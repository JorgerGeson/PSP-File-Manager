/*
 * editor.c - editor de texto e editor hexadecimal
 *
 * Texto: o arquivo e carregado em linhas; X edita a linha sob o cursor com o
 *        teclado em tela (com cursor e acentos). Salva via arquivo temporario.
 * Hex  : altera bytes direto no arquivo (tamanho fixo).
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdebug.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "ui.h"
#include "fsops.h"
#include "viewer.h"
#include "editor.h"

#define EDIT_MAX      (1024 * 1024)
#define LINE_EDIT_MAX 1024
#define LINE_HARD_MAX 4000
#define TROWS         31          /* linhas de texto na tela (1..31) */
#define UNDO_MAX      128

/* ======================= linhas ======================= */
typedef struct { char *s; int len; } ELine;

static ELine *L = NULL;
static int nL = 0, capL = 0;

static char *dupn(const char *s, int n)
{
    char *p = (char *)malloc((size_t)n + 1);
    if (!p) return NULL;
    memcpy(p, s, (size_t)n);
    p[n] = 0;
    return p;
}

static int l_insert(int idx, const char *s, int n)
{
    if (nL >= capL) {
        int nc = capL ? capL * 2 : 256;
        ELine *nv = (ELine *)realloc(L, (size_t)nc * sizeof(ELine));
        if (!nv) return 0;
        L = nv;
        capL = nc;
    }
    char *d = dupn(s, n);
    if (!d) return 0;
    if (idx < nL) memmove(L + idx + 1, L + idx, (size_t)(nL - idx) * sizeof(ELine));
    L[idx].s = d;
    L[idx].len = n;
    nL++;
    return 1;
}

static void l_remove(int idx)
{
    free(L[idx].s);
    if (idx < nL - 1) memmove(L + idx, L + idx + 1, (size_t)(nL - idx - 1) * sizeof(ELine));
    nL--;
}

static int l_set(int idx, const char *s, int n)
{
    char *d = dupn(s, n);
    if (!d) return 0;
    free(L[idx].s);
    L[idx].s = d;
    L[idx].len = n;
    return 1;
}

static void l_free_all(void)
{
    for (int i = 0; i < nL; i++) free(L[i].s);
    free(L);
    L = NULL;
    nL = capL = 0;
}

/* ======================= desfazer ======================= */
typedef struct { int type, idx, grp; char *text; } Undo;   /* 0 = SET(texto antigo), 1 = INS, 2 = DEL(texto antigo) */
static Undo us[UNDO_MAX];
static int nu = 0, g_grp = 0;

static void u_clear(void)
{
    for (int i = 0; i < nu; i++) free(us[i].text);
    nu = 0;
}

static void u_push(int type, int idx, const char *text, int grp)
{
    if (nu == UNDO_MAX) {
        free(us[0].text);
        memmove(us, us + 1, sizeof(Undo) * (UNDO_MAX - 1));
        nu--;
    }
    us[nu].type = type;
    us[nu].idx = idx;
    us[nu].grp = grp;
    us[nu].text = text ? dupn(text, (int)strlen(text)) : NULL;
    nu++;
}

/* operacoes com registro de desfazer */
static int op_set(int idx, const char *s, int grp)
{
    u_push(0, idx, L[idx].s, grp);
    return l_set(idx, s, (int)strlen(s));
}

static int op_ins(int idx, const char *s, int grp)
{
    if (!l_insert(idx, s, (int)strlen(s))) return 0;
    u_push(1, idx, NULL, grp);
    return 1;
}

static int op_del(int idx, int grp)
{
    if (nL == 1) return op_set(0, "", grp);
    u_push(2, idx, L[idx].s, grp);
    l_remove(idx);
    return 1;
}

static int undo_last(int *line)
{
    if (nu == 0) return 0;
    int grp = us[nu - 1].grp;
    while (nu > 0 && us[nu - 1].grp == grp) {
        Undo *u = &us[--nu];
        if (u->type == 0) { if (u->idx < nL) l_set(u->idx, u->text, (int)strlen(u->text)); }
        else if (u->type == 1) { if (u->idx < nL && nL > 1) l_remove(u->idx); }
        else l_insert(u->idx <= nL ? u->idx : nL, u->text, (int)strlen(u->text));
        *line = u->idx;
        free(u->text);
    }
    if (*line >= nL) *line = nL - 1;
    if (*line < 0) *line = 0;
    return 1;
}

/* ======================= estado do editor ======================= */
static int g_crlf = 0, g_final_nl = 1, g_modified = 0;
static char g_find[128] = "";
static char g_msg[96] = "";

static void msg(const char *m) { snprintf(g_msg, sizeof(g_msg), "%s", m); }

static int load_file(const char *path)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) { ui_message("Nao foi possivel ler o arquivo.", "", C_RED); return 0; }
    if (st.st_size > EDIT_MAX) {
        ui_message("Arquivo maior que 1 MB.", "Use o editor hex para arquivos grandes.", C_RED);
        return 0;
    }
    int n = (int)st.st_size;
    char *data = (char *)malloc((size_t)n + 1);
    if (!data) { ui_message("Memoria insuficiente.", "", C_RED); return 0; }
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) { free(data); ui_message("Nao foi possivel abrir o arquivo.", "", C_RED); return 0; }
    int rd = (n > 0) ? sceIoRead(fd, data, n) : 0;
    sceIoClose(fd);
    if (rd < 0) rd = 0;
    n = rd;
    data[n] = 0;

    for (int i = 0; i < n && i < 4096; i++)
        if (data[i] == 0) {
            free(data);
            ui_message("Arquivo binario (tem bytes nulos).", "Abra com o editor hex.", C_YELLOW);
            return 0;
        }

    int crlf = 0, total = 0;
    int i = 0;
    while (i < n) {
        int start = i;
        while (i < n && data[i] != '\n') i++;
        int end = i;
        if (end > start && data[end - 1] == '\r') { end--; crlf++; }
        if (!l_insert(nL, data + start, end - start)) break;
        total++;
        if (i < n) i++;                       /* pula o \n */
    }
    g_final_nl = (n == 0) || data[n - 1] == '\n';
    if (n > 0 && data[n - 1] == '\n' && total > 0) { /* a ultima "linha" vazia nao existe */ }
    if (nL == 0) l_insert(0, "", 0);
    g_crlf = (total > 0 && crlf * 2 > total);
    free(data);
    return 1;
}

static int save_file(const char *path)
{
    int eol = g_crlf ? 2 : 1;
    size_t total = 0;
    for (int i = 0; i < nL; i++) total += (size_t)L[i].len + (size_t)eol;
    char *out = (char *)malloc(total + 1);
    if (!out) return 0;

    size_t o = 0;
    for (int i = 0; i < nL; i++) {
        memcpy(out + o, L[i].s, (size_t)L[i].len);
        o += (size_t)L[i].len;
        if (i < nL - 1 || g_final_nl) {
            if (g_crlf) out[o++] = '\r';
            out[o++] = '\n';
        }
    }

    char tmp[560];
    snprintf(tmp, sizeof(tmp), "%s.new", path);
    SceUID fd = sceIoOpen(tmp, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (fd < 0) { free(out); return 0; }
    size_t pos = 0;
    int ok = 1;
    while (pos < o) {
        size_t chunk = o - pos > 65536 ? 65536 : o - pos;
        int w = sceIoWrite(fd, out + pos, (SceSize)chunk);
        if (w != (int)chunk) { ok = 0; break; }
        pos += chunk;
    }
    sceIoClose(fd);
    free(out);
    if (!ok) { sceIoRemove(tmp); return 0; }

    /* troca o original pelo novo; se falhar o .new continua no cartao */
    if (sceIoRemove(path) < 0 && fs_exists(path)) { sceIoRemove(tmp); return 0; }
    if (sceIoRename(tmp, path) < 0) return 0;
    return 1;
}

/* ======================= desenho ======================= */
static int digits(int v) { int d = 1; while (v >= 10) { v /= 10; d++; } return d; }

/* copia "width" colunas de s (UTF-8 -> ASCII), pulando "skip" colunas */
static void fold_range(const char *s, int len, int skip, char *out, int width)
{
    int col = 0, o = 0;
    for (int i = 0; i < len && o < width; ) {
        char ch;
        if (s[i] == '\t') { ch = ' '; i++; }
        else i += ui_fold_char((const unsigned char *)s + i, len - i, &ch);
        if (col++ >= skip) out[o++] = ch;
    }
    out[o] = 0;
}

static void draw_text(const char *name, int cur, int top, int hs)
{
    int lw = digits(nL);
    if (lw < 3) lw = 3;
    int width = UI_W - (lw + 2);

    ui_line(0, C_BLACK, C_CYAN, " %.34s  lin %d/%d%s%s", name, cur + 1, nL,
            g_modified ? "  [modificado]" : "", g_crlf ? " CRLF" : "");
    for (int r = 0; r < TROWS; r++) {
        int k = top + r;
        if (k >= nL) { ui_line(1 + r, C_WHITE, C_BLACK, ""); continue; }
        char t[UI_W + 2];
        fold_range(L[k].s, L[k].len, hs, t, width);
        ui_line(1 + r, (k == cur) ? C_BLACK : C_WHITE, (k == cur) ? C_YELLOW : C_BLACK,
                "%*d %s", lw + 1, k + 1, t);
    }
    if (g_msg[0]) ui_line(32, C_BLACK, C_GREEN, " %s", g_msg);
    else          ui_line(32, C_GRAY, C_BLACK, " col %d | %d bytes na linha", hs + 1, L[cur].len);
    ui_line(33, C_GRAY, C_BLACK, " X:editar Quad:nova linha Tri:menu Start:salvar O:sair");
}

/* ======================= ferramentas ======================= */
static const char *ci_find(const char *h, const char *n)
{
    int nl = (int)strlen(n);
    if (nl == 0) return h;
    for (; *h; h++) {
        int i = 0;
        while (i < nl && h[i] && tolower((unsigned char)h[i]) == tolower((unsigned char)n[i])) i++;
        if (i == nl) return h;
    }
    return NULL;
}

static int find_next(int from)
{
    if (!g_find[0]) return -1;
    for (int k = 1; k <= nL; k++) {
        int i = (from + k) % nL;
        if (ci_find(L[i].s, g_find)) return i;
    }
    return -1;
}

static int edit_line(int idx, int grp)
{
    char buf[LINE_EDIT_MAX];
    if (L[idx].len >= LINE_EDIT_MAX - 1) {
        ui_message("Linha longa demais para editar", "(maximo 1000 bytes).", C_YELLOW);
        return 0;
    }
    memcpy(buf, L[idx].s, (size_t)L[idx].len + 1);
    if (!ui_input_text_ex("Editar linha", buf, sizeof(buf), 1)) return 0;
    if (!strcmp(buf, L[idx].s)) return 0;
    if (!op_set(idx, buf, grp)) return 0;
    g_modified = 1;
    return 1;
}

static void replace_all(void)
{
    char a[128], b[128];
    snprintf(a, sizeof(a), "%s", g_find);
    if (!ui_input_text("Substituir: texto a procurar", a, sizeof(a))) return;
    b[0] = 0;
    if (!ui_input_text_ex("Substituir por (pode ser vazio)", b, sizeof(b), 1)) return;
    snprintf(g_find, sizeof(g_find), "%s", a);

    int grp = ++g_grp, changed = 0, total = 0;
    int al = (int)strlen(a), bl = (int)strlen(b);
    char *tmp = (char *)malloc(LINE_HARD_MAX + 1);
    if (!tmp) return;
    for (int i = 0; i < nL; i++) {
        const char *p = L[i].s;
        int o = 0, hit = 0;
        const char *m;
        while ((m = ci_find(p, a)) != NULL) {
            int pre = (int)(m - p);
            if (o + pre + bl > LINE_HARD_MAX) { hit = -1; break; }
            memcpy(tmp + o, p, (size_t)pre); o += pre;
            memcpy(tmp + o, b, (size_t)bl); o += bl;
            p = m + al;
            hit++;
        }
        if (hit <= 0) continue;
        int rest = (int)strlen(p);
        if (o + rest > LINE_HARD_MAX) continue;
        memcpy(tmp + o, p, (size_t)rest); o += rest;
        tmp[o] = 0;
        if (op_set(i, tmp, grp)) { changed++; total += hit; }
    }
    free(tmp);
    if (changed) g_modified = 1;
    char m[96];
    snprintf(m, sizeof(m), "%d substituicao(oes) em %d linha(s)", total, changed);
    msg(m);
}

enum { T_SAVE, T_SAVEEXIT, T_INS_ABOVE, T_INS_BELOW, T_DEL, T_DUP, T_JOIN, T_GOTO,
       T_FIND, T_FINDNEXT, T_REPLACE, T_UNDO, T_EXIT, T_COUNT };

/* ======================= editor de texto ======================= */
void edit_text(const char *path)
{
    if (path_is_ro(path)) { ui_message("Arquivo em area somente leitura.", "", C_YELLOW); return; }
    l_free_all();
    u_clear();
    g_modified = 0;
    g_msg[0] = 0;
    if (!load_file(path)) { l_free_all(); return; }

    const char *name = path_base(path);
    int cur = 0, top = 0, hs = 0;
    ui_clear();

    for (;;) {
        if (cur < 0) cur = 0;
        if (cur >= nL) cur = nL - 1;
        if (cur < top) top = cur;
        if (cur >= top + TROWS) top = cur - TROWS + 1;
        if (top < 0) top = 0;
        if (hs < 0) hs = 0;

        draw_text(name, cur, top, hs);
        g_msg[0] = 0;

        unsigned p = ui_wait();
        int action = -1;           /* acao do menu */

        if (p & PSP_CTRL_UP)       cur = (cur > 0) ? cur - 1 : nL - 1;
        if (p & PSP_CTRL_DOWN)     cur = (cur < nL - 1) ? cur + 1 : 0;
        if (p & PSP_CTRL_LTRIGGER) cur -= TROWS;
        if (p & PSP_CTRL_RTRIGGER) cur += TROWS;
        if (cur < 0) cur = 0;
        if (cur >= nL) cur = nL - 1;
        if (p & PSP_CTRL_LEFT)     hs = (hs >= 16) ? hs - 16 : 0;
        if (p & PSP_CTRL_RIGHT)    hs += 16;

        if (p & PSP_CTRL_CROSS) {
            edit_line(cur, ++g_grp);
            ui_clear();
        }
        if (p & PSP_CTRL_SQUARE) {
            int grp = ++g_grp;
            if (op_ins(cur + 1, "", grp)) {
                g_modified = 1;
                cur++;
                if (!edit_line(cur, grp)) {
                    /* cancelou: desfaz a linha vazia inserida */
                    int ln = cur;
                    undo_last(&ln);
                    cur = ln > 0 ? ln - 1 : 0;
                }
                ui_clear();
            }
        }
        if (p & PSP_CTRL_START) action = T_SAVE;
        if (p & PSP_CTRL_TRIANGLE) {
            static const char *items[T_COUNT] = {
                "Salvar", "Salvar e sair", "Inserir linha acima", "Inserir linha abaixo",
                "Excluir linha", "Duplicar linha", "Juntar com a proxima linha", "Ir para a linha...",
                "Procurar...", "Procurar proxima", "Substituir tudo...", "Desfazer", "Sair sem salvar"
            };
            action = ui_menu("Editor - menu", items, T_COUNT, 0);
            ui_clear();
        }
        if (p & PSP_CTRL_CIRCLE) {
            if (!g_modified) break;
            static const char *ex[3] = { "Salvar e sair", "Sair sem salvar", "Continuar editando" };
            int s = ui_menu("Ha alteracoes nao salvas", ex, 3, 0);
            ui_clear();
            if (s == 0) action = T_SAVEEXIT;
            else if (s == 1) break;
        }

        switch (action) {
        case T_SAVE:
            msg(save_file(path) ? (g_modified = 0, "Arquivo salvo") : "ERRO ao salvar (disco cheio?)");
            break;
        case T_SAVEEXIT:
            if (save_file(path)) { g_modified = 0; goto done; }
            msg("ERRO ao salvar (disco cheio?)");
            break;
        case T_INS_ABOVE:
            if (op_ins(cur, "", ++g_grp)) { g_modified = 1; edit_line(cur, g_grp); }
            ui_clear();
            break;
        case T_INS_BELOW:
            if (op_ins(cur + 1, "", ++g_grp)) { g_modified = 1; cur++; edit_line(cur, g_grp); }
            ui_clear();
            break;
        case T_DEL:
            if (op_del(cur, ++g_grp)) { g_modified = 1; msg("Linha excluida (Menu > Desfazer)"); }
            break;
        case T_DUP:
            if (op_ins(cur + 1, L[cur].s, ++g_grp)) { g_modified = 1; cur++; }
            break;
        case T_JOIN:
            if (cur < nL - 1 && L[cur].len + L[cur + 1].len <= LINE_HARD_MAX) {
                char *j = (char *)malloc((size_t)L[cur].len + (size_t)L[cur + 1].len + 1);
                if (j) {
                    int grp = ++g_grp;
                    strcpy(j, L[cur].s);
                    strcat(j, L[cur + 1].s);
                    op_set(cur, j, grp);
                    op_del(cur + 1, grp);
                    g_modified = 1;
                    free(j);
                }
            }
            break;
        case T_GOTO: {
            char b[16] = "";
            if (ui_input_text("Ir para a linha numero", b, sizeof(b))) {
                int v = atoi(b);
                if (v >= 1 && v <= nL) cur = v - 1;
            }
            ui_clear();
            break;
        }
        case T_FIND:
            if (ui_input_text("Procurar (ignora maiusculas)", g_find, sizeof(g_find))) {
                int f = find_next(cur);
                if (f >= 0) { cur = f; msg("Encontrado"); } else msg("Nao encontrado");
            }
            ui_clear();
            break;
        case T_FINDNEXT: {
            int f = find_next(cur);
            if (f >= 0) { cur = f; msg("Encontrado"); } else msg(g_find[0] ? "Nao encontrado" : "Use Procurar primeiro");
            break;
        }
        case T_REPLACE:
            replace_all();
            ui_clear();
            break;
        case T_UNDO: {
            int ln = cur;
            if (undo_last(&ln)) { cur = ln; g_modified = 1; msg("Desfeito"); }
            else msg("Nada para desfazer");
            break;
        }
        case T_EXIT:
            if (!g_modified || ui_confirm("Descartar as alteracoes?", "X = descartar   O = voltar")) goto done;
            ui_clear();
            break;
        default: break;
        }
    }
done:
    l_free_all();
    u_clear();
    ui_clear();
}

/* ======================= editor hexadecimal ======================= */
#define HROWS 31
#define HPER  8

static int hex_find(SceUID fd, unsigned long long size, unsigned long long start,
                    const unsigned char *pat, int plen, unsigned long long *found)
{
    const int CH = 32768;
    unsigned char *b = (unsigned char *)malloc((size_t)CH + (size_t)plen);
    if (!b) return 0;
    unsigned long long pos = start;
    int ok = 0;
    while (pos < size) {
        sceIoLseek(fd, (SceOff)pos, PSP_SEEK_SET);
        int got = sceIoRead(fd, b, CH + plen - 1);
        if (got < plen) break;
        for (int i = 0; i + plen <= got; i++)
            if (b[i] == pat[0] && !memcmp(b + i, pat, (size_t)plen)) { *found = pos + (unsigned)i; ok = 1; break; }
        if (ok) break;
        pos += (unsigned)(got - plen + 1);
        if (got < CH + plen - 1) break;
    }
    free(b);
    return ok;
}

static int parse_hex(const char *s, unsigned char *out, int max)
{
    int n = 0, hi = -1;
    for (; *s; s++) {
        int v;
        if (*s >= '0' && *s <= '9') v = *s - '0';
        else if (*s >= 'a' && *s <= 'f') v = *s - 'a' + 10;
        else if (*s >= 'A' && *s <= 'F') v = *s - 'A' + 10;
        else if (*s == ' ') continue;
        else return -1;
        if (hi < 0) hi = v;
        else { if (n >= max) return -1; out[n++] = (unsigned char)(hi * 16 + v); hi = -1; }
    }
    return hi < 0 ? n : -1;
}

enum { H_BYTE, H_TEXT, H_GOTO, H_FINDT, H_FINDH, H_EXIT, H_COUNT };

void edit_hex(const char *path)
{
    if (path_is_ro(path)) { ui_message("Arquivo em area somente leitura.", "", C_YELLOW); return; }
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) { ui_message("Nao foi possivel ler o arquivo.", "", C_RED); return; }
    unsigned long long size = (unsigned long long)st.st_size;
    if (size == 0) { ui_message("Arquivo vazio.", "", C_YELLOW); return; }
    SceUID fd = sceIoOpen(path, PSP_O_RDWR, 0777);
    if (fd < 0) { ui_message("Nao foi possivel abrir para escrita.", "", C_RED); return; }

    const char *name = path_base(path);
    unsigned long long cur = 0, top = 0;
    int warned = 0, edits = 0;
    char note[80] = "";
    unsigned char buf[HROWS * HPER];
    ui_clear();

    for (;;) {
        if (cur >= size) cur = size - 1;
        unsigned long long page = (unsigned long long)HROWS * HPER;
        if (cur < top) top = (cur / HPER) * HPER;
        if (cur >= top + page) top = (cur / HPER) * HPER - page + HPER;

        sceIoLseek(fd, (SceOff)top, PSP_SEEK_SET);
        int got = sceIoRead(fd, buf, (SceSize)page);
        if (got < 0) got = 0;

        ui_line(0, C_BLACK, C_CYAN, " %.30s  %08X/%08X  %d alt.", name, (unsigned)cur, (unsigned)size, edits);
        for (int r = 0; r < HROWS; r++) {
            char row[96];
            int o = snprintf(row, sizeof(row), "%08X  ", (unsigned)(top + (unsigned long long)r * HPER));
            for (int k = 0; k < HPER; k++) {
                int idx = r * HPER + k;
                if (idx < got) o += snprintf(row + o, sizeof(row) - o, "%02X ", buf[idx]);
                else           o += snprintf(row + o, sizeof(row) - o, "   ");
            }
            row[o++] = ' ';
            for (int k = 0; k < HPER; k++) {
                int idx = r * HPER + k;
                char c = ' ';
                if (idx < got) { c = (char)buf[idx]; if (c < 32 || c > 126) c = '.'; }
                row[o++] = c;
            }
            row[o] = 0;
            ui_line(1 + r, (r * HPER < got) ? C_WHITE : C_GRAY, C_BLACK, "%s", row);
        }
        /* destaca o byte sob o cursor (hex e ascii) */
        {
            int rel = (int)(cur - top);
            int r = rel / HPER, k = rel % HPER;
            if (rel < got) {
                pspDebugScreenSetTextColor(C_BLACK);
                pspDebugScreenSetBackColor(C_YELLOW);
                pspDebugScreenSetXY(10 + 3 * k, 1 + r);
                pspDebugScreenPrintf("%02X", buf[rel]);
                char c = (char)buf[rel];
                if (c < 32 || c > 126) c = '.';
                pspDebugScreenSetXY(35 + k, 1 + r);
                pspDebugScreenPrintf("%c", c);
            }
        }
        if (note[0]) ui_line(32, C_BLACK, C_GREEN, " %s", note);
        else         ui_line(32, C_GRAY, C_BLACK, " X:editar byte  Tri:menu");
        ui_line(33, C_GRAY, C_BLACK, " Setas:mover L/R:pagina X:editar byte Tri:menu O:sair");
        note[0] = 0;

        unsigned p = ui_wait();
        if (p & PSP_CTRL_UP)       cur = (cur >= HPER) ? cur - HPER : cur;
        if (p & PSP_CTRL_DOWN)     cur += HPER;
        if (p & PSP_CTRL_LEFT)     cur = (cur > 0) ? cur - 1 : 0;
        if (p & PSP_CTRL_RIGHT)    cur += 1;
        if (p & PSP_CTRL_LTRIGGER) cur = (cur >= page) ? cur - page : 0;
        if (p & PSP_CTRL_RTRIGGER) cur += page;
        if (cur >= size) cur = size - 1;
        if (p & PSP_CTRL_CIRCLE) break;

        int action = -1;
        if (p & PSP_CTRL_CROSS) action = H_BYTE;
        if (p & PSP_CTRL_TRIANGLE) {
            static const char *items[H_COUNT] = {
                "Editar byte (valor hex)", "Escrever texto aqui (sobrescreve)", "Ir para o offset (hex)...",
                "Procurar texto...", "Procurar bytes (hex)...", "Sair"
            };
            action = ui_menu("Editor hex - menu", items, H_COUNT, 0);
            ui_clear();
        }
        if (action < 0) continue;
        if (action == H_EXIT) break;

        if ((action == H_BYTE || action == H_TEXT) && !warned) {
            if (!ui_confirm("Alterar bytes grava direto no arquivo.", "X = continuar   O = cancelar")) { ui_clear(); continue; }
            warned = 1;
        }

        if (action == H_BYTE) {
            char b[8];
            snprintf(b, sizeof(b), "%02X", buf[cur - top < (unsigned)got ? cur - top : 0]);
            if (ui_input_text("Novo valor do byte (hex 00-FF)", b, sizeof(b))) {
                unsigned char v[2];
                int n = parse_hex(b, v, 1);
                if (n == 1) {
                    sceIoLseek(fd, (SceOff)cur, PSP_SEEK_SET);
                    if (sceIoWrite(fd, v, 1) == 1) { edits++; snprintf(note, sizeof(note), "Byte %08X = %02X", (unsigned)cur, v[0]); }
                    else snprintf(note, sizeof(note), "ERRO ao gravar");
                } else snprintf(note, sizeof(note), "Valor invalido");
            }
            ui_clear();
        } else if (action == H_TEXT) {
            char t[128] = "";
            if (ui_input_text("Texto a escrever na posicao atual", t, sizeof(t))) {
                int tl = (int)strlen(t);
                if ((unsigned long long)tl > size - cur) tl = (int)(size - cur);
                sceIoLseek(fd, (SceOff)cur, PSP_SEEK_SET);
                if (sceIoWrite(fd, t, (SceSize)tl) == tl) { edits += tl; snprintf(note, sizeof(note), "%d byte(s) gravado(s)", tl); cur += (unsigned)tl; }
                else snprintf(note, sizeof(note), "ERRO ao gravar");
            }
            ui_clear();
        } else if (action == H_GOTO) {
            char b[16] = "";
            if (ui_input_text("Offset em hexadecimal", b, sizeof(b))) {
                unsigned long long v = strtoull(b, NULL, 16);
                cur = (v < size) ? v : size - 1;
            }
            ui_clear();
        } else if (action == H_FINDT || action == H_FINDH) {
            char b[96] = "";
            unsigned char pat[64];
            int pl = 0;
            if (ui_input_text(action == H_FINDT ? "Procurar texto (exato)" : "Procurar bytes hex (ex: 4F 6B)", b, sizeof(b))) {
                if (action == H_FINDT) { pl = (int)strlen(b); if (pl > 63) pl = 63; memcpy(pat, b, (size_t)pl); }
                else pl = parse_hex(b, pat, 63);
                unsigned long long f;
                if (pl <= 0) snprintf(note, sizeof(note), "Padrao invalido");
                else if (hex_find(fd, size, cur + 1, pat, pl, &f) || hex_find(fd, size, 0, pat, pl, &f)) {
                    cur = f;
                    snprintf(note, sizeof(note), "Encontrado em %08X", (unsigned)f);
                } else snprintf(note, sizeof(note), "Nao encontrado");
            }
            ui_clear();
        }
    }
    sceIoClose(fd);
    ui_clear();
}
