/*
 * rarlib.cpp - ponte entre o arch.c e o unrar (API de DLL do unrar compilada como biblioteca)
 *
 * Usado so com USE_UNRAR=1. Suporta RAR 1.3 a 5.x com compressao, senha (inclusive
 * cabecalhos criptografados). Volumes divididos nao sao suportados.
 */
#ifndef _UNIX
#define _UNIX
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>
#include "dll.hpp"
extern "C" {
#include "fsops.h"
#include "arch.h"
}
#if defined(PSP) || defined(_PSP) || defined(__PSP__)
#include <pspkernel.h>
#define HAVE_PSPMEM 1
#endif

/* ---------- conversoes UTF-8 <-> wchar_t ---------- */
static void utf8_to_w(const char *s, wchar_t *w, int max)
{
    int o = 0;
    while (*s && o < max - 2) {
        unsigned char c = (unsigned char)*s;
        unsigned cp; int n;
        if (c < 0x80) { cp = c; n = 1; }
        else if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; n = 2; }
        else if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; n = 3; }
        else if ((c & 0xF8) == 0xF0) { cp = c & 0x07; n = 4; }
        else { cp = '?'; n = 1; }
        for (int i = 1; i < n; i++) {
            if (((unsigned char)s[i] & 0xC0) != 0x80) { cp = '?'; n = i; break; }
            cp = (cp << 6) | ((unsigned char)s[i] & 0x3F);
        }
        s += n;
        if (sizeof(wchar_t) == 2 && cp >= 0x10000) {
            cp -= 0x10000;
            w[o++] = (wchar_t)(0xD800 + (cp >> 10));
            w[o++] = (wchar_t)(0xDC00 + (cp & 0x3FF));
        } else w[o++] = (wchar_t)cp;
    }
    w[o] = 0;
}

static void w_to_utf8(const wchar_t *w, char *s, int max)
{
    int o = 0;
    for (; *w && o < max - 5; w++) {
        unsigned cp = (unsigned)*w;
        if (sizeof(wchar_t) == 2 && cp >= 0xD800 && cp < 0xDC00 && w[1] >= 0xDC00 && w[1] < 0xE000) {
            cp = 0x10000 + ((cp - 0xD800) << 10) + ((unsigned)w[1] - 0xDC00);
            w++;
        }
        if (cp < 0x80) s[o++] = (char)cp;
        else if (cp < 0x800) { s[o++] = (char)(0xC0 | (cp >> 6)); s[o++] = (char)(0x80 | (cp & 0x3F)); }
        else if (cp < 0x10000) { s[o++] = (char)(0xE0 | (cp >> 12)); s[o++] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[o++] = (char)(0x80 | (cp & 0x3F)); }
        else { s[o++] = (char)(0xF0 | (cp >> 18)); s[o++] = (char)(0x80 | ((cp >> 12) & 0x3F)); s[o++] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[o++] = (char)(0x80 | (cp & 0x3F)); }
    }
    s[o] = 0;
}

/* ---------- callback ---------- */
struct Ctx {
    char name[256];
    unsigned long long done, total;
    int cancel;
};

static int CALLBACK rar_cb(UINT msg, LPARAM user, LPARAM p1, LPARAM p2)
{
    Ctx *c = (Ctx *)user;
    switch (msg) {
    case UCM_PROCESSDATA:
        if (c) {
            c->done += (unsigned long long)p2;
            if (fs_progress && fs_progress(c->name, c->done, c->total)) { c->cancel = 1; return -1; }
        }
        return 0;
    case UCM_NEEDPASSWORD:
        if (!arc_password[0]) return -1;
        strncpy((char *)p1, arc_password, (size_t)p2);
        ((char *)p1)[p2 - 1] = 0;
        return 1;
    case UCM_LARGEDICT:
        return 0;                       /* nao deixa estourar a memoria do PSP */
    case UCM_CHANGEVOLUME:
    case UCM_CHANGEVOLUMEW:
        return -1;                      /* volumes divididos nao suportados */
    default:
        return 0;
    }
}

static unsigned mem_limit_mb(void)
{
#ifdef HAVE_PSPMEM
    unsigned mb = (unsigned)(sceKernelMaxFreeMemSize() / (1024 * 1024));
    return mb > 10 ? mb - 6 : 4;       /* reserva para o restante do programa */
#else
    return 0;                           /* sem limite (teste no PC) */
#endif
}

static const char *err_text(int code)
{
    switch (code) {
    case ERAR_NO_MEMORY:        return "Memoria insuficiente";
    case ERAR_BAD_DATA:         return "Dados corrompidos / CRC invalido";
    case ERAR_BAD_ARCHIVE:      return "Arquivo RAR invalido";
    case ERAR_UNKNOWN_FORMAT:   return "Formato RAR desconhecido";
    case ERAR_EOPEN:            return "Nao foi possivel abrir o arquivo";
    case ERAR_ECREATE:          return "Nao foi possivel criar o arquivo";
    case ERAR_EREAD:            return "Erro de leitura / cancelado";
    case ERAR_EWRITE:           return "Erro ao gravar (disco cheio?)";
    case ERAR_MISSING_PASSWORD: return "Senha necessaria";
    case ERAR_BAD_PASSWORD:     return "Senha incorreta";
    case ERAR_LARGE_DICT:       return "Dicionario grande demais para a memoria do PSP";
    case ERAR_USER_LIMIT:       return "Dicionario grande demais para a memoria do PSP";
    default:                    return "Erro do unrar";
    }
}

static void set_err(char *dst, const char *m) { snprintf(dst, 96, "%s", m); }

static HANDLE open_arc(const char *path, unsigned mode, Ctx *ctx, int *result)
{
    static wchar_t wpath[1024];
    utf8_to_w(path, wpath, 1024);
    RAROpenArchiveDataEx od;
    memset(&od, 0, sizeof(od));
    od.ArcNameW = wpath;
    od.OpenMode = mode;
    od.Callback = rar_cb;
    od.UserData = (LPARAM)ctx;
    od.MaxAllocate = mem_limit_mb();
    HANDLE h = RAROpenArchiveEx(&od);
    *result = (int)od.OpenResult;
    if (h && arc_password[0]) RARSetPassword(h, arc_password);
    return h;
}

/* ---------- listar ---------- */
extern "C" int rarlib_list(const char *path, ArcList *al)
{
    Ctx ctx;
    memset(&ctx, 0, sizeof(ctx));
    int res = 0;
    HANDLE h = open_arc(path, RAR_OM_LIST, &ctx, &res);
    if (!h) { set_err(al->err, err_text(res ? res : ERAR_EOPEN)); return FS_ERR; }

    RARHeaderDataEx *hd = new RARHeaderDataEx;
    int rc = FS_OK;
    for (;;) {
        memset(hd, 0, sizeof(*hd));
        int r = RARReadHeaderEx(h, hd);
        if (r == ERAR_END_ARCHIVE) break;
        if (r != ERAR_SUCCESS) {
            if (al->n == 0) { set_err(al->err, err_text(r)); rc = FS_ERR; }
            break;
        }
        ArcEntry *e = arc_list_add(al);
        if (!e) break;
        char u8[1024];
        w_to_utf8(hd->FileNameW, u8, sizeof(u8));
        for (char *q = u8; *q; q++) if (*q == '\\') *q = '/';
        snprintf(e->name, sizeof(e->name), "%s", u8);
        e->csize = (unsigned long long)hd->PackSize | ((unsigned long long)hd->PackSizeHigh << 32);
        e->usize = (unsigned long long)hd->UnpSize | ((unsigned long long)hd->UnpSizeHigh << 32);
        e->method = hd->Method;
        e->crc = hd->FileCRC;
        e->hascrc = 0;                                  /* o unrar confere sozinho */
        e->isdir = (hd->Flags & RHDF_DIRECTORY) ? 1 : 0;
        e->encrypted = (hd->Flags & RHDF_ENCRYPTED) ? 1 : 0;
        if (hd->Flags & (RHDF_SPLITBEFORE | RHDF_SPLITAFTER)) e->status = AST_SPLIT;
        RARProcessFile(h, RAR_SKIP, NULL, NULL);
    }
    delete hd;
    RARCloseArchive(h);
    return rc;
}

/* ---------- extrair ---------- */
extern "C" int rarlib_extract(const char *path, const char *destdir, int index, int overwrite, ArcResult *res)
{
    Ctx ctx;
    memset(&ctx, 0, sizeof(ctx));
    int orr = 0;
    HANDLE h = open_arc(path, RAR_OM_EXTRACT, &ctx, &orr);
    if (!h) { set_err(res->lasterr, err_text(orr ? orr : ERAR_EOPEN)); return FS_ERR; }
    fs_mkpath(destdir);

    RARHeaderDataEx *hd = new RARHeaderDataEx;
    int result = FS_OK, i = 0;
    for (;; i++) {
        memset(hd, 0, sizeof(*hd));
        int r = RARReadHeaderEx(h, hd);
        if (r == ERAR_END_ARCHIVE) break;
        if (r != ERAR_SUCCESS) {
            set_err(res->lasterr, err_text(r));
            if (r == ERAR_MISSING_PASSWORD || r == ERAR_BAD_PASSWORD || r == ERAR_BAD_DATA || i == 0) {
                res->failed++;
                if (i == 0) result = FS_ERR;
            }
            break;
        }
        if (index >= 0 && i != index) { RARProcessFile(h, RAR_SKIP, NULL, NULL); continue; }

        char u8[1024], safe[512], full[512];
        w_to_utf8(hd->FileNameW, u8, sizeof(u8));
        if (!arc_safe_name(u8, safe, sizeof(safe))) {
            res->failed++;
            set_err(res->lasterr, "Nome inseguro ignorado");
            RARProcessFile(h, RAR_SKIP, NULL, NULL);
            goto next;
        }
        path_join(full, sizeof(full), destdir, safe);

        if (hd->Flags & RHDF_DIRECTORY) {
            fs_mkpath(full);
            RARProcessFile(h, RAR_SKIP, NULL, NULL);
        } else if (hd->Flags & (RHDF_SPLITBEFORE | RHDF_SPLITAFTER)) {
            res->failed++;
            set_err(res->lasterr, "Volume dividido nao suportado");
            RARProcessFile(h, RAR_SKIP, NULL, NULL);
        } else if (!overwrite && fs_exists(full)) {
            res->skipped++;
            RARProcessFile(h, RAR_SKIP, NULL, NULL);
        } else {
            char dir[512];
            snprintf(dir, sizeof(dir), "%s", full);
            char *sl = strrchr(dir, '/');
            if (sl) { *sl = 0; fs_mkpath(dir); }

            snprintf(ctx.name, sizeof(ctx.name), "%s", path_base(safe));
            ctx.done = 0;
            ctx.total = (unsigned long long)hd->UnpSize | ((unsigned long long)hd->UnpSizeHigh << 32);
            ctx.cancel = 0;

            static wchar_t wfull[1024];
            utf8_to_w(full, wfull, 1024);
            int pr = RARProcessFileW(h, RAR_EXTRACT, NULL, wfull);
            if (ctx.cancel) { remove(full); result = FS_CANCEL; break; }
            if (pr == ERAR_SUCCESS) res->ok++;
            else {
                res->failed++;
                set_err(res->lasterr, err_text(pr));
                remove(full);
                if (pr == ERAR_NO_MEMORY || pr == ERAR_LARGE_DICT || pr == ERAR_USER_LIMIT) break;
            }
        }
    next:;
    }
    delete hd;
    RARCloseArchive(h);
    return result;
}
