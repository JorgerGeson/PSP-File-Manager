#ifndef ARCH_H
#define ARCH_H
#ifdef __cplusplus
extern "C" {
#endif

/* Arquivos compactados: ZIP (listar, extrair, criar) e RAR (listar e extrair
 * entradas armazenadas sem compressao - ver arch.c).  */

enum { ARC_NONE = 0, ARC_ZIP, ARC_RAR4, ARC_RAR5 };

/* motivo pelo qual uma entrada nao pode ser extraida */
enum { AST_OK = 0, AST_ENCRYPTED, AST_METHOD, AST_SPLIT };

typedef struct {
    char name[256];
    unsigned long long csize;    /* tamanho compactado */
    unsigned long long usize;    /* tamanho original */
    unsigned long long off;      /* zip: cabecalho local | rar: inicio dos dados */
    unsigned method;             /* zip: 0/8 | rar4: 0x30..0x35 | rar5: 0..5 */
    unsigned crc;
    int hascrc;
    int isdir;
    int encrypted;               /* zip: ZipCrypto (precisa de senha) */
    int status;                  /* AST_* */
} ArcEntry;

typedef struct {
    ArcEntry *v;
    int n, cap;
    int type;
    char err[96];
} ArcList;

typedef struct {
    int ok, skipped, failed;
    char lasterr[96];
} ArcResult;

/* senha usada ao extrair/criar ZIP (ZipCrypto); vazia = sem senha */
extern char arc_password[64];
int  arc_needs_password(const char *path);               /* 1 se ha entradas ZIP protegidas */

/* uso interno (rarlib) */
ArcEntry *arc_list_add(ArcList *al);
int  arc_safe_name(const char *in, char *out, int sz);

int  arc_detect(const char *path);                       /* ARC_* pelo conteudo */
int  arc_list(const char *path, ArcList *al);            /* FS_OK / FS_ERR (al->err) */
void arc_free(ArcList *al);
const char *arc_status_text(const ArcEntry *e);          /* "" se extraivel */

/* index = -1 extrai tudo. overwrite = 0 pula arquivos que ja existem. */
int  arc_extract(const char *path, const char *destdir, int index, int overwrite, ArcResult *res);

/* cria um ZIP com os caminhos de srcs (arquivos ou pastas, recursivo) */
int  zip_create(const char *outpath, char **srcs, int nsrc, ArcResult *res);

#ifdef __cplusplus
}
#endif

#endif
