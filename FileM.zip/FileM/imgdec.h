#ifndef IMGDEC_H
#define IMGDEC_H

/* Decodificador de imagens: PNG (libpng), JPEG (libjpeg) e BMP (proprio).
 * Imagens muito grandes sao reduzidas por um passo inteiro para caber na memoria. */

enum { IMG_NONE = 0, IMG_PNG, IMG_JPG, IMG_BMP };

typedef struct {
    unsigned *px;      /* pixels 0xAABBGGRR, w*h */
    int w, h;          /* tamanho guardado (apos reducao) */
    int ow, oh;        /* tamanho original */
    int step;          /* fator de reducao (1 = sem reducao) */
} Image;

int  img_type(const char *name);                                /* pela extensao */
int  img_decode(const char *path, Image *im, char *err, int esz);   /* 1 = ok */
void img_free(Image *im);

#endif
