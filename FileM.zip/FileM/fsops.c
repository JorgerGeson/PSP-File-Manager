#include <pspkernel.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "fsops.h"

#define COPY_BUF (128 * 1024)

int (*fs_progress)(const char *, unsigned long long, unsigned long long) = NULL;
static unsigned char *g_buf = NULL;

/* =============== listagem =============== */
static Entry *dl_add(DirList *dl)
{
    if (dl->n >= dl->cap) {
        int nc = dl->cap ? dl->cap * 2 : 64;
        Entry *nv = realloc(dl->v, nc * sizeof(Entry));
        if (!nv) return NULL;
        dl->v = nv;
        dl->cap = nc;
    }
    Entry *e = &dl->v[dl->n++];
    memset(e, 0, sizeof(*e));
    return e;
}

int dir_load(const char *path, DirList *dl, int with_updir)
{
    dl->v = NULL;
    dl->n = 0;
    dl->cap = 0;

    SceUID d = sceIoDopen(path);
    if (d < 0) return FS_ERR;

    if (with_updir) {
        Entry *u = dl_add(dl);
        if (u) {
            strcpy(u->name, "..");
            u->isdir = 1;
        }
    }

    SceIoDirent ent;
    for (;;) {
        memset(&ent, 0, sizeof(ent));
        int r = sceIoDread(d, &ent);
        if (r <= 0) break;
        if (!strcmp(ent.d_name, ".") || !strcmp(ent.d_name, "..")) continue;

        Entry *e = dl_add(dl);
        if (!e) break;
        strncpy(e->name, ent.d_name, sizeof(e->name) - 1);
        e->isdir = FIO_S_ISDIR(ent.d_stat.st_mode) ? 1 : 0;
        e->size = (unsigned long long)ent.d_stat.st_size;
        e->mtime = ent.d_stat.sce_st_mtime;
        e->mkey = ((((((unsigned long long)e->mtime.year * 13 + e->mtime.month) * 32 +
                      e->mtime.day) * 24 + e->mtime.hour) * 60 + e->mtime.minute) * 60 +
                   e->mtime.second);
    }
    sceIoDclose(d);
    return FS_OK;
}

void dir_free(DirList *dl)
{
    if (dl->v) free(dl->v);
    dl->v = NULL;
    dl->n = 0;
    dl->cap = 0;
}

static int s_mode = SORT_NAME;

static int cmp_entries(const void *pa, const void *pb)
{
    const Entry *a = (const Entry *)pa;
    const Entry *b = (const Entry *)pb;

    if (a->isdir != b->isdir) return b->isdir - a->isdir;   /* pastas primeiro */

    if (s_mode == SORT_DATE) {
        if (a->mkey != b->mkey) return (a->mkey < b->mkey) ? 1 : -1;   /* mais novo primeiro */
    } else if (s_mode == SORT_SIZE && !a->isdir) {
        if (a->size != b->size) return (a->size < b->size) ? 1 : -1;    /* maior primeiro */
    }
    return strcasecmp(a->name, b->name);
}

void dir_sort(DirList *dl, int mode)
{
    int start = (dl->n > 0 && !strcmp(dl->v[0].name, "..")) ? 1 : 0;
    s_mode = mode;
    if (dl->n - start > 1)
        qsort(dl->v + start, dl->n - start, sizeof(Entry), cmp_entries);
}

int dir_find(const DirList *dl, const char *name)
{
    for (int i = 0; i < dl->n; i++)
        if (!strcmp(dl->v[i].name, name)) return i;
    return -1;
}

/* =============== caminhos =============== */
void path_join(char *out, int sz, const char *dir, const char *name)
{
    int n = (int)strlen(dir);
    if (n > 0 && dir[n - 1] == '/') snprintf(out, sz, "%s%s", dir, name);
    else                            snprintf(out, sz, "%s/%s", dir, name);
}

void path_parent(char *p)
{
    int n = (int)strlen(p);
    while (n > 0 && p[n - 1] == '/') n--;
    while (n > 0 && p[n - 1] != '/' && p[n - 1] != ':') n--;
    while (n > 1 && p[n - 1] == '/' && p[n - 2] != ':') n--;
    p[n] = 0;
    if (n > 0 && p[n - 1] == ':') {
        p[n] = '/';
        p[n + 1] = 0;
    }
}

const char *path_base(const char *path)
{
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

int path_is_root(const char *p)
{
    const char *c = strchr(p, ':');
    if (!c) return 0;
    return (c[1] == 0) || (c[1] == '/' && c[2] == 0);
}

int path_is_ro(const char *path)
{
    return !strncmp(path, "flash", 5) || !strncmp(path, "umd", 3) || !strncmp(path, "disc", 4);
}

int path_inside(const char *child, const char *parent)
{
    int n = (int)strlen(parent);
    while (n > 0 && parent[n - 1] == '/') n--;
    return strncmp(child, parent, n) == 0 && (child[n] == '/' || child[n] == 0);
}

/* =============== operacoes =============== */
int fs_exists(const char *path)
{
    SceIoStat st;
    return sceIoGetstat(path, &st) >= 0;
}

void fs_unique(char *path, int sz)
{
    if (!fs_exists(path)) return;

    char orig[512];
    char ext[64] = "";
    snprintf(orig, sizeof(orig), "%s", path);

    char *slash = strrchr(orig, '/');
    char *dot = strrchr(orig, '.');
    if (dot && (!slash || dot > slash + 1)) {
        snprintf(ext, sizeof(ext), "%s", dot);
        *dot = 0;
    }
    for (int i = 1; i < 1000; i++) {
        if (i == 1) snprintf(path, sz, "%s_copia%s", orig, ext);
        else        snprintf(path, sz, "%s_copia%d%s", orig, i, ext);
        if (!fs_exists(path)) return;
    }
}

static int copy_file(const char *src, const char *dst)
{
    SceIoStat st;
    unsigned long long total = 0;
    if (sceIoGetstat(src, &st) >= 0) total = (unsigned long long)st.st_size;

    SceUID in = sceIoOpen(src, PSP_O_RDONLY, 0);
    if (in < 0) return FS_ERR;
    SceUID out = sceIoOpen(dst, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (out < 0) {
        sceIoClose(in);
        return FS_ERR;
    }
    if (!g_buf) g_buf = (unsigned char *)malloc(COPY_BUF);
    if (!g_buf) {
        sceIoClose(in);
        sceIoClose(out);
        return FS_ERR;
    }

    unsigned long long done = 0;
    int res = FS_OK;
    for (;;) {
        int n = sceIoRead(in, g_buf, COPY_BUF);
        if (n < 0) { res = FS_ERR; break; }
        if (n == 0) break;
        int w = sceIoWrite(out, g_buf, n);
        if (w != n) { res = FS_ERR; break; }   /* disco cheio, por exemplo */
        done += (unsigned long long)n;
        if (fs_progress && fs_progress(path_base(src), done, total)) { res = FS_CANCEL; break; }
    }
    sceIoClose(in);
    sceIoClose(out);
    if (res != FS_OK) sceIoRemove(dst);        /* nao deixa arquivo pela metade */
    return res;
}

int fs_copy(const char *src, const char *dst)
{
    SceIoStat st;
    if (sceIoGetstat(src, &st) < 0) return FS_ERR;
    if (!FIO_S_ISDIR(st.st_mode)) return copy_file(src, dst);

    if (path_inside(dst, src)) return FS_ERR;  /* pasta dentro dela mesma */
    sceIoMkdir(dst, 0777);

    DirList dl;
    if (dir_load(src, &dl, 0) != FS_OK) return FS_ERR;

    int res = FS_OK;
    for (int i = 0; i < dl.n; i++) {
        char s[512], d[512];
        path_join(s, sizeof(s), src, dl.v[i].name);
        path_join(d, sizeof(d), dst, dl.v[i].name);
        int r = fs_copy(s, d);
        if (r == FS_CANCEL) { res = FS_CANCEL; break; }
        if (r != FS_OK) res = FS_ERR;
    }
    dir_free(&dl);
    return res;
}

int fs_delete(const char *path)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) return FS_ERR;

    if (fs_progress && fs_progress(path_base(path), 0, 0)) return FS_CANCEL;

    if (!FIO_S_ISDIR(st.st_mode))
        return (sceIoRemove(path) >= 0) ? FS_OK : FS_ERR;

    DirList dl;
    if (dir_load(path, &dl, 0) != FS_OK) return FS_ERR;

    int res = FS_OK;
    for (int i = 0; i < dl.n; i++) {
        char c[512];
        path_join(c, sizeof(c), path, dl.v[i].name);
        int r = fs_delete(c);
        if (r == FS_CANCEL) { res = FS_CANCEL; break; }
        if (r != FS_OK) res = FS_ERR;
    }
    dir_free(&dl);
    if (res == FS_OK) res = (sceIoRmdir(path) >= 0) ? FS_OK : FS_ERR;
    return res;
}

int fs_move(const char *src, const char *dst)
{
    /* mesma particao: renomear e instantaneo */
    if (sceIoRename(src, dst) >= 0) return FS_OK;
    /* outra particao: copia e apaga a origem */
    int r = fs_copy(src, dst);
    if (r != FS_OK) return r;
    return fs_delete(src);
}

void fs_tree_size(const char *path, unsigned long long *bytes, int *files, int *dirs)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) return;

    if (!FIO_S_ISDIR(st.st_mode)) {
        *bytes += (unsigned long long)st.st_size;
        (*files)++;
        return;
    }
    (*dirs)++;
    DirList dl;
    if (dir_load(path, &dl, 0) != FS_OK) return;
    for (int i = 0; i < dl.n; i++) {
        char c[512];
        path_join(c, sizeof(c), path, dl.v[i].name);
        fs_tree_size(c, bytes, files, dirs);
    }
    dir_free(&dl);
}

/* espaco livre/total via devctl (funciona em ms0:/ef0:) */
typedef struct {
    unsigned int maxClusters;
    unsigned int freeClusters;
    int          unk1;
    unsigned int sectorSize;
    unsigned int sectorCount;   /* setores por cluster */
} DevInfo;

typedef struct { DevInfo *info; } DevArg;

int fs_devinfo(const char *path, unsigned long long *freeb, unsigned long long *totalb)
{
    char dev[16];
    const char *c = strchr(path, ':');
    if (!c || (c - path) > 10) return FS_ERR;
    memcpy(dev, path, (size_t)(c - path + 1));
    dev[c - path + 1] = 0;

    DevInfo di;
    DevArg arg;
    memset(&di, 0, sizeof(di));
    arg.info = &di;
    if (sceIoDevctl(dev, 0x02425818, &arg, sizeof(arg), NULL, 0) < 0) return FS_ERR;

    unsigned long long cl = (unsigned long long)di.sectorCount * di.sectorSize;
    *freeb = (unsigned long long)di.freeClusters * cl;
    *totalb = (unsigned long long)di.maxClusters * cl;
    return FS_OK;
}


/* =============== apoio: pastas, stat, caminhos =============== */
int fs_mkpath(const char *dir)
{
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    int n = (int)strlen(tmp);
    while (n > 0 && tmp[n - 1] == '/') tmp[--n] = 0;

    char *start = strchr(tmp, ':');
    start = start ? start + 1 : tmp;
    while (*start == '/') start++;

    for (char *p = start; *p; p++) {
        if (*p == '/') {
            *p = 0;
            if (!fs_exists(tmp)) sceIoMkdir(tmp, 0777);
            *p = '/';
        }
    }
    if (!fs_exists(tmp)) sceIoMkdir(tmp, 0777);
    return fs_exists(tmp) ? FS_OK : FS_ERR;
}

int fs_stat_info(const char *path, int *isdir, unsigned long long *size,
                 unsigned *dosdate, unsigned *dostime)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) return FS_ERR;
    if (isdir) *isdir = FIO_S_ISDIR(st.st_mode) ? 1 : 0;
    if (size) *size = (unsigned long long)st.st_size;
    int y = st.sce_st_mtime.year;
    if (y < 1980) y = 1980;
    if (dosdate) *dosdate = (unsigned)(((y - 1980) << 9) | (st.sce_st_mtime.month << 5) | st.sce_st_mtime.day);
    if (dostime) *dostime = (unsigned)((st.sce_st_mtime.hour << 11) | (st.sce_st_mtime.minute << 5) |
                                       (st.sce_st_mtime.second / 2));
    return FS_OK;
}

void *fs_dir_open(const char *path)
{
    SceUID d = sceIoDopen(path);
    if (d < 0) return NULL;
    SceUID *h = (SceUID *)malloc(sizeof(SceUID));
    if (!h) { sceIoDclose(d); return NULL; }
    *h = d;
    return h;
}

int fs_dir_next(void *hh, char *name, int sz)
{
    SceUID *h = (SceUID *)hh;
    SceIoDirent ent;
    for (;;) {
        memset(&ent, 0, sizeof(ent));
        int r = sceIoDread(*h, &ent);
        if (r <= 0) return 0;
        if (!strcmp(ent.d_name, ".") || !strcmp(ent.d_name, "..")) continue;
        snprintf(name, sz, "%s", ent.d_name);
        return 1;
    }
}

void fs_dir_close(void *hh)
{
    SceUID *h = (SceUID *)hh;
    if (!h) return;
    sceIoDclose(*h);
    free(h);
}

/* resolve "arg" em relacao a "cwd": aceita dev:/x, /x (mesmo drive), x, ., .. */
void path_resolve(char *out, int sz, const char *cwd, const char *arg)
{
    char full[1024];
    const char *colon = strchr(arg, ':');
    const char *slash = strchr(arg, '/');

    if (colon && (!slash || colon < slash)) {
        snprintf(full, sizeof(full), "%s", arg);
    } else if (arg[0] == '/') {
        const char *c = strchr(cwd, ':');
        int dl = c ? (int)(c - cwd) + 1 : 0;
        snprintf(full, sizeof(full), "%.*s%s", dl, cwd, arg);
    } else {
        path_join(full, sizeof(full), cwd, arg);
    }

    /* separa "dev:" do resto e normaliza os componentes */
    char dev[16] = "";
    char *rest = full;
    char *c = strchr(full, ':');
    if (c && (c - full) < 12) {
        int dl = (int)(c - full) + 1;
        memcpy(dev, full, (size_t)dl);
        dev[dl] = 0;
        rest = c + 1;
    }

    char *comp[64];
    int nc = 0;
    char *save = NULL;
    for (char *t = strtok_r(rest, "/", &save); t; t = strtok_r(NULL, "/", &save)) {
        if (!strcmp(t, ".") || !*t) continue;
        if (!strcmp(t, "..")) { if (nc > 0) nc--; continue; }
        if (nc < 64) comp[nc++] = t;
    }
    int o = snprintf(out, sz, "%s/", dev);
    for (int i = 0; i < nc && o < sz - 1; i++) {
        o += snprintf(out + o, sz - o, "%s%s", comp[i], (i < nc - 1) ? "/" : "");
    }
}
