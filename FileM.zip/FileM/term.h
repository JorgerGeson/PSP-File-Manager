#ifndef TERM_H
#define TERM_H
void terminal_run(const char *startdir);
#endif
