/*
 * PSP File Manager - gerenciador de arquivos em modo texto
 *
 * Navegacao:   Cima/Baixo mover | L/R pagina | Esq/Dir topo/fim
 *              X abrir | O voltar | Quadrado marcar | Triangulo menu
 *              Select drives | Start recarregar | HOME sair
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include "ui.h"
#include "fsops.h"
#include "viewer.h"
#include "editor.h"
#include "term.h"
#include "imgview.h"
#include "audio.h"
#include "arch.h"

PSP_MODULE_INFO("PSPFileManager", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);

#define LIST_TOP  3
#define LIST_ROWS 28

/* ---------- estado ---------- */
static DirList g_dl;
static char    cwd[512] = "ms0:/";
static int     g_cur = 0, g_top = 0;
static int     g_sort = SORT_NAME;

static char  **g_clip = NULL;
static int     g_nclip = 0;
static int     g_clipcut = 0;

static char g_status[100] = "";
static char g_free[24] = "?", g_total[24] = "?";
static char g_sep[UI_W + 1];

/* ---------- callback de saida (botao HOME) ---------- */
static int exit_cb(int a1, int a2, void *c)
{
    sceKernelExitGame();
    return 0;
}

static int cb_thread(SceSize args, void *argp)
{
    int id = sceKernelCreateCallback("exit", exit_cb, NULL);
    sceKernelRegisterExitCallback(id);
    sceKernelSleepThreadCB();
    return 0;
}

static void setup_callbacks(void)
{
    int t = sceKernelCreateThread("cb", cb_thread, 0x11, 0xFA0, 0, NULL);
    if (t >= 0) sceKernelStartThread(t, 0, NULL);
}

/* ---------- utilidades ---------- */
static void set_status(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_status, sizeof(g_status), fmt, ap);
    va_end(ap);
}

static void refresh_space(void)
{
    unsigned long long f, t;
    if (fs_devinfo(cwd, &f, &t) == FS_OK) {
        fmt_size(g_free, f);
        fmt_size(g_total, t);
    } else {
        strcpy(g_free, "?");
        strcpy(g_total, "?");
    }
}

static void clamp_view(void)
{
    if (g_dl.n == 0) { g_cur = 0; g_top = 0; return; }
    if (g_cur < 0) g_cur = 0;
    if (g_cur >= g_dl.n) g_cur = g_dl.n - 1;
    if (g_cur < g_top) g_top = g_cur;
    if (g_cur >= g_top + LIST_ROWS) g_top = g_cur - LIST_ROWS + 1;
    if (g_top < 0) g_top = 0;
}

static int count_marked(void)
{
    int c = 0;
    for (int i = 0; i < g_dl.n; i++) if (g_dl.v[i].marked) c++;
    return c;
}

/* troca de pasta; mantem o estado antigo se falhar */
static int change_dir(const char *newpath, const char *select_name)
{
    DirList nd;
    char np[512];
    snprintf(np, sizeof(np), "%s", newpath);

    if (dir_load(np, &nd, !path_is_root(np)) != FS_OK) return FS_ERR;

    dir_free(&g_dl);
    g_dl = nd;
    snprintf(cwd, sizeof(cwd), "%s", np);
    dir_sort(&g_dl, g_sort);

    g_cur = 0;
    g_top = 0;
    if (select_name) {
        int i = dir_find(&g_dl, select_name);
        if (i >= 0) g_cur = i;
    }
    return FS_OK;
}

static void reload_dir(void)
{
    char keep[256] = "";
    if (g_dl.n > 0) snprintf(keep, sizeof(keep), "%s", g_dl.v[g_cur].name);
    int oldtop = g_top;
    if (change_dir(cwd, keep[0] ? keep : NULL) == FS_OK) {
        g_top = oldtop;
        refresh_space();
    } else {
        set_status("Erro ao recarregar a pasta");
    }
}

/* ---------- desenho ---------- */
static void draw_main(void)
{
    ui_line(0, C_BLACK, C_CYAN, " PSP File Manager     livre: %s / %s", g_free, g_total);

    int L = (int)strlen(cwd);
    if (L > 64) ui_line(1, C_YELLOW, C_BLACK, " ...%s", cwd + L - 61);
    else        ui_line(1, C_YELLOW, C_BLACK, " %s", cwd);

    ui_line(2, C_GRAY, C_BLACK, "  %-36s %9s  %s", "Nome", "Tamanho", "Modificado");

    for (int i = 0; i < LIST_ROWS; i++) {
        int k = g_top + i;
        int row = LIST_TOP + i;
        if (k >= g_dl.n) {
            ui_line(row, C_WHITE, C_BLACK, "");
            continue;
        }
        Entry *e = &g_dl.v[k];
        int isup = !strcmp(e->name, "..");
        char nm[270], sz[24], dt[24];

        snprintf(nm, sizeof(nm), "%s%s", e->name, (e->isdir && !isup) ? "/" : "");
        if (e->isdir) snprintf(sz, sizeof(sz), "%s", isup ? "" : "<DIR>");
        else          fmt_size(sz, e->size);

        if (isup || e->mtime.year == 0) dt[0] = 0;
        else snprintf(dt, sizeof(dt), "%04d-%02d-%02d %02d:%02d", (int)e->mtime.year,
                      (int)e->mtime.month, (int)e->mtime.day, (int)e->mtime.hour,
                      (int)e->mtime.minute);

        unsigned fg = e->marked ? C_GREEN : (e->isdir ? C_YELLOW : C_WHITE);
        unsigned bg = (k == g_cur) ? C_GRAY : C_BLACK;
        ui_line(row, fg, bg, "%c%c%-36.36s %9s  %s", (k == g_cur) ? '>' : ' ',
                e->marked ? '*' : ' ', nm, sz, dt);
    }

    ui_line(31, C_GRAY, C_BLACK, "%s", g_sep);
    ui_line(32, C_CYAN, C_BLACK, " %d itens | %d marcados | area: %d%s", g_dl.n > 0 && !strcmp(g_dl.v[0].name, "..") ? g_dl.n - 1 : g_dl.n,
            count_marked(), g_nclip, g_nclip ? (g_clipcut ? " (mover)" : " (copiar)") : "");

    if (g_status[0]) ui_line(33, C_BLACK, C_YELLOW, " %s", g_status);
    else ui_line(33, C_GRAY, C_BLACK, " X:abrir O:voltar Quad:marcar Tri:menu Sel:drives Start:recarregar");
}

/* ---------- alvos ---------- */
static char *make_path(const Entry *e)
{
    char *p = (char *)malloc(512);
    if (p) path_join(p, 512, cwd, e->name);
    return p;
}

static void free_list(char **l, int n)
{
    if (!l) return;
    for (int i = 0; i < n; i++) free(l[i]);
    free(l);
}

/* itens marcados, ou o item sob o cursor se nada estiver marcado */
static int gather(char ***out)
{
    int cnt = count_marked();
    int single = 0;
    *out = NULL;

    if (cnt == 0) {
        if (g_dl.n > 0 && strcmp(g_dl.v[g_cur].name, "..") != 0) { cnt = 1; single = 1; }
        else return 0;
    }
    char **l = (char **)calloc((size_t)cnt, sizeof(char *));
    if (!l) return 0;

    int k = 0;
    if (single) {
        l[k++] = make_path(&g_dl.v[g_cur]);
    } else {
        for (int i = 0; i < g_dl.n && k < cnt; i++)
            if (g_dl.v[i].marked) l[k++] = make_path(&g_dl.v[i]);
    }
    *out = l;
    return cnt;
}

static void clip_clear(void)
{
    free_list(g_clip, g_nclip);
    g_clip = NULL;
    g_nclip = 0;
}

static void unmark_all(void)
{
    for (int i = 0; i < g_dl.n; i++) g_dl.v[i].marked = 0;
}

/* ---------- acoes ---------- */
static void action_copycut(int cut)
{
    char **l;
    int n = gather(&l);
    if (n == 0) { set_status("Nada selecionado"); return; }

    if (cut) {
        for (int i = 0; i < n; i++)
            if (path_is_ro(l[i])) {
                free_list(l, n);
                set_status("Origem somente leitura: nao e possivel mover");
                return;
            }
    }
    clip_clear();
    g_clip = l;
    g_nclip = n;
    g_clipcut = cut;
    unmark_all();
    set_status("%d item(ns) na area de transferencia (%s)", n, cut ? "mover" : "copiar");
}

static void action_paste(void)
{
    if (!g_nclip) { set_status("Area de transferencia vazia"); return; }
    if (path_is_ro(cwd)) { set_status("Destino somente leitura"); return; }

    int ok = 0, err = 0, canceled = 0;
    for (int i = 0; i < g_nclip; i++) {
        char dst[512], op[64];
        path_join(dst, sizeof(dst), cwd, path_base(g_clip[i]));
        snprintf(op, sizeof(op), "%s (%d/%d)", g_clipcut ? "Movendo" : "Copiando", i + 1, g_nclip);
        ui_set_op(op);

        int r;
        if (g_clipcut) {
            if (strcmp(g_clip[i], dst) == 0) { ok++; continue; }   /* ja esta aqui */
            if (fs_exists(dst)) fs_unique(dst, sizeof(dst));
            if (path_inside(dst, g_clip[i])) { err++; continue; }
            r = fs_move(g_clip[i], dst);
        } else {
            if (fs_exists(dst)) fs_unique(dst, sizeof(dst));
            if (path_inside(dst, g_clip[i])) { err++; continue; }
            r = fs_copy(g_clip[i], dst);
        }
        if (r == FS_OK) ok++;
        else if (r == FS_CANCEL) { canceled = 1; break; }
        else err++;
    }
    if (g_clipcut && ok > 0) clip_clear();
    reload_dir();
    set_status("Colar: %d ok, %d erro(s)%s", ok, err, canceled ? " - cancelado" : "");
}

static void action_delete(void)
{
    char **l;
    int n = gather(&l);
    if (n == 0) { set_status("Nada selecionado"); return; }

    for (int i = 0; i < n; i++)
        if (path_is_ro(l[i])) {
            free_list(l, n);
            set_status("Somente leitura: exclusao bloqueada");
            return;
        }

    char l1[96], l2[96];
    snprintf(l1, sizeof(l1), "Excluir %d item(ns) permanentemente?", n);
    if (n == 1) snprintf(l2, sizeof(l2), "%s", path_base(l[0]));
    else        snprintf(l2, sizeof(l2), "%s e mais %d...", path_base(l[0]), n - 1);

    if (!ui_confirm(l1, l2)) {
        free_list(l, n);
        set_status("Exclusao cancelada");
        return;
    }

    int ok = 0, err = 0, canceled = 0;
    for (int i = 0; i < n; i++) {
        char op[64];
        snprintf(op, sizeof(op), "Excluindo (%d/%d)", i + 1, n);
        ui_set_op(op);
        int r = fs_delete(l[i]);
        if (r == FS_OK) ok++;
        else if (r == FS_CANCEL) { canceled = 1; break; }
        else err++;
    }
    free_list(l, n);
    clip_clear();
    reload_dir();
    set_status("Excluir: %d ok, %d erro(s)%s", ok, err, canceled ? " - cancelado" : "");
}

static void action_rename(void)
{
    if (g_dl.n == 0 || !strcmp(g_dl.v[g_cur].name, "..")) { set_status("Nada para renomear"); return; }
    if (path_is_ro(cwd)) { set_status("Somente leitura"); return; }

    char buf[128];
    snprintf(buf, sizeof(buf), "%s", g_dl.v[g_cur].name);
    char oldname[256];
    snprintf(oldname, sizeof(oldname), "%s", g_dl.v[g_cur].name);

    if (!ui_input_text("Renomear", buf, sizeof(buf))) { set_status("Cancelado"); return; }

    char oldp[512], newp[512];
    path_join(oldp, sizeof(oldp), cwd, oldname);
    path_join(newp, sizeof(newp), cwd, buf);
    if (fs_exists(newp) && strcasecmp(oldname, buf) != 0) { set_status("Ja existe um item com esse nome"); return; }

    if (sceIoRename(oldp, newp) >= 0) {
        char keep[128];
        snprintf(keep, sizeof(keep), "%s", buf);
        if (change_dir(cwd, keep) == FS_OK) refresh_space();
        set_status("Renomeado para %s", buf);
    } else {
        set_status("Erro ao renomear");
    }
}

static void action_mkdir(void)
{
    if (path_is_ro(cwd)) { set_status("Somente leitura"); return; }
    char buf[128] = "";
    if (!ui_input_text("Nova pasta", buf, sizeof(buf))) { set_status("Cancelado"); return; }
    char p[512];
    path_join(p, sizeof(p), cwd, buf);
    if (fs_exists(p)) { set_status("Ja existe"); return; }
    if (sceIoMkdir(p, 0777) >= 0) {
        change_dir(cwd, buf);
        refresh_space();
        set_status("Pasta criada: %s", buf);
    } else {
        set_status("Erro ao criar a pasta");
    }
}

static void action_newfile(void)
{
    if (path_is_ro(cwd)) { set_status("Somente leitura"); return; }
    char buf[128] = "";
    if (!ui_input_text("Novo arquivo vazio", buf, sizeof(buf))) { set_status("Cancelado"); return; }
    char p[512];
    path_join(p, sizeof(p), cwd, buf);
    if (fs_exists(p)) { set_status("Ja existe"); return; }
    SceUID fd = sceIoOpen(p, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (fd >= 0) {
        sceIoClose(fd);
        change_dir(cwd, buf);
        refresh_space();
        set_status("Arquivo criado: %s", buf);
    } else {
        set_status("Erro ao criar o arquivo");
    }
}

static void action_props(void)
{
    char **l;
    int n = gather(&l);
    if (n == 0) { set_status("Nada selecionado"); return; }

    ui_clear();
    ui_line(0, C_BLACK, C_CYAN, " Propriedades");
    ui_line(2, C_YELLOW, C_BLACK, " Calculando...");

    unsigned long long bytes = 0;
    int files = 0, dirs = 0;
    for (int i = 0; i < n; i++) fs_tree_size(l[i], &bytes, &files, &dirs);

    char sz[24];
    fmt_size(sz, bytes);
    ui_clear();
    ui_line(0, C_BLACK, C_CYAN, " Propriedades");

    int row = 2;
    SceIoStat st;
    if (n == 1 && sceIoGetstat(l[0], &st) >= 0) {
        int isdir = FIO_S_ISDIR(st.st_mode) ? 1 : 0;
        ui_line(row++, C_WHITE, C_BLACK, " Nome:      %s", path_base(l[0]));
        ui_line(row++, C_WHITE, C_BLACK, " Local:     %s", cwd);
        ui_line(row++, C_WHITE, C_BLACK, " Tipo:      %s", isdir ? "Pasta" : "Arquivo");
        ui_line(row++, C_WHITE, C_BLACK, " Tamanho:   %s (%llu bytes)", sz, bytes);
        if (isdir)
            ui_line(row++, C_WHITE, C_BLACK, " Conteudo:  %d arquivo(s), %d subpasta(s)", files, dirs > 0 ? dirs - 1 : 0);
        row++;
        ui_line(row++, C_WHITE, C_BLACK, " Criado:    %04d-%02d-%02d %02d:%02d:%02d", (int)st.sce_st_ctime.year,
                (int)st.sce_st_ctime.month, (int)st.sce_st_ctime.day, (int)st.sce_st_ctime.hour,
                (int)st.sce_st_ctime.minute, (int)st.sce_st_ctime.second);
        ui_line(row++, C_WHITE, C_BLACK, " Modificado:%04d-%02d-%02d %02d:%02d:%02d", (int)st.sce_st_mtime.year,
                (int)st.sce_st_mtime.month, (int)st.sce_st_mtime.day, (int)st.sce_st_mtime.hour,
                (int)st.sce_st_mtime.minute, (int)st.sce_st_mtime.second);
    } else {
        ui_line(row++, C_WHITE, C_BLACK, " %d itens selecionados", n);
        ui_line(row++, C_WHITE, C_BLACK, " Tamanho total: %s (%llu bytes)", sz, bytes);
        ui_line(row++, C_WHITE, C_BLACK, " Total: %d arquivo(s), %d pasta(s)", files, dirs);
    }
    row++;
    ui_line(row++, C_CYAN, C_BLACK, " Espaco livre: %s de %s", g_free, g_total);
    ui_line(33, C_GRAY, C_BLACK, " Pressione X ou O para voltar");
    free_list(l, n);

    for (;;) {
        unsigned p = ui_wait();
        if (p & (PSP_CTRL_CROSS | PSP_CTRL_CIRCLE)) break;
    }
}

static int is_text_ext(const char *name)
{
    static const char *exts[] = { "txt", "ini", "cfg", "log", "c", "h", "cpp", "md", "xml",
                                  "json", "lua", "py", "sh", "csv", "conf", "html", "htm",
                                  "nfo", "bat", "js", "css", "yml", "yaml", "lst" };
    const char *dot = strrchr(name, '.');
    if (!dot) return 0;
    for (unsigned i = 0; i < sizeof(exts) / sizeof(exts[0]); i++)
        if (!strcasecmp(dot + 1, exts[i])) return 1;
    return 0;
}

static void action_view(int hex)
{
    if (g_dl.n == 0) return;
    Entry *e = &g_dl.v[g_cur];
    if (e->isdir) { set_status("Selecione um arquivo"); return; }
    char fp[512];
    path_join(fp, sizeof(fp), cwd, e->name);
    if (hex) view_hex(fp);
    else     view_text(fp);
}


/* ---------- arquivos compactados ---------- */
static void arc_report(const char *what, int r, const ArcResult *res)
{
    if (r == FS_CANCEL) set_status("%s: cancelado", what);
    else if (r != FS_OK) set_status("%s: erro - %.60s", what, res->lasterr);
    else set_status("%s: %d ok, %d pulado(s), %d falha(s)%s%.40s", what, res->ok, res->skipped, res->failed,
                    res->failed ? " - " : "", res->failed ? res->lasterr : "");
}

static void arc_extract_to(const char *arc, const char *dest, int index)
{
    if (path_is_ro(dest)) { set_status("Destino somente leitura"); return; }
    arc_password[0] = 0;
    if (arc_needs_password(arc)) {
        char pw[64] = "";
        if (!ui_input_text("Senha do arquivo ZIP", pw, sizeof(pw))) { ui_clear(); set_status("Cancelado"); return; }
        snprintf(arc_password, sizeof(arc_password), "%s", pw);
        ui_clear();
    }
    int ow = ui_confirm("Arquivos que ja existem:", "X = sobrescrever   O = pular");
    ui_set_op("Extraindo");
    ArcResult res;
    int r = arc_extract(arc, dest, index, ow, &res);
    arc_password[0] = 0;
    reload_dir();
    arc_report("Extrair", r, &res);
}

static void arc_browse(const char *arc)
{
    ArcList al;
    arc_password[0] = 0;
    int lr = arc_list(arc, &al);
    if (lr != FS_OK && strstr(al.err, "enha")) {          /* cabecalhos criptografados */
        char pw[64] = "";
        if (ui_input_text("Senha do arquivo", pw, sizeof(pw))) {
            snprintf(arc_password, sizeof(arc_password), "%s", pw);
            lr = arc_list(arc, &al);
        }
        ui_clear();
    }
    if (lr != FS_OK) { arc_password[0] = 0; ui_message(al.err, "", C_RED); return; }
    int cur = 0, top = 0;
    const int rows = 30;
    ui_clear();
    for (;;) {
        if (al.n == 0) { ui_message("Arquivo vazio.", "", C_YELLOW); break; }
        if (cur < top) top = cur;
        if (cur >= top + rows) top = cur - rows + 1;
        ui_line(0, C_BLACK, C_CYAN, " %s  [%s] %d entradas", path_base(arc),
                al.type == ARC_ZIP ? "ZIP" : (al.type == ARC_RAR4 ? "RAR4" : "RAR5"), al.n);
        for (int i = 0; i < rows; i++) {
            int k = top + i;
            if (k >= al.n) { ui_line(1 + i, C_WHITE, C_BLACK, ""); continue; }
            ArcEntry *e = &al.v[k];
            char sz[24];
            fmt_size(sz, e->usize);
            unsigned fg = e->status ? C_ORANGE : (e->isdir ? C_YELLOW : C_WHITE);
            ui_line(1 + i, fg, (k == cur) ? C_GRAY : C_BLACK, "%c%-50.50s %9s%s", (k == cur) ? '>' : ' ',
                    e->name, e->isdir ? "<DIR>" : sz, e->status ? " !" : "");
        }
        ArcEntry *c = &al.v[cur];
        if (c->status) ui_line(32, C_BLACK, C_ORANGE, " %s", arc_status_text(c));
        else           ui_line(32, C_GRAY, C_BLACK, "");
        ui_line(33, C_GRAY, C_BLACK, " X:extrair esta entrada aqui  Start:extrair tudo aqui  O:voltar");

        unsigned p = ui_wait();
        if (p & PSP_CTRL_UP)       cur = (cur > 0) ? cur - 1 : al.n - 1;
        if (p & PSP_CTRL_DOWN)     cur = (cur < al.n - 1) ? cur + 1 : 0;
        if (p & PSP_CTRL_LTRIGGER) cur = (cur > rows) ? cur - rows : 0;
        if (p & PSP_CTRL_RTRIGGER) cur = (cur + rows < al.n) ? cur + rows : al.n - 1;
        if (p & PSP_CTRL_CIRCLE) break;
        if (p & PSP_CTRL_CROSS) { char keep[64]; snprintf(keep, sizeof(keep), "%s", arc_password); arc_extract_to(arc, cwd, cur); snprintf(arc_password, sizeof(arc_password), "%s", keep); ui_clear(); }
        if (p & PSP_CTRL_START) { arc_extract_to(arc, cwd, -1); ui_clear(); }
    }
    arc_free(&al);
    arc_password[0] = 0;
}

static void action_archive(const char *arc)
{
    static const char *items[] = { "Ver conteudo", "Extrair aqui", "Extrair para pasta com o nome do arquivo" };
    int s = ui_menu("Arquivo compactado", items, 3, 0);
    if (s == 0) arc_browse(arc);
    else if (s == 1) arc_extract_to(arc, cwd, -1);
    else if (s == 2) {
        char d[512], nm[256];
        snprintf(nm, sizeof(nm), "%s", path_base(arc));
        char *dot = strrchr(nm, '.');
        if (dot && dot != nm) *dot = 0;
        path_join(d, sizeof(d), cwd, nm);
        arc_extract_to(arc, d, -1);
    }
}

static void action_zip(void)
{
    char **l;
    int n = gather(&l);
    if (n == 0) { set_status("Nada selecionado"); return; }
    if (path_is_ro(cwd)) { free_list(l, n); set_status("Destino somente leitura"); return; }

    char buf[128];
    snprintf(buf, sizeof(buf), "%s.zip", path_base(l[0]));
    if (!ui_input_text("Nome do arquivo ZIP", buf, sizeof(buf))) { free_list(l, n); set_status("Cancelado"); return; }
    char out[512];
    path_join(out, sizeof(out), cwd, buf);
    if (fs_exists(out)) { free_list(l, n); set_status("Ja existe um item com esse nome"); return; }

    char pw[64] = "";
    ui_clear();
    ui_input_text_ex("Senha (vazio = sem senha)", pw, sizeof(pw), 1);
    snprintf(arc_password, sizeof(arc_password), "%s", pw);
    ui_set_op("Compactando");
    ArcResult res;
    int r = zip_create(out, l, n, &res);
    arc_password[0] = 0;
    free_list(l, n);
    unmark_all();
    reload_dir();
    arc_report("ZIP", r, &res);
}

static void action_edit(int hex)
{
    if (g_dl.n == 0) return;
    Entry *e = &g_dl.v[g_cur];
    if (e->isdir) { set_status("Selecione um arquivo"); return; }
    char fp[512];
    path_join(fp, sizeof(fp), cwd, e->name);
    if (hex) edit_hex(fp); else edit_text(fp);
    reload_dir();
}

static void action_special(int kind)   /* 0 imagem, 1 audio */
{
    if (g_dl.n == 0) return;
    Entry *e = &g_dl.v[g_cur];
    if (e->isdir) { set_status("Selecione um arquivo"); return; }
    char fp[512];
    path_join(fp, sizeof(fp), cwd, e->name);
    if (kind == 0) view_image(fp); else play_audio(fp);
}

static void action_archive_cur(void)
{
    if (g_dl.n == 0) return;
    Entry *e = &g_dl.v[g_cur];
    char fp[512];
    path_join(fp, sizeof(fp), cwd, e->name);
    if (e->isdir || arc_detect(fp) == ARC_NONE) { set_status("Nao e um arquivo ZIP/RAR"); return; }
    action_archive(fp);
}

static void action_terminal(void)
{
    terminal_run(cwd);
    reload_dir();
}

static void action_select_all(int mode)   /* 0 = marcar, 1 = desmarcar, 2 = inverter */
{
    for (int i = 0; i < g_dl.n; i++) {
        if (!strcmp(g_dl.v[i].name, "..")) continue;
        if (mode == 0) g_dl.v[i].marked = 1;
        else if (mode == 1) g_dl.v[i].marked = 0;
        else g_dl.v[i].marked = !g_dl.v[i].marked;
    }
}

static void action_sort(void)
{
    char keep[256] = "";
    if (g_dl.n > 0) snprintf(keep, sizeof(keep), "%s", g_dl.v[g_cur].name);
    g_sort = (g_sort + 1) % SORT_COUNT;
    dir_sort(&g_dl, g_sort);
    int i = keep[0] ? dir_find(&g_dl, keep) : 0;
    g_cur = (i >= 0) ? i : 0;
    static const char *nm[] = { "nome", "tamanho", "data" };
    set_status("Ordenado por %s", nm[g_sort]);
}

static void drive_menu(void)
{
    static const char *names[] = {
        "ms0:/    Memory Stick",
        "ef0:/    Armazenamento interno (PSP Go)",
        "flash0:/ Sistema (somente leitura)",
        "flash1:/ Configuracoes (somente leitura)",
        "umd0:/   UMD (somente leitura)",
    };
    static const char *roots[] = { "ms0:/", "ef0:/", "flash0:/", "flash1:/", "umd0:/" };

    int s = ui_menu("Escolher drive", names, 5, 0);
    if (s < 0) return;
    if (change_dir(roots[s], NULL) == FS_OK) refresh_space();
    else set_status("Nao foi possivel abrir %s", roots[s]);
}

enum {
    M_COPY, M_CUT, M_PASTE, M_DELETE, M_RENAME, M_MKDIR, M_NEWFILE,
    M_VIEWTXT, M_VIEWHEX, M_EDITTXT, M_EDITHEX, M_VIEWIMG, M_PLAY, M_ARCHIVE, M_ZIP, M_TERM,
    M_PROPS, M_SELALL, M_SELNONE, M_SELINV, M_SORT, M_EXIT, M_COUNT
};

static void action_menu(void)
{
    char sortlabel[48];
    static const char *snames[] = { "nome", "tamanho", "data" };
    snprintf(sortlabel, sizeof(sortlabel), "Ordenar (atual: %s)", snames[g_sort]);

    const char *items[M_COUNT];
    items[M_COPY]    = "Copiar";
    items[M_CUT]     = "Recortar (mover)";
    items[M_PASTE]   = "Colar aqui";
    items[M_DELETE]  = "Excluir";
    items[M_RENAME]  = "Renomear";
    items[M_MKDIR]   = "Nova pasta";
    items[M_NEWFILE] = "Novo arquivo vazio";
    items[M_VIEWTXT] = "Ver como texto";
    items[M_VIEWHEX] = "Ver como hex";
    items[M_EDITTXT] = "Editar como texto";
    items[M_EDITHEX] = "Editar como hex";
    items[M_VIEWIMG] = "Ver imagem (PNG/JPG/BMP)";
    items[M_PLAY]    = "Tocar audio (MP3/WAV)";
    items[M_ARCHIVE] = "Abrir/extrair ZIP ou RAR";
    items[M_ZIP]     = "Compactar em ZIP";
    items[M_TERM]    = "Abrir terminal aqui";
    items[M_PROPS]   = "Propriedades";
    items[M_SELALL]  = "Marcar tudo";
    items[M_SELNONE] = "Desmarcar tudo";
    items[M_SELINV]  = "Inverter selecao";
    items[M_SORT]    = sortlabel;
    items[M_EXIT]    = "Sair do programa";

    int s = ui_menu("Menu de acoes", items, M_COUNT, 0);
    switch (s) {
    case M_COPY:    action_copycut(0); break;
    case M_CUT:     action_copycut(1); break;
    case M_PASTE:   action_paste(); break;
    case M_DELETE:  action_delete(); break;
    case M_RENAME:  action_rename(); break;
    case M_MKDIR:   action_mkdir(); break;
    case M_NEWFILE: action_newfile(); break;
    case M_VIEWTXT: action_view(0); break;
    case M_VIEWHEX: action_view(1); break;
    case M_EDITTXT: action_edit(0); break;
    case M_EDITHEX: action_edit(1); break;
    case M_VIEWIMG: action_special(0); break;
    case M_PLAY:    action_special(1); break;
    case M_ARCHIVE: action_archive_cur(); break;
    case M_ZIP:     action_zip(); break;
    case M_TERM:    action_terminal(); break;
    case M_PROPS:   action_props(); break;
    case M_SELALL:  action_select_all(0); break;
    case M_SELNONE: action_select_all(1); break;
    case M_SELINV:  action_select_all(2); break;
    case M_SORT:    action_sort(); break;
    case M_EXIT:    sceKernelExitGame(); break;
    default: break;
    }
}

/* ---------- navegacao ---------- */
static void go_up(void)
{
    if (path_is_root(cwd)) { set_status("Ja esta na raiz (Select: trocar de drive)"); return; }
    char child[256], parent[512];
    snprintf(child, sizeof(child), "%s", path_base(cwd));
    snprintf(parent, sizeof(parent), "%s", cwd);
    path_parent(parent);
    if (change_dir(parent, child) == FS_OK) refresh_space();
    else set_status("Nao foi possivel abrir a pasta");
}

static void open_entry(void)
{
    if (g_dl.n == 0) return;
    Entry *e = &g_dl.v[g_cur];

    if (e->isdir) {
        if (!strcmp(e->name, "..")) { go_up(); return; }
        char np[512];
        path_join(np, sizeof(np), cwd, e->name);
        if (change_dir(np, NULL) == FS_OK) refresh_space();
        else set_status("Nao foi possivel abrir a pasta");
    } else {
        char fp[512];
        path_join(fp, sizeof(fp), cwd, e->name);
        if (is_image_name(e->name)) view_image(fp);
        else if (is_audio_name(e->name)) play_audio(fp);
        else if (arc_detect(fp) != ARC_NONE) action_archive(fp);
        else action_view(!is_text_ext(e->name));
    }
}

/* ---------- main ---------- */
int main(int argc, char *argv[])
{
    setup_callbacks();
    ui_init();
    fs_progress = ui_progress;

    memset(g_sep, '-', UI_W);
    g_sep[UI_W] = 0;

    ui_clear();
    if (change_dir("ms0:/", NULL) != FS_OK) {
        if (change_dir("ef0:/", NULL) != FS_OK)
            set_status("Nenhum drive disponivel - use Select");
    }
    refresh_space();

    for (;;) {
        clamp_view();
        draw_main();

        unsigned p = ui_wait();
        g_status[0] = 0;
        int n = g_dl.n;

        if (n > 0) {
            if (p & PSP_CTRL_UP)       g_cur = (g_cur > 0) ? g_cur - 1 : n - 1;
            if (p & PSP_CTRL_DOWN)     g_cur = (g_cur < n - 1) ? g_cur + 1 : 0;
            if (p & PSP_CTRL_LTRIGGER) g_cur = (g_cur > LIST_ROWS) ? g_cur - LIST_ROWS : 0;
            if (p & PSP_CTRL_RTRIGGER) g_cur = (g_cur + LIST_ROWS < n) ? g_cur + LIST_ROWS : n - 1;
            if (p & PSP_CTRL_LEFT)     g_cur = 0;
            if (p & PSP_CTRL_RIGHT)    g_cur = n - 1;
            if (p & PSP_CTRL_SQUARE) {
                Entry *e = &g_dl.v[g_cur];
                if (strcmp(e->name, "..") != 0) e->marked = !e->marked;
                if (g_cur < n - 1) g_cur++;
            }
        }
        if (p & PSP_CTRL_CROSS)    open_entry();
        if (p & PSP_CTRL_CIRCLE)   go_up();
        if (p & PSP_CTRL_TRIANGLE) action_menu();
        if (p & PSP_CTRL_SELECT)   drive_menu();
        if (p & PSP_CTRL_START) {
            reload_dir();
            set_status("Recarregado");
        }

        /* menus, dialogos e visualizadores desenham por cima: limpa so nesses casos */
        if (p & (PSP_CTRL_CROSS | PSP_CTRL_TRIANGLE | PSP_CTRL_SELECT))
            ui_clear();
    }
    return 0;
}
