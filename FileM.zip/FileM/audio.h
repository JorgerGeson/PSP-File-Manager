#ifndef AUDIO_H
#define AUDIO_H

int  is_audio_name(const char *name);   /* .mp3 / .wav */
void play_audio(const char *path);      /* player: pausa, volume, faixa anterior/proxima da pasta */

#endif
