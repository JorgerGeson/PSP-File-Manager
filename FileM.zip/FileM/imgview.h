#ifndef IMGVIEW_H
#define IMGVIEW_H

int  is_image_name(const char *name);
void view_image(const char *path);   /* visualizador com zoom, rolagem e navegacao pela pasta */

#endif
