#ifndef PSPC_UTIME_H
#define PSPC_UTIME_H
#include <time.h>
struct utimbuf { time_t actime, modtime; };
#ifdef __cplusplus
extern "C" {
#endif
int utime(const char *path, const struct utimbuf *t);
#ifdef __cplusplus
}
#endif
#endif
