/* stub para o PSP: sem usuarios/grupos */
#ifndef PSPC_PWD_H
#define PSPC_PWD_H
#ifdef __cplusplus
extern "C" {
#endif
struct passwd { char *pw_name; unsigned pw_uid, pw_gid; };
struct group  { char *gr_name; unsigned gr_gid; };
struct passwd *getpwnam(const char *name);
struct group  *getgrnam(const char *name);
#ifdef __cplusplus
}
#endif
#endif
