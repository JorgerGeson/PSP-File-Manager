#ifndef PSPC_STATVFS_H
#define PSPC_STATVFS_H
struct statvfs { unsigned long f_bsize, f_frsize, f_blocks, f_bfree, f_bavail; };
#ifdef __cplusplus
extern "C" {
#endif
int statvfs(const char *path, struct statvfs *buf);
#ifdef __cplusplus
}
#endif
#endif
