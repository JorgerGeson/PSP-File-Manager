#ifndef UI_H
#define UI_H

/* Tela de texto do PSP: 68 colunas x 34 linhas.
 * Usamos 67 colunas por linha para nunca disparar a quebra automatica
 * (que na pspdebug pode limpar a tela ao escrever a ultima celula). */
#define UI_W 67
#define UI_ROWS 34

/* cores no formato 0xAABBGGRR */
#define C_WHITE  0xFFFFFFFFu
#define C_BLACK  0xFF000000u
#define C_YELLOW 0xFF00FFFFu
#define C_GREEN  0xFF00FF00u
#define C_CYAN   0xFFFFFF00u
#define C_RED    0xFF0000FFu
#define C_GRAY   0xFF707070u
#define C_BLUE   0xFF804000u
#define C_ORANGE 0xFF0080FFu

void     ui_init(void);
void     ui_clear(void);
void     ui_line(int row, unsigned fg, unsigned bg, const char *fmt, ...);

/* UTF-8 -> 1 caractere ASCII de 1 coluna; devolve os bytes consumidos */
int      ui_fold_char(const unsigned char *s, int avail, char *out);

/* entrada: botoes recem-pressionados (com auto-repeat nas direcoes/gatilhos) */
unsigned ui_poll(void);
unsigned ui_held(void);
unsigned ui_wait(void);

/* componentes */
int  ui_menu(const char *title, const char **items, int n, int start);
int  ui_confirm(const char *l1, const char *l2);
void ui_message(const char *l1, const char *l2, unsigned color);
int  ui_input_text(const char *title, char *buf, int maxlen);
int  ui_input_text_ex(const char *title, char *buf, int maxlen, int allow_empty);

/* barra de progresso (usada como callback pelas operacoes de arquivo) */
void ui_set_op(const char *op);
int  ui_progress(const char *name, unsigned long long done, unsigned long long total);

void fmt_size(char *out, unsigned long long bytes);

#endif
