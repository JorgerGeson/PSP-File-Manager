/*
 * audio.c - reprodutor de audio
 *
 *  MP3 : decodificador de hardware do PSP (sceMp3, modulos AV carregados em tempo de execucao)
 *  WAV : PCM 8/16/24/32 bits e float32, mono/estereo, qualquer taxa
 *  OGG : Vorbis via Tremor (so com make USE_OGG=1)
 *
 * A saida passa por um "sink" que junta quadros estereo em blocos de 1152 e,
 * se preciso, reamostra para 44100 Hz (interpolacao linear).
 *
 * Controles: X pausa | O sair | L/R faixa anterior/proxima | Cima/Baixo volume
 *            Quadrado reinicia | Triangulo repetir faixa
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <pspaudio.h>
#include <pspmp3.h>
#include <psputility.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "ui.h"
#include "fsops.h"
#include "audio.h"

#define BLOCK      1152
#define SINK_CAP   8192
#define VOL_MAX    0x8000

enum { CMD_NONE = 0, CMD_NEXT, CMD_PREV, CMD_STOP, CMD_END };

#ifdef USE_OGG
#if defined(__has_include)
#if __has_include(<tremor/ivorbisfile.h>)
#include <tremor/ivorbisfile.h>
#else
#include <ivorbisfile.h>
#endif
#else
#include <tremor/ivorbisfile.h>
#endif
#endif

int is_audio_name(const char *name)
{
    const char *d = strrchr(name, '.');
    if (!d) return 0;
    d++;
#ifdef USE_OGG
    if (!strcasecmp(d, "ogg")) return 1;
#endif
    return !strcasecmp(d, "mp3") || !strcasecmp(d, "wav");
}

/* ======================= sink de audio ======================= */
static short s_in[SINK_CAP * 2] __attribute__((aligned(64)));
static short s_out[BLOCK * 2] __attribute__((aligned(64)));
static int s_n = 0;                       /* quadros em s_in */
static unsigned long long s_pos = 0;      /* posicao fracionaria (16.16) */
static unsigned s_step = 65536;
static int s_src = 0, s_chan = -1;
static unsigned long long s_emitted = 0;  /* quadros de saida enviados */
static unsigned s_outrate = 44100;

static int sink_open(unsigned rate)
{
    s_n = 0;
    s_pos = 0;
    s_emitted = 0;
    s_src = 0;
    s_chan = -1;
    s_step = 65536;
    s_outrate = rate;

    if (rate != 44100 && sceAudioSRCChReserve(BLOCK, (int)rate, 2) >= 0) {
        s_src = 1;
        return 1;
    }
    s_chan = sceAudioChReserve(PSP_AUDIO_NEXT_CHANNEL, BLOCK, PSP_AUDIO_FORMAT_STEREO);
    if (s_chan < 0) return 0;
    s_outrate = 44100;
    s_step = (unsigned)(((unsigned long long)rate << 16) / 44100ULL);
    return 1;
}

static void sink_close(void)
{
    if (s_src) sceAudioSRCChRelease();
    else if (s_chan >= 0) sceAudioChRelease(s_chan);
    s_src = 0;
    s_chan = -1;
}

static void sink_reset(void)
{
    s_n = 0;
    s_pos = 0;
    s_emitted = 0;
}

static void sink_push(const short *st, int frames)
{
    if (frames > SINK_CAP - s_n) frames = SINK_CAP - s_n;
    if (frames <= 0) return;
    memcpy(s_in + (size_t)s_n * 2, st, (size_t)frames * 4);
    s_n += frames;
}

static int sink_ready(void)
{
    return (int)(((s_pos + (unsigned long long)(BLOCK - 1) * s_step) >> 16) + 1) < s_n;
}

static void sink_emit(int volpct)
{
    for (int i = 0; i < BLOCK; i++) {
        unsigned long long p = s_pos + (unsigned long long)i * s_step;
        int idx = (int)(p >> 16);
        int fr = (int)(p & 0xFFFF);
        const short *a = s_in + (size_t)idx * 2;
        if (s_step == 65536) {
            s_out[i * 2] = a[0];
            s_out[i * 2 + 1] = a[1];
        } else {
            const short *b = a + 2;
            s_out[i * 2]     = (short)(a[0] + (((int)b[0] - a[0]) * fr >> 16));
            s_out[i * 2 + 1] = (short)(a[1] + (((int)b[1] - a[1]) * fr >> 16));
        }
    }
    s_pos += (unsigned long long)BLOCK * s_step;
    int used = (int)(s_pos >> 16);
    if (used > s_n) used = s_n;
    s_pos &= 0xFFFF;
    if (used > 0) {
        memmove(s_in, s_in + (size_t)used * 2, (size_t)(s_n - used) * 4);
        s_n -= used;
    }
    int vol = VOL_MAX * volpct / 100;
    if (s_src) sceAudioSRCOutputBlocking(vol, s_out);
    else       sceAudioOutputBlocking(s_chan, vol, s_out);
    s_emitted += BLOCK;
}

/* ======================= estado/tela do player ======================= */
typedef struct {
    char name[256];
    char info[64];
    int idx, n;
    int vol;            /* 0..100 */
    int paused, repeat;
    int pct;            /* 0..100 */
    int tick;
    char err[96];
} Player;

static void draw_player(const Player *p, int force)
{
    if (!force && (p->tick % 6) != 0) return;
    unsigned sec = (unsigned)(s_emitted / (s_outrate ? s_outrate : 44100));
    char bar[41], vb[21];
    for (int i = 0; i < 40; i++) bar[i] = (i < p->pct * 40 / 100) ? '#' : '.';
    bar[40] = 0;
    for (int i = 0; i < 20; i++) vb[i] = (i < p->vol / 5) ? '|' : '.';
    vb[20] = 0;

    ui_line(0, C_BLACK, C_CYAN, " Reprodutor de audio");
    ui_line(2, C_YELLOW, C_BLACK, " %.64s", p->name);
    ui_line(3, C_GRAY, C_BLACK, " %s", p->info);
    ui_line(5, p->paused ? C_ORANGE : C_GREEN, C_BLACK, " %s   %02u:%02u", p->paused ? "|| PAUSADO " : ">  TOCANDO ", sec / 60, sec % 60);
    ui_line(6, C_WHITE, C_BLACK, " [%s] %3d%%", bar, p->pct);
    ui_line(8, C_WHITE, C_BLACK, " Volume [%s] %3d%%", vb, p->vol);
    ui_line(10, C_CYAN, C_BLACK, " Faixa %d/%d   Repetir faixa: %s", p->idx + 1, p->n, p->repeat ? "SIM" : "nao");
    ui_line(14, C_GRAY, C_BLACK, " X: pausar/continuar      O: sair");
    ui_line(15, C_GRAY, C_BLACK, " L/R: faixa anterior/proxima");
    ui_line(16, C_GRAY, C_BLACK, " Cima/Baixo: volume       Quad: reiniciar");
    ui_line(17, C_GRAY, C_BLACK, " Tri: repetir faixa");
    if (p->err[0]) ui_line(20, C_BLACK, C_RED, " %.64s", p->err);
}

/* le o controle; devolve um comando ou CMD_NONE. restart = 1 se pediu reiniciar */
static int player_input(Player *p, int *restart)
{
    unsigned b = ui_poll();
    *restart = 0;
    if (b & PSP_CTRL_CIRCLE)   return CMD_STOP;
    if (b & PSP_CTRL_RTRIGGER) return CMD_NEXT;
    if (b & PSP_CTRL_LTRIGGER) return CMD_PREV;
    if (b & PSP_CTRL_CROSS)    { p->paused = !p->paused; draw_player(p, 1); }
    if (b & PSP_CTRL_UP)       { if (p->vol < 100) p->vol += 5; draw_player(p, 1); }
    if (b & PSP_CTRL_DOWN)     { if (p->vol > 0) p->vol -= 5; draw_player(p, 1); }
    if (b & PSP_CTRL_TRIANGLE) { p->repeat = !p->repeat; draw_player(p, 1); }
    if (b & PSP_CTRL_SQUARE)   *restart = 1;
    return CMD_NONE;
}

/* ======================= WAV ======================= */
static unsigned rl16(const unsigned char *p) { return p[0] | (p[1] << 8); }
static unsigned rl32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((unsigned)p[3] << 24); }

typedef struct {
    int tag, ch, bits;
    unsigned rate, align;
    unsigned long long off, size;
} Wav;

static int wav_parse(SceUID fd, unsigned long long fsize, Wav *w, char *err)
{
    unsigned char h[12];
    sceIoLseek(fd, 0, PSP_SEEK_SET);
    if (sceIoRead(fd, h, 12) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) {
        strcpy(err, "Arquivo WAV invalido");
        return 0;
    }
    unsigned long long pos = 12;
    int have_fmt = 0;
    memset(w, 0, sizeof(*w));
    while (pos + 8 <= fsize) {
        unsigned char c[8];
        sceIoLseek(fd, (SceOff)pos, PSP_SEEK_SET);
        if (sceIoRead(fd, c, 8) != 8) break;
        unsigned long long csz = rl32(c + 4);
        if (!memcmp(c, "fmt ", 4)) {
            unsigned char f[40];
            int want = csz < 40 ? (int)csz : 40;
            if (want < 16 || sceIoRead(fd, f, want) != want) break;
            w->tag = (int)rl16(f);
            w->ch = (int)rl16(f + 2);
            w->rate = rl32(f + 4);
            w->align = rl16(f + 12);
            w->bits = (int)rl16(f + 14);
            if (w->tag == 0xFFFE && want >= 26) w->tag = (int)rl16(f + 24);
            have_fmt = 1;
        } else if (!memcmp(c, "data", 4)) {
            if (!have_fmt) break;
            w->off = pos + 8;
            w->size = csz;
            if (w->off + w->size > fsize || w->size == 0) w->size = fsize - w->off;
            break;
        }
        pos += 8 + csz + (csz & 1);
    }
    if (!have_fmt || w->off == 0) { strcpy(err, "WAV sem dados de audio"); return 0; }
    int okfmt = (w->tag == 1 && (w->bits == 8 || w->bits == 16 || w->bits == 24 || w->bits == 32)) ||
                (w->tag == 3 && w->bits == 32);
    if (!okfmt) { snprintf(err, 96, "WAV nao suportado (formato %d, %d bits)", w->tag, w->bits); return 0; }
    if (w->ch < 1 || w->ch > 8 || w->rate < 4000 || w->rate > 192000) { strcpy(err, "WAV: canais/taxa invalidos"); return 0; }
    unsigned bps = (unsigned)w->bits / 8;
    if (w->align < bps * (unsigned)w->ch) w->align = bps * (unsigned)w->ch;
    return 1;
}

static int wav_sample(const unsigned char *p, int bits, int tag)
{
    switch (bits) {
    case 8:  return ((int)p[0] - 128) << 8;
    case 16: return (short)(p[0] | (p[1] << 8));
    case 24: return (short)(p[1] | (p[2] << 8));
    default:
        if (tag == 3) {
            float f;
            memcpy(&f, p, 4);
            if (f > 1.0f) f = 1.0f;
            if (f < -1.0f) f = -1.0f;
            return (int)(f * 32767.0f);
        }
        return (short)(p[2] | (p[3] << 8));
    }
}

static int play_wav(const char *path, Player *p)
{
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) { strcpy(p->err, "Nao foi possivel abrir o arquivo"); return CMD_END; }
    SceIoStat st;
    sceIoGetstat(path, &st);
    Wav w;
    if (!wav_parse(fd, (unsigned long long)st.st_size, &w, p->err)) { sceIoClose(fd); return CMD_END; }

    snprintf(p->info, sizeof(p->info), "WAV %u Hz  %d bits  %s", w.rate, w.bits, w.ch == 1 ? "mono" : "estereo");
    unsigned char *raw = (unsigned char *)malloc((size_t)BLOCK * w.align);
    short *tmp = (short *)malloc(BLOCK * 4);
    if (!raw || !tmp || !sink_open(w.rate)) {
        strcpy(p->err, "Nao foi possivel abrir a saida de audio");
        free(raw); free(tmp); sceIoClose(fd);
        return CMD_END;
    }
    unsigned bps = (unsigned)w.bits / 8;
    unsigned long long consumed = 0, total = w.size;
    int cmd = CMD_NONE;
    draw_player(p, 1);

    while (cmd == CMD_NONE) {
        int restart;
        cmd = player_input(p, &restart);
        if (cmd) break;
        if (restart) { consumed = 0; sink_reset(); }
        p->tick++;
        draw_player(p, 0);
        if (p->paused) { sceDisplayWaitVblankStart(); continue; }

        if (consumed >= total) { cmd = CMD_END; break; }
        unsigned long long left = (total - consumed) / w.align;
        int frames = left > BLOCK ? BLOCK : (int)left;
        if (frames <= 0) { cmd = CMD_END; break; }
        sceIoLseek(fd, (SceOff)(w.off + consumed), PSP_SEEK_SET);
        int got = sceIoRead(fd, raw, (SceSize)((size_t)frames * w.align));
        if (got <= 0) { cmd = CMD_END; break; }
        frames = got / (int)w.align;
        for (int i = 0; i < frames; i++) {
            const unsigned char *f = raw + (size_t)i * w.align;
            int l = wav_sample(f, w.bits, w.tag);
            int r = (w.ch > 1) ? wav_sample(f + bps, w.bits, w.tag) : l;
            tmp[i * 2] = (short)l;
            tmp[i * 2 + 1] = (short)r;
        }
        consumed += (unsigned long long)frames * w.align;
        p->pct = total ? (int)(consumed * 100 / total) : 0;
        sink_push(tmp, frames);
        while (sink_ready() && cmd == CMD_NONE) {
            sink_emit(p->vol);
            int rs;
            cmd = player_input(p, &rs);
            if (rs) { consumed = 0; sink_reset(); break; }
        }
    }
    sink_close();
    free(raw);
    free(tmp);
    sceIoClose(fd);
    return cmd;
}

/* ======================= MP3 ======================= */
static unsigned char s_mp3buf[16 * 1024] __attribute__((aligned(64)));
static unsigned char s_pcmbuf[16 * 1024] __attribute__((aligned(64)));
static int s_av_loaded = 0;

static void load_av(void)
{
    if (s_av_loaded) return;
    sceUtilityLoadModule(0x0300);     /* PSP_MODULE_AV_AVCODEC */
    sceUtilityLoadModule(0x0304);     /* PSP_MODULE_AV_MP3 */
    s_av_loaded = 1;
}

static int mp3_fill(int handle, SceUID fd, unsigned *posout)
{
    unsigned char *dst;
    int towrite, srcpos;
    if (sceMp3GetInfoToAddStreamData(handle, &dst, &towrite, &srcpos) < 0) return -1;
    if (towrite <= 0) return 1;
    if (sceIoLseek32(fd, srcpos, PSP_SEEK_SET) < 0) return -1;
    int rd = sceIoRead(fd, dst, (SceSize)towrite);
    if (rd < 0) return -1;
    if (rd == 0) return 0;
    if (sceMp3NotifyAddStreamData(handle, rd) < 0) return -1;
    *posout = (unsigned)srcpos + (unsigned)rd;
    return rd;
}

static int play_mp3(const char *path, Player *p)
{
    load_av();
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) { strcpy(p->err, "Nao foi possivel abrir o arquivo"); return CMD_END; }
    SceIoStat st;
    sceIoGetstat(path, &st);
    unsigned fsize = (unsigned)st.st_size, start = 0, end = fsize;

    unsigned char h[10];                                   /* ID3v2 no inicio */
    if (sceIoRead(fd, h, 10) == 10 && !memcmp(h, "ID3", 3)) {
        start = 10 + (((unsigned)h[6] & 0x7F) << 21) + (((unsigned)h[7] & 0x7F) << 14) +
                (((unsigned)h[8] & 0x7F) << 7) + ((unsigned)h[9] & 0x7F);
        if (start >= fsize) start = 0;
    }
    if (fsize > 128 + start) {                             /* ID3v1 no fim */
        unsigned char t[3];
        sceIoLseek32(fd, (int)fsize - 128, PSP_SEEK_SET);
        if (sceIoRead(fd, t, 3) == 3 && !memcmp(t, "TAG", 3)) end = fsize - 128;
    }

    SceMp3InitArg arg;
    memset(&arg, 0, sizeof(arg));
    arg.mp3StreamStart = start;
    arg.mp3StreamEnd = end;
    arg.mp3Buf = s_mp3buf;
    arg.mp3BufSize = sizeof(s_mp3buf);
    arg.pcmBuf = s_pcmbuf;
    arg.pcmBufSize = sizeof(s_pcmbuf);

    int handle = sceMp3ReserveMp3Handle(&arg);
    if (handle < 0) {
        snprintf(p->err, sizeof(p->err), "MP3: sem decodificador (erro %08X)", (unsigned)handle);
        sceIoClose(fd);
        return CMD_END;
    }
    unsigned filepos = start;
    int r = mp3_fill(handle, fd, &filepos);
    int ir = (r < 0) ? r : sceMp3Init(handle);
    if (ir < 0) {
        snprintf(p->err, sizeof(p->err), "MP3: arquivo invalido ou nao suportado (%08X)", (unsigned)ir);
        sceMp3ReleaseMp3Handle(handle);
        sceIoClose(fd);
        return CMD_END;
    }
    int rate = sceMp3GetSamplingRate(handle);
    int ch = sceMp3GetMp3ChannelNum(handle);
    int fsamples = (rate >= 32000) ? 1152 : 576;
    snprintf(p->info, sizeof(p->info), "MP3 %d Hz  %s", rate, ch == 1 ? "mono" : "estereo");

    if (!sink_open((unsigned)rate)) {
        strcpy(p->err, "Nao foi possivel abrir a saida de audio");
        sceMp3ReleaseMp3Handle(handle);
        sceIoClose(fd);
        return CMD_END;
    }

    short *tmp = (short *)malloc(1152 * 4);
    int cmd = CMD_NONE, eof = 0, decoded_any = 0;
    draw_player(p, 1);

    while (cmd == CMD_NONE && tmp) {
        int restart;
        cmd = player_input(p, &restart);
        if (cmd) break;
        if (restart) {
            sceMp3ResetPlayPosition(handle);
            sink_reset();
            eof = 0;
            filepos = start;
        }
        p->tick++;
        draw_player(p, 0);
        if (p->paused) { sceDisplayWaitVblankStart(); continue; }

        if (sceMp3CheckStreamDataNeeded(handle) > 0 && !eof) {
            int fr = mp3_fill(handle, fd, &filepos);
            if (fr < 0) { cmd = CMD_END; break; }
            if (fr == 0) eof = 1;
        }
        short *pcm = NULL;
        int nd = sceMp3Decode(handle, &pcm);
        if (nd <= 0 || !pcm) {
            if (!decoded_any && nd < 0) snprintf(p->err, sizeof(p->err), "MP3: erro ao decodificar (%08X)", (unsigned)nd);
            cmd = CMD_END;
            break;
        }
        decoded_any = 1;
        if (ch == 2) memcpy(tmp, pcm, (size_t)fsamples * 4);
        else for (int i = 0; i < fsamples; i++) { tmp[i * 2] = pcm[i]; tmp[i * 2 + 1] = pcm[i]; }
        if (end > start) {
            unsigned buffered = (unsigned)sizeof(s_mp3buf);
            unsigned cur = filepos > start + buffered ? filepos - buffered - start : 0;
            p->pct = (int)((unsigned long long)cur * 100 / (end - start));
            if (p->pct > 100) p->pct = 100;
        }
        sink_push(tmp, fsamples);
        while (sink_ready() && cmd == CMD_NONE) {
            sink_emit(p->vol);
            int rs;
            cmd = player_input(p, &rs);
        }
    }
    sink_close();
    free(tmp);
    sceMp3ReleaseMp3Handle(handle);
    sceIoClose(fd);
    return cmd;
}

/* ======================= OGG Vorbis (opcional: make USE_OGG=1) ======================= */
#ifdef USE_OGG
static int play_ogg(const char *path, Player *p)
{
    FILE *f = fopen(path, "rb");
    if (!f) { strcpy(p->err, "Nao foi possivel abrir o arquivo"); return CMD_END; }
    OggVorbis_File vf;
    if (ov_open(f, &vf, NULL, 0) < 0) {
        fclose(f);
        strcpy(p->err, "OGG invalido ou nao suportado");
        return CMD_END;
    }
    vorbis_info *vi = ov_info(&vf, -1);
    int ch = vi ? vi->channels : 0;
    long rate = vi ? vi->rate : 0;
    if (ch < 1 || ch > 2 || rate < 4000) {
        strcpy(p->err, "OGG: so mono/estereo suportado");
        ov_clear(&vf);
        return CMD_END;
    }
    snprintf(p->info, sizeof(p->info), "OGG %ld Hz  %s", rate, ch == 1 ? "mono" : "estereo");
    if (!sink_open((unsigned)rate)) {
        strcpy(p->err, "Nao foi possivel abrir a saida de audio");
        ov_clear(&vf);
        return CMD_END;
    }
    short *buf = (short *)malloc(1152 * 4);
    short *st = (short *)malloc(1152 * 4);
    ogg_int64_t total = ov_pcm_total(&vf, -1);
    int cmd = CMD_NONE, bs = 0;
    draw_player(p, 1);

    while (cmd == CMD_NONE && buf && st) {
        int restart;
        cmd = player_input(p, &restart);
        if (cmd) break;
        if (restart) { ov_pcm_seek(&vf, 0); sink_reset(); }
        p->tick++;
        draw_player(p, 0);
        if (p->paused) { sceDisplayWaitVblankStart(); continue; }

        long n = ov_read(&vf, (char *)buf, 1152 * 2 * ch, &bs);
        if (n == 0) { cmd = CMD_END; break; }
        if (n < 0) continue;                         /* trecho corrompido: pula */
        int frames = (int)(n / (2 * ch));
        if (ch == 2) memcpy(st, buf, (size_t)frames * 4);
        else for (int i = 0; i < frames; i++) { st[i * 2] = buf[i]; st[i * 2 + 1] = buf[i]; }
        if (total > 0) p->pct = (int)(ov_pcm_tell(&vf) * 100 / total);
        sink_push(st, frames);
        while (sink_ready() && cmd == CMD_NONE) {
            sink_emit(p->vol);
            int rs;
            cmd = player_input(p, &rs);
        }
    }
    sink_close();
    free(buf);
    free(st);
    ov_clear(&vf);
    return cmd;
}
#endif

/* ======================= lista da pasta e laco principal ======================= */
void play_audio(const char *path)
{
    char dir[512];
    snprintf(dir, sizeof(dir), "%s", path);
    path_parent(dir);

    DirList dl;
    if (dir_load(dir, &dl, 0) != FS_OK) { ui_message("Nao foi possivel listar a pasta.", "", C_RED); return; }
    dir_sort(&dl, SORT_NAME);
    char (*names)[256] = (char (*)[256])malloc((size_t)(dl.n ? dl.n : 1) * 256);
    int n = 0, idx = 0;
    const char *base = path_base(path);
    for (int i = 0; names && i < dl.n; i++) {
        if (dl.v[i].isdir || !is_audio_name(dl.v[i].name)) continue;
        snprintf(names[n], 256, "%s", dl.v[i].name);
        if (!strcmp(dl.v[i].name, base)) idx = n;
        n++;
    }
    dir_free(&dl);
    if (!names || n == 0) {
        free(names);
        ui_message("Formato nao suportado (use MP3 ou WAV).", "", C_YELLOW);
        return;
    }

    Player pl;
    memset(&pl, 0, sizeof(pl));
    pl.vol = 70;
    pl.n = n;

    for (;;) {
        char full[512];
        path_join(full, sizeof(full), dir, names[idx]);
        pl.idx = idx;
        pl.pct = 0;
        pl.paused = 0;
        pl.tick = 0;
        pl.err[0] = 0;
        pl.info[0] = 0;
        snprintf(pl.name, sizeof(pl.name), "%s", names[idx]);
        ui_clear();

        const char *ext = strrchr(names[idx], '.');
        int cmd;
        if (ext && !strcasecmp(ext + 1, "wav")) cmd = play_wav(full, &pl);
#ifdef USE_OGG
        else if (ext && !strcasecmp(ext + 1, "ogg")) cmd = play_ogg(full, &pl);
#endif
        else cmd = play_mp3(full, &pl);

        if (cmd == CMD_STOP) break;
        if (cmd == CMD_PREV) { idx = (idx + n - 1) % n; continue; }
        if (cmd == CMD_NEXT) { idx = (idx + 1) % n; continue; }
        /* acabou sozinha (ou deu erro) */
        if (pl.err[0]) {
            draw_player(&pl, 1);
            ui_line(22, C_YELLOW, C_BLACK, " Pressione X para continuar");
            for (;;) { unsigned b = ui_wait(); if (b & (PSP_CTRL_CROSS | PSP_CTRL_CIRCLE)) break; }
            break;
        }
        if (pl.repeat) continue;
        if (idx + 1 >= n) break;               /* fim da pasta */
        idx++;
    }
    free(names);
    ui_clear();
}
