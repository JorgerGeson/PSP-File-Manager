#include "rar.hpp"

/* Zone.Identifier stream can include the text like:

[ZoneTransfer]
ZoneId=3
HostUrl=https://site/path/file.ext
ReferrerUrl=d:\path\archive.ext

Where ZoneId can be:

    0 = My Computer
    1 = Local intranet
    2 = Trusted sites
    3 = Internet
    4 = Restricted sites
*/

MarkOfTheWeb::MarkOfTheWeb()
{
  ZoneIdValue=-1; // -1 indicates the missing MOTW.
  AllFields=false;
}


void MarkOfTheWeb::Clear()
{
  ZoneIdValue=-1;
}


void MarkOfTheWeb::ReadZoneIdStream(const std::wstring &FileName,bool AllFields)
{
  MarkOfTheWeb::AllFields=AllFields;
  ZoneIdValue=-1;
  ZoneIdStream.clear();

  std::wstring StreamName=FileName+MOTW_STREAM_NAME;

  File SrcFile;
  if (SrcFile.Open(StreamName))
  {
    ZoneIdStream.resize(MOTW_STREAM_MAX_SIZE);
    int BufSize=SrcFile.Read(&ZoneIdStream[0],ZoneIdStream.size());
    ZoneIdStream.resize(BufSize<0 ? 0:BufSize);

    if (BufSize<=0)
      return;

    ZoneIdValue=ParseZoneIdStream(ZoneIdStream);
  }
}


// 'Stream' contains the raw "Zone.Identifier" NTFS stream data on input
// and either raw or cleaned stream data on output.
int MarkOfTheWeb::ParseZoneIdStream(std::string &Stream)
{
  if (!starts_with(Stream,"[ZoneTransfer]"))
    return -1; // Not a valid Mark of the Web. Prefer the archive MOTW, if any.

  std::string::size_type ZoneId=std::string::npos; // Found "ZoneId=" position.
  bool LineStart=true; // Only spaces and tabs are present since line start.
  for (size_t I=0;I<Stream.size();I++)
  {
    if (LineStart && Stream.compare(I,7,"ZoneId=")==0)
    {
      if (ZoneId!=std::string::npos) // Second "ZoneId=" found.
        return -1; // Not a valid Mark of the Web.

      ZoneId=I; // Store "ZoneId=" position and continue search for possible second instance.
      continue;
    }
    if (Stream[I]=='\r' || Stream[I]=='\n')
      LineStart=true; // New line started.
    else
      if (Stream[I]!=' ' && Stream[I]!='\t')
        LineStart=false; // Non-space character found after line start.
  }

  // No "ZoneId=" found or its parameter is invalid.
  if (ZoneId==std::string::npos || !IsDigit(Stream[ZoneId+7]))
    return -1; // Not a valid Mark of the Web.
  char E=Stream[ZoneId+8];
  if (E!=0 && E!=' ' && E!='\t' && E!='\r' && E!='\n')
    return -1; // Not a valid Mark of the Web.

  int ZoneIdValue=atoi(&Stream[ZoneId+7]);
  if (ZoneIdValue<0 || ZoneIdValue>4)
    return -1; // Not a valid Mark of the Web.

  if (!AllFields)
    Stream="[ZoneTransfer]\r\nZoneId=" + std::to_string(ZoneIdValue) + "\r\n";

  return ZoneIdValue;
}


void MarkOfTheWeb::CreateZoneIdStream(const std::wstring &Name,StringList &MotwList)
{
  if (ZoneIdValue==-1)
    return;

  size_t ExtPos=GetExtPos(Name);
  const wchar *Ext=ExtPos==std::wstring::npos ? L"":&Name[ExtPos+1];

  bool Matched=false;
  const wchar *CurMask;
  MotwList.Rewind();
  while ((CurMask=MotwList.GetString())!=nullptr)
  {
    // Perform the fast extension comparison for simple *.ext masks.
    // Also we added the fast path to wcsicomp for English only strings.
    // When extracting 100000 files with "Exe and office" masks set
    // this loop spent 85ms with this optimization and wcsicomp optimized
    // for English strings, 415ms with this optimization only, 475ms with
    // wcsicomp optimized only and 795ms without both optimizations.
    bool FastCmp=CurMask[0]=='*' && CurMask[1]=='.' && wcspbrk(CurMask+2,L"*?.")==NULL;
    if (FastCmp && wcsicomp(Ext,CurMask+2)==0 || !FastCmp && CmpName(CurMask,Name,MATCH_NAMES))
    {
      Matched=true;
      break;
    }
  }

  if (!Matched)
    return;

  // Convert single character names like 'f' from f:stream to .\f:stream to
  // resolve the ambiguity with drive letters.
  std::wstring StreamName=Name.size() == 1 ? L".\\"+Name:Name;
  StreamName += MOTW_STREAM_NAME;
  
  File StreamFile;
  if (StreamFile.Create(StreamName)) // Can fail on FAT.
  {
    // 2026.10.08: Obsolete, exceptions enabled.
    // We got a report that write to stream failed on Synology 2411+ NAS drive.
    // So we handle it silently instead of aborting.
//    StreamFile.SetExceptions(false);

    if (StreamFile.Write(&ZoneIdStream[0],ZoneIdStream.size()))
      StreamFile.Close();
  }
}


bool MarkOfTheWeb::IsNameConflicting(const std::wstring &StreamName)
{
  // We must use the case insensitive comparison for L":Zone.Identifier"
  // to catch specially crafted archived streams like L":zone.identifier".
  return wcsicomp(StreamName,MOTW_STREAM_NAME)==0 && ZoneIdValue!=-1;
}


// Return true and prepare the file stream to write if its ZoneId is stricter
// than archive ZoneId. If it is missing, broken, less or equally strict,
// return false and prefer an archive MOTW. This function modifies
// the file stream if AllFields==false, but it is invoked only if user
// requested to propagate the archive MOTW. In this case it seems to be
// reasonable to adjust extracting MOTW file stream according to archive
// MOTW propagation settings. If we ever decide to change it, we can replace
// '&FileStream' to 'FileStream' in function parameter.
bool MarkOfTheWeb::IsFileStreamMoreSecure(std::string &FileStream)
{
  int StreamZone=ParseZoneIdStream(FileStream);
  return StreamZone>ZoneIdValue;
}
