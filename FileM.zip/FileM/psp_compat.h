/* incluido a forca (-include) ao compilar o unrar para o PSP */
#ifndef PSP_COMPAT_H
#define PSP_COMPAT_H
#define lstat stat
#define lstat64 stat
#define stat64 stat
#define fstat64 fstat
#define open64 open
#define lseek64 lseek
#endif
