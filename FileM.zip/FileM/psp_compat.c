/*
 * psp_compat.c - funcoes POSIX que o unrar referencia e a libc do PSP pode nao ter.
 * Todas "weak": se a libc ja tiver a funcao, a dela vence.
 */
#ifdef USE_UNRAR
#define W __attribute__((weak))
typedef long long off64;
struct passwd; struct group; struct utimbuf; struct statvfs;

W struct passwd *getpwnam(const char *n) { (void)n; return 0; }
W struct group  *getgrnam(const char *n) { (void)n; return 0; }
W int chmod(const char *p, unsigned m) { (void)p; (void)m; return 0; }
W int lchown(const char *p, unsigned u, unsigned g) { (void)p; (void)u; (void)g; return 0; }
W int chown(const char *p, unsigned u, unsigned g) { (void)p; (void)u; (void)g; return 0; }
W int link(const char *a, const char *b) { (void)a; (void)b; return -1; }
W int symlink(const char *a, const char *b) { (void)a; (void)b; return -1; }
W int readlink(const char *p, char *b, unsigned long n) { (void)p; (void)b; (void)n; return -1; }
W unsigned geteuid(void) { return 0; }
W int flock(int fd, int op) { (void)fd; (void)op; return 0; }
W int fsync(int fd) { (void)fd; return 0; }
W int dup(int fd) { (void)fd; return -1; }
W int ftruncate(int fd, long n) { (void)fd; (void)n; return -1; }
W int utime(const char *p, const struct utimbuf *t) { (void)p; (void)t; return 0; }
W int utimes(const char *p, const void *t) { (void)p; (void)t; return 0; }
W int statvfs(const char *p, struct statvfs *b) { (void)p; (void)b; return -1; }
#endif
