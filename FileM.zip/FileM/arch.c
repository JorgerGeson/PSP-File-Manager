/*
 * arch.c - arquivos compactados
 *
 * ZIP : listar, extrair (store/deflate) e criar (deflate) usando zlib.
 * RAR : RAR 1.5-4.x e RAR 5.x: listar e extrair entradas ARMAZENADAS (sem
 *       compressao). Entradas comprimidas aparecem na lista mas sao recusadas:
 *       o algoritmo de descompressao do RAR nao esta incluido aqui.
 *       Criar RAR nao e possivel (compressor proprietario).
 *
 * Usa so stdio + zlib + as funcoes fs_* (fsops.h).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <zlib.h>
#include "fsops.h"
#include "arch.h"

#define BUFSZ (64 * 1024)

#ifdef USE_UNRAR
int rarlib_list(const char *path, ArcList *al);
int rarlib_extract(const char *path, const char *destdir, int index, int overwrite, ArcResult *res);
#endif

char arc_password[64] = "";
static unsigned char *g_ib = NULL, *g_ob = NULL;

/* ---- ZipCrypto ---- */
typedef struct { unsigned k0, k1, k2; } ZKeys;
static const z_crc_t *g_ct = NULL;
static void zk_upd(ZKeys *k, unsigned char c)
{
    if (!g_ct) g_ct = get_crc_table();
    k->k0 = (unsigned)(g_ct[(k->k0 ^ c) & 0xff] ^ (k->k0 >> 8));
    k->k1 = (k->k1 + (k->k0 & 0xff)) * 134775813u + 1;
    k->k2 = (unsigned)(g_ct[(k->k2 ^ (k->k1 >> 24)) & 0xff] ^ (k->k2 >> 8));
}
static void zk_init(ZKeys *k, const char *pw)
{
    k->k0 = 0x12345678u; k->k1 = 0x23456789u; k->k2 = 0x34567890u;
    for (; *pw; pw++) zk_upd(k, (unsigned char)*pw);
}
static unsigned char zk_byte(const ZKeys *k)
{
    unsigned t = (k->k2 | 2) & 0xffff;
    return (unsigned char)((t * (t ^ 1)) >> 8);
}
static void zk_decrypt(ZKeys *k, unsigned char *p, size_t n)
{
    for (size_t i = 0; i < n; i++) { p[i] ^= zk_byte(k); zk_upd(k, p[i]); }
}
static void zk_encrypt(ZKeys *k, unsigned char *p, size_t n)
{
    for (size_t i = 0; i < n; i++) { unsigned char c = p[i]; p[i] = c ^ zk_byte(k); zk_upd(k, c); }
}

static int bufs_ok(void)
{
    if (!g_ib) g_ib = (unsigned char *)malloc(BUFSZ);
    if (!g_ob) g_ob = (unsigned char *)malloc(BUFSZ);
    return g_ib && g_ob;
}

static unsigned rd16(const unsigned char *p) { return (unsigned)p[0] | ((unsigned)p[1] << 8); }
static unsigned rd32(const unsigned char *p)
{
    return (unsigned)p[0] | ((unsigned)p[1] << 8) | ((unsigned)p[2] << 16) | ((unsigned)p[3] << 24);
}
static void wr16(unsigned char *p, unsigned v) { p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8); }
static void wr32(unsigned char *p, unsigned v)
{
    p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8);
    p[2] = (unsigned char)(v >> 16); p[3] = (unsigned char)(v >> 24);
}

static void seterr(char *dst, const char *msg) { snprintf(dst, 96, "%s", msg); }

/* ---------------- lista ---------------- */
ArcEntry *arc_list_add(ArcList *al)
{
    if (al->n >= al->cap) {
        int nc = al->cap ? al->cap * 2 : 64;
        ArcEntry *nv = (ArcEntry *)realloc(al->v, (size_t)nc * sizeof(ArcEntry));
        if (!nv) return NULL;
        al->v = nv;
        al->cap = nc;
    }
    ArcEntry *e = &al->v[al->n++];
    memset(e, 0, sizeof(*e));
    return e;
}

void arc_free(ArcList *al)
{
    if (al->v) free(al->v);
    al->v = NULL;
    al->n = al->cap = 0;
}

const char *arc_status_text(const ArcEntry *e)
{
    switch (e->status) {
    case AST_ENCRYPTED: return "criptografado";
    case AST_METHOD:    return "compressao nao suportada";
    case AST_SPLIT:     return "volume dividido";
    default:            return "";
    }
}

/* nome interno -> caminho seguro e relativo. 0 = recusado */
int arc_safe_name(const char *in, char *out, int sz)
{
    int o = 0;
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", in);
    for (char *p = tmp; *p; p++) if (*p == '\\') *p = '/';

    char *save = NULL;
    int first = 1;
    for (char *t = strtok_r(tmp, "/", &save); t; t = strtok_r(NULL, "/", &save)) {
        if (!*t || !strcmp(t, ".")) continue;
        if (!strcmp(t, "..")) return 0;
        if (first && strchr(t, ':')) return 0;     /* "ms0:" etc. */
        first = 0;
        int l = (int)strlen(t);
        if (o + l + 2 >= sz) return 0;
        if (o) out[o++] = '/';
        memcpy(out + o, t, (size_t)l);
        o += l;
    }
    out[o] = 0;
    return o > 0;
}

int arc_detect(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return ARC_NONE;
    unsigned char m[8];
    size_t n = fread(m, 1, 8, f);
    fclose(f);
    if (n >= 4 && m[0] == 'P' && m[1] == 'K' && ((m[2] == 3 && m[3] == 4) || (m[2] == 5 && m[3] == 6)))
        return ARC_ZIP;
    if (n >= 7 && !memcmp(m, "Rar!\x1a\x07\x00", 7)) return ARC_RAR4;
    if (n >= 8 && !memcmp(m, "Rar!\x1a\x07\x01\x00", 8)) return ARC_RAR5;
    return ARC_NONE;
}

/* ================= ZIP: listar ================= */
static int zip_list(FILE *f, ArcList *al)
{
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    if (fsize < 22) { seterr(al->err, "Arquivo zip pequeno demais"); return FS_ERR; }

    long tail = fsize < 65557 ? fsize : 65557;
    unsigned char *t = (unsigned char *)malloc((size_t)tail);
    if (!t) { seterr(al->err, "Sem memoria"); return FS_ERR; }
    fseek(f, fsize - tail, SEEK_SET);
    if ((long)fread(t, 1, (size_t)tail, f) != tail) { free(t); seterr(al->err, "Erro de leitura"); return FS_ERR; }

    long eocd = -1;
    for (long i = tail - 22; i >= 0; i--)
        if (t[i] == 'P' && t[i + 1] == 'K' && t[i + 2] == 5 && t[i + 3] == 6) { eocd = i; break; }
    if (eocd < 0) { free(t); seterr(al->err, "Fim do zip nao encontrado"); return FS_ERR; }

    unsigned total = rd16(t + eocd + 10);
    unsigned cdsize = rd32(t + eocd + 12);
    unsigned cdoff = rd32(t + eocd + 16);
    free(t);

    if (total == 0xFFFF || cdsize == 0xFFFFFFFFu || cdoff == 0xFFFFFFFFu) {
        seterr(al->err, "ZIP64 nao suportado");
        return FS_ERR;
    }
    if ((long)cdoff + (long)cdsize > fsize || cdsize > 16u * 1024 * 1024) {
        seterr(al->err, "Diretorio central invalido");
        return FS_ERR;
    }
    unsigned char *cd = (unsigned char *)malloc(cdsize ? cdsize : 1);
    if (!cd) { seterr(al->err, "Sem memoria"); return FS_ERR; }
    fseek(f, (long)cdoff, SEEK_SET);
    if (fread(cd, 1, cdsize, f) != cdsize) { free(cd); seterr(al->err, "Erro de leitura"); return FS_ERR; }

    unsigned p = 0;
    for (unsigned i = 0; i < total; i++) {
        if (p + 46 > cdsize || rd32(cd + p) != 0x02014b50u) break;
        unsigned flags = rd16(cd + p + 8), method = rd16(cd + p + 10);
        unsigned crc = rd32(cd + p + 16), cs = rd32(cd + p + 20), us = rd32(cd + p + 24);
        unsigned nl = rd16(cd + p + 28), xl = rd16(cd + p + 30), cl = rd16(cd + p + 32);
        unsigned lo = rd32(cd + p + 42);
        if (p + 46 + nl + xl + cl > cdsize) break;

        ArcEntry *e = arc_list_add(al);
        if (!e) break;
        char raw[512];
        unsigned cp = nl < sizeof(raw) - 1 ? nl : (unsigned)sizeof(raw) - 1;
        memcpy(raw, cd + p + 46, cp);
        raw[cp] = 0;
        for (char *q = raw; *q; q++) if (*q == '\\') *q = '/';
        int isdir = cp > 0 && raw[cp - 1] == '/';
        snprintf(e->name, sizeof(e->name), "%s", raw);
        e->isdir = isdir;
        e->csize = cs;
        e->usize = us;
        e->off = lo;
        e->method = method;
        e->crc = crc;
        e->hascrc = 1;
        e->encrypted = (flags & 1) ? 1 : 0;
        if (method == 99) e->status = AST_METHOD;            /* AES */
        else if (method != 0 && method != 8) e->status = AST_METHOD;
        p += 46 + nl + xl + cl;
    }
    free(cd);
    return FS_OK;
}

/* ================= RAR: listar ================= */
static int rar_read(FILE *f, long pos, void *buf, size_t n)
{
    if (fseek(f, pos, SEEK_SET) != 0) return 0;
    return fread(buf, 1, n, f) == n;
}

static int rar4_list(FILE *f, long fsize, ArcList *al)
{
    long pos = 7;
    unsigned char h[7];
    while (pos + 7 <= fsize) {
        if (!rar_read(f, pos, h, 7)) break;
        unsigned type = h[2], flags = rd16(h + 3), hsize = rd16(h + 5);
        if (hsize < 7) break;
        long hend = pos + hsize;
        unsigned long long add = 0;

        if (type == 0x73) {                               /* cabecalho principal */
            if (flags & 0x80) { seterr(al->err, "Cabecalhos criptografados"); return FS_ERR; }
        } else if (type == 0x74) {                        /* arquivo */
            if (hsize > 4096 + 300 || hsize < 32) break;
            unsigned char b[4096 + 300];
            if (!rar_read(f, pos + 7, b, hsize - 7)) break;
            unsigned long long pack = rd32(b), unp = rd32(b + 4);
            unsigned crc = rd32(b + 9), method = b[18], nsz = rd16(b + 19);
            unsigned p = 25;
            if (flags & 0x100) {
                if (hsize < 7 + 33) break;
                pack |= (unsigned long long)rd32(b + p) << 32;
                unp |= (unsigned long long)rd32(b + p + 4) << 32;
                p += 8;
            }
            if (p + nsz > hsize - 7) break;
            char raw[600];
            unsigned cp = nsz < sizeof(raw) - 1 ? nsz : (unsigned)sizeof(raw) - 1;
            memcpy(raw, b + p, cp);
            raw[cp] = 0;
            raw[strnlen(raw, cp)] = 0;                    /* nome unicode: usa a parte antes do NUL */
            for (char *q = raw; *q; q++) if (*q == '\\') *q = '/';

            ArcEntry *e = arc_list_add(al);
            if (!e) break;
            snprintf(e->name, sizeof(e->name), "%s", raw);
            e->csize = pack;
            e->usize = unp;
            e->off = (unsigned long long)hend;
            e->method = method;
            e->crc = crc;
            e->hascrc = 1;
            e->isdir = ((flags & 0xE0) == 0xE0);
            if (flags & 0x04) e->status = AST_ENCRYPTED;
            else if (flags & 0x03) e->status = AST_SPLIT;
            else if (method != 0x30) e->status = AST_METHOD;
            add = pack;
        } else if (type == 0x7B) {
            break;                                        /* fim do arquivo */
        } else if (flags & 0x8000) {
            unsigned char a[4];
            if (!rar_read(f, pos + 7, a, 4)) break;
            add = rd32(a);
        }
        pos = hend + (long)add;
    }
    return FS_OK;
}

/* inteiro de tamanho variavel do RAR5; retorna bytes consumidos (0 = erro) */
static int vint(const unsigned char *p, int avail, unsigned long long *out)
{
    unsigned long long v = 0;
    for (int i = 0; i < avail && i < 10; i++) {
        v |= (unsigned long long)(p[i] & 0x7F) << (7 * i);
        if (!(p[i] & 0x80)) { *out = v; return i + 1; }
    }
    return 0;
}

static int rar5_list(FILE *f, long fsize, ArcList *al)
{
    long pos = 8;
    while (pos + 8 <= fsize) {
        unsigned char top[16];
        size_t got = (size_t)(fsize - pos < 16 ? fsize - pos : 16);
        if (!rar_read(f, pos, top, got)) break;
        unsigned long long hsize;
        int vl = vint(top + 4, (int)got - 4, &hsize);
        if (!vl || hsize < 2 || hsize > 1024 * 1024) break;

        long body = pos + 4 + vl;
        unsigned char *b = (unsigned char *)malloc((size_t)hsize);
        if (!b) break;
        if (!rar_read(f, body, b, (size_t)hsize)) { free(b); break; }

        unsigned long long type, bflags, extra = 0, dsize = 0;
        int p = 0, n;
        int len = (int)hsize;
        if (!(n = vint(b + p, len - p, &type))) { free(b); break; } p += n;
        if (!(n = vint(b + p, len - p, &bflags))) { free(b); break; } p += n;
        if (bflags & 1) { if (!(n = vint(b + p, len - p, &extra))) { free(b); break; } p += n; }
        if (bflags & 2) { if (!(n = vint(b + p, len - p, &dsize))) { free(b); break; } p += n; }

        if (type == 4) {
            free(b);
            seterr(al->err, "Cabecalhos criptografados");
            return FS_ERR;
        }
        if (type == 5) { free(b); break; }

        if (type == 2) {                                  /* arquivo */
            unsigned long long ff = 0, usz = 0, attr = 0, ci = 0, host = 0, nlen = 0;
            unsigned mtime_dummy = 0, crc = 0;
            int hascrc = 0, ok = 1;
            (void)mtime_dummy;
            if (!(n = vint(b + p, len - p, &ff))) ok = 0; else p += n;
            if (ok && !(n = vint(b + p, len - p, &usz))) ok = 0; else if (ok) p += n;
            if (ok && !(n = vint(b + p, len - p, &attr))) ok = 0; else if (ok) p += n;
            if (ok && (ff & 2)) { if (p + 4 > len) ok = 0; else p += 4; }
            if (ok && (ff & 4)) { if (p + 4 > len) ok = 0; else { crc = rd32(b + p); hascrc = 1; p += 4; } }
            if (ok && !(n = vint(b + p, len - p, &ci))) ok = 0; else if (ok) p += n;
            if (ok && !(n = vint(b + p, len - p, &host))) ok = 0; else if (ok) p += n;
            if (ok && !(n = vint(b + p, len - p, &nlen))) ok = 0; else if (ok) p += n;
            (void)attr; (void)host;
            if (ok && p + (int)nlen <= len) {
                ArcEntry *e = arc_list_add(al);
                if (e) {
                    char raw[600];
                    unsigned cp = nlen < sizeof(raw) - 1 ? (unsigned)nlen : (unsigned)sizeof(raw) - 1;
                    memcpy(raw, b + p, cp);
                    raw[cp] = 0;
                    for (char *q = raw; *q; q++) if (*q == '\\') *q = '/';
                    snprintf(e->name, sizeof(e->name), "%s", raw);
                    e->csize = dsize;
                    e->usize = (ff & 8) ? dsize : usz;
                    e->off = (unsigned long long)(body + (long)hsize);
                    e->method = (unsigned)((ci >> 7) & 7);
                    e->crc = crc;
                    e->hascrc = hascrc;
                    e->isdir = (ff & 1) ? 1 : 0;

                    int enc = 0;                          /* registro de extra tipo 1 = criptografia */
                    if (extra && (int)extra <= len) {
                        int q = len - (int)extra;
                        while (q < len) {
                            unsigned long long rs, rt;
                            int a = vint(b + q, len - q, &rs);
                            if (!a) break;
                            int c = vint(b + q + a, len - q - a, &rt);
                            if (!c) break;
                            if (rt == 1) enc = 1;
                            q += a + (int)rs;
                        }
                    }
                    if (enc) e->status = AST_ENCRYPTED;
                    else if (bflags & 0x18) e->status = AST_SPLIT;
                    else if (!e->isdir && e->method != 0) e->status = AST_METHOD;
                }
            }
        }
        free(b);
        pos = body + (long)hsize + (long)dsize;
    }
    return FS_OK;
}

int arc_list(const char *path, ArcList *al)
{
    memset(al, 0, sizeof(*al));
    al->type = arc_detect(path);
    if (al->type == ARC_NONE) { seterr(al->err, "Nao e um arquivo ZIP/RAR"); return FS_ERR; }

    FILE *f = fopen(path, "rb");
    if (!f) { seterr(al->err, "Nao foi possivel abrir o arquivo"); return FS_ERR; }
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);

    int r;
    if (al->type == ARC_ZIP)       r = zip_list(f, al);
#ifdef USE_UNRAR
    else { r = rarlib_list(path, al); }
#else
    else if (al->type == ARC_RAR4) r = rar4_list(f, fsize, al);
    else                           r = rar5_list(f, fsize, al);
#endif
    fclose(f);
    if (r != FS_OK) arc_free(al);
    return r;
}

int arc_needs_password(const char *path)
{
    ArcList al;
    if (arc_list(path, &al) != FS_OK) return strstr(al.err, "enha") != NULL;
    int r = 0;
    for (int i = 0; i < al.n; i++) if (al.v[i].encrypted && !al.v[i].isdir) r = 1;
    arc_free(&al);
    return r;
}

/* ================= extracao ================= */
static void parent_of(char *p)
{
    char *s = strrchr(p, '/');
    if (s) *s = 0;
}

/* abre o destino; cria as pastas. retorna FILE* ou NULL (skip = 1 se existe e nao pode sobrescrever) */
static FILE *open_dest(const char *destdir, const char *name, int overwrite, int *skip, char *outpath, int osz)
{
    *skip = 0;
    path_join(outpath, osz, destdir, name);
    if (!overwrite && fs_exists(outpath)) { *skip = 1; return NULL; }
    char dir[512];
    snprintf(dir, sizeof(dir), "%s", outpath);
    parent_of(dir);
    fs_mkpath(dir);
    return fopen(outpath, "wb");
}

static int zip_extract_one(FILE *f, const ArcEntry *e, const char *destdir, int overwrite,
                           ArcResult *res)
{
    char safe[512], outp[512];
    if (!arc_safe_name(e->name, safe, sizeof(safe))) {
        res->failed++;
        seterr(res->lasterr, "Nome inseguro ignorado");
        return FS_OK;
    }
    if (e->isdir) {
        path_join(outp, sizeof(outp), destdir, safe);
        fs_mkpath(outp);
        return FS_OK;
    }
    if (e->status != AST_OK) {
        res->failed++;
        seterr(res->lasterr, arc_status_text(e));
        return FS_OK;
    }

    unsigned char lh[30];
    if (!rar_read(f, (long)e->off, lh, 30) || rd32(lh) != 0x04034b50u) {
        res->failed++;
        seterr(res->lasterr, "Cabecalho local invalido");
        return FS_OK;
    }
    long data = (long)e->off + 30 + (long)rd16(lh + 26) + (long)rd16(lh + 28);

    int skip;
    FILE *out = open_dest(destdir, safe, overwrite, &skip, outp, sizeof(outp));
    if (skip) { res->skipped++; return FS_OK; }
    if (!out) { res->failed++; seterr(res->lasterr, "Nao foi possivel criar o arquivo"); return FS_OK; }

    fseek(f, data, SEEK_SET);
    int result = FS_OK, bad = 0;
    unsigned long crc = crc32(0L, Z_NULL, 0);
    unsigned long long done = 0, remain = e->csize;
    const char *base = path_base(safe);

    ZKeys zk;
    int enc = e->encrypted;
    if (enc) {
        unsigned char eh[12];
        if (!arc_password[0]) { bad = 7; }
        else if (remain < 12 || fread(eh, 1, 12, f) != 12) { bad = 2; }
        else {
            remain -= 12;
            zk_init(&zk, arc_password);
            zk_decrypt(&zk, eh, 12);
            unsigned chk = (rd16(lh + 6) & 8) ? (rd16(lh + 10) >> 8) : (e->crc >> 24);
            if (eh[11] != (unsigned char)chk) bad = 8;
        }
    }

    if (bad) {
        /* senha ausente/incorreta: nada a ler */
    } else if (e->method == 0) {
        while (remain > 0) {
            size_t want = remain > BUFSZ ? BUFSZ : (size_t)remain;
            size_t got = fread(g_ib, 1, want, f);
            if (got == 0) { bad = 2; break; }
            if (enc) zk_decrypt(&zk, g_ib, got);
            if (fwrite(g_ib, 1, got, out) != got) { bad = 3; break; }
            crc = crc32(crc, g_ib, (uInt)got);
            remain -= got;
            done += got;
            if (fs_progress && fs_progress(base, done, e->usize)) { result = FS_CANCEL; break; }
        }
    } else {
        z_stream zs;
        memset(&zs, 0, sizeof(zs));
        if (inflateInit2(&zs, -MAX_WBITS) != Z_OK) {
            bad = 4;
        } else {
            int zend = 0;
            while (!bad && !zend && result == FS_OK) {
                if (zs.avail_in == 0) {
                    if (remain == 0) { bad = 2; break; }        /* acabou a entrada sem fim de stream */
                    size_t want = remain > BUFSZ ? BUFSZ : (size_t)remain;
                    size_t got = fread(g_ib, 1, want, f);
                    if (got == 0) { bad = 2; break; }
                    if (enc) zk_decrypt(&zk, g_ib, got);
                    remain -= got;
                    zs.next_in = g_ib;
                    zs.avail_in = (uInt)got;
                }
                int r;
                do {
                    zs.next_out = g_ob;
                    zs.avail_out = BUFSZ;
                    r = inflate(&zs, Z_NO_FLUSH);
                    size_t have = BUFSZ - zs.avail_out;
                    if (have) {
                        if (fwrite(g_ob, 1, have, out) != have) { bad = 3; break; }
                        crc = crc32(crc, g_ob, (uInt)have);
                        done += have;
                    }
                    if (r == Z_STREAM_END) { zend = 1; break; }
                    if (r != Z_OK && r != Z_BUF_ERROR) { bad = 4; break; }
                    if (r == Z_BUF_ERROR) break;                /* precisa de mais entrada */
                } while (zs.avail_out == 0);
                if (!bad && fs_progress && fs_progress(base, done, e->usize)) result = FS_CANCEL;
            }
            inflateEnd(&zs);
        }
    }
    fclose(out);

    if (result == FS_CANCEL) { remove(outp); return FS_CANCEL; }
    if (!bad && done != e->usize) bad = 5;
    if (!bad && e->hascrc && (unsigned)crc != e->crc) bad = 6;
    if (bad) {
        remove(outp);
        res->failed++;
        seterr(res->lasterr, bad == 3 ? "Erro ao gravar (disco cheio?)" :
                             bad == 6 ? "CRC invalido" :
                             bad == 7 ? "Senha necessaria" :
                             bad == 8 ? "Senha incorreta" : "Dados corrompidos");
        return FS_OK;
    }
    res->ok++;
    return FS_OK;
}

static int rar_extract_one(FILE *f, const ArcEntry *e, const char *destdir, int overwrite,
                           ArcResult *res)
{
    char safe[512], outp[512];
    if (!arc_safe_name(e->name, safe, sizeof(safe))) {
        res->failed++;
        seterr(res->lasterr, "Nome inseguro ignorado");
        return FS_OK;
    }
    if (e->isdir) {
        path_join(outp, sizeof(outp), destdir, safe);
        fs_mkpath(outp);
        return FS_OK;
    }
    if (e->status != AST_OK) {
        res->failed++;
        seterr(res->lasterr, arc_status_text(e));
        return FS_OK;
    }

    int skip;
    FILE *out = open_dest(destdir, safe, overwrite, &skip, outp, sizeof(outp));
    if (skip) { res->skipped++; return FS_OK; }
    if (!out) { res->failed++; seterr(res->lasterr, "Nao foi possivel criar o arquivo"); return FS_OK; }

    fseek(f, (long)e->off, SEEK_SET);
    unsigned long crc = crc32(0L, Z_NULL, 0);
    unsigned long long remain = e->csize, done = 0;
    int bad = 0, result = FS_OK;
    const char *base = path_base(safe);

    while (remain > 0) {
        size_t want = remain > BUFSZ ? BUFSZ : (size_t)remain;
        size_t got = fread(g_ib, 1, want, f);
        if (got == 0) { bad = 2; break; }
        if (fwrite(g_ib, 1, got, out) != got) { bad = 3; break; }
        crc = crc32(crc, g_ib, (uInt)got);
        remain -= got;
        done += got;
        if (fs_progress && fs_progress(base, done, e->csize)) { result = FS_CANCEL; break; }
    }
    fclose(out);
    if (result == FS_CANCEL) { remove(outp); return FS_CANCEL; }
    if (!bad && e->hascrc && (unsigned)crc != e->crc) bad = 6;
    if (bad) {
        remove(outp);
        res->failed++;
        seterr(res->lasterr, bad == 3 ? "Erro ao gravar (disco cheio?)" :
                             bad == 6 ? "CRC invalido" : "Dados corrompidos");
        return FS_OK;
    }
    res->ok++;
    return FS_OK;
}

int arc_extract(const char *path, const char *destdir, int index, int overwrite, ArcResult *res)
{
    ArcResult dummy;
    if (!res) res = &dummy;
    memset(res, 0, sizeof(*res));
    if (!bufs_ok()) { seterr(res->lasterr, "Sem memoria"); return FS_ERR; }
#ifdef USE_UNRAR
    {
        int t = arc_detect(path);
        if (t == ARC_RAR4 || t == ARC_RAR5) return rarlib_extract(path, destdir, index, overwrite, res);
    }
#endif

    ArcList al;
    if (arc_list(path, &al) != FS_OK) { seterr(res->lasterr, al.err); return FS_ERR; }
    FILE *f = fopen(path, "rb");
    if (!f) { arc_free(&al); seterr(res->lasterr, "Nao foi possivel abrir o arquivo"); return FS_ERR; }

    fs_mkpath(destdir);
    int result = FS_OK;
    for (int i = 0; i < al.n; i++) {
        if (index >= 0 && i != index) continue;
        int r = (al.type == ARC_ZIP) ? zip_extract_one(f, &al.v[i], destdir, overwrite, res)
                                     : rar_extract_one(f, &al.v[i], destdir, overwrite, res);
        if (r == FS_CANCEL) { result = FS_CANCEL; break; }
    }
    fclose(f);
    arc_free(&al);
    return result;
}

/* ================= ZIP: criar ================= */
typedef struct {
    char *name;
    unsigned crc, csize, usize, off;
    unsigned method, dtime, ddate;
    int isdir, enc;
} ZEnt;

typedef struct {
    FILE *f;
    char outpath[512];
    ZEnt *v;
    int n, cap;
    int cancel;
    ArcResult *res;
} ZW;

static int is_stored_ext(const char *name)
{
    static const char *ext[] = { "zip", "rar", "7z", "gz", "bz2", "xz", "jpg", "jpeg", "png", "gif",
                                 "mp3", "ogg", "mp4", "m4a", "aac", "flac", "cso", "iso" };
    const char *d = strrchr(name, '.');
    if (!d) return 0;
    for (unsigned i = 0; i < sizeof(ext) / sizeof(ext[0]); i++)
        if (!strcasecmp(d + 1, ext[i])) return 1;
    return 0;
}

static ZEnt *zw_add(ZW *w, const char *name, int isdir)
{
    if (w->n >= 65535) { seterr(w->res->lasterr, "Muitas entradas (limite 65535)"); return NULL; }
    if (w->n >= w->cap) {
        int nc = w->cap ? w->cap * 2 : 64;
        ZEnt *nv = (ZEnt *)realloc(w->v, (size_t)nc * sizeof(ZEnt));
        if (!nv) return NULL;
        w->v = nv;
        w->cap = nc;
    }
    ZEnt *z = &w->v[w->n];
    memset(z, 0, sizeof(*z));
    size_t l = strlen(name);
    z->name = (char *)malloc(l + 2);
    if (!z->name) return NULL;
    memcpy(z->name, name, l);
    if (isdir && (l == 0 || name[l - 1] != '/')) z->name[l++] = '/';
    z->name[l] = 0;
    z->isdir = isdir;
    w->n++;
    return z;
}

static int put_local(ZW *w, ZEnt *z)
{
    unsigned char h[30];
    unsigned nl = (unsigned)strlen(z->name);
    wr32(h, 0x04034b50u);
    wr16(h + 4, 20);
    wr16(h + 6, 0x0800 | (z->enc ? 1 : 0));   /* UTF-8 (+ senha) */
    wr16(h + 8, z->method);
    wr16(h + 10, z->dtime);
    wr16(h + 12, z->ddate);
    wr32(h + 14, z->crc);
    wr32(h + 18, z->csize);
    wr32(h + 22, z->usize);
    wr16(h + 26, nl);
    wr16(h + 28, 0);
    if (fwrite(h, 1, 30, w->f) != 30) return 0;
    return fwrite(z->name, 1, nl, w->f) == nl;
}

static int zw_add_file(ZW *w, const char *full, const char *arcname)
{
    unsigned long long sz;
    unsigned dd, dt;
    int isdir;
    if (fs_stat_info(full, &isdir, &sz, &dd, &dt) != FS_OK) { w->res->failed++; return FS_OK; }
    if (sz > 0xFFFFFFFEull) { w->res->failed++; seterr(w->res->lasterr, "Arquivo grande demais"); return FS_OK; }

    FILE *in = fopen(full, "rb");
    if (!in) { w->res->failed++; seterr(w->res->lasterr, "Nao foi possivel ler um arquivo"); return FS_OK; }

    ZEnt *z = zw_add(w, arcname, 0);
    if (!z) { fclose(in); return FS_ERR; }
    z->dtime = dt;
    z->ddate = dd;
    z->method = (sz == 0 || is_stored_ext(arcname)) ? 0 : 8;
    z->usize = (unsigned)sz;
    ZKeys zk;
    unsigned long long written = 0;
    if (arc_password[0] && sz > 0) {
        /* pre-leitura para o CRC (o byte de verificacao da senha usa o CRC) */
        unsigned long pc = crc32(0L, Z_NULL, 0);
        size_t g;
        while ((g = fread(g_ib, 1, BUFSZ, in)) > 0) pc = crc32(pc, g_ib, (uInt)g);
        fseek(in, 0, SEEK_SET);
        z->crc = (unsigned)pc;
        z->enc = 1;
    }
    long hdr = ftell(w->f);
    if (hdr < 0) { fclose(in); return FS_ERR; }
    z->off = (unsigned)hdr;
    if (!put_local(w, z)) { fclose(in); return FS_ERR; }

    unsigned long crc = crc32(0L, Z_NULL, 0);
    unsigned long long done = 0;
    int bad = 0;
    z_stream zs;
    if (z->enc) {
        unsigned char eh[12];
        zk_init(&zk, arc_password);
        srand((unsigned)(z->crc ^ (unsigned)(size_t)z ^ 0x5bd1e995u));
        for (int i = 0; i < 11; i++) eh[i] = (unsigned char)(rand() >> 7);
        eh[11] = (unsigned char)(z->crc >> 24);
        zk_encrypt(&zk, eh, 12);
        if (fwrite(eh, 1, 12, w->f) != 12) bad = 3;
        written += 12;
    }
    if (z->method == 8) {
        memset(&zs, 0, sizeof(zs));
        if (deflateInit2(&zs, 6, Z_DEFLATED, -MAX_WBITS, 8, Z_DEFAULT_STRATEGY) != Z_OK) bad = 1;
    }

    const char *base = path_base(arcname);
    int eof = 0;
    while (!bad && !eof) {
        size_t got = fread(g_ib, 1, BUFSZ, in);
        if (got < BUFSZ) eof = 1;
        crc = crc32(crc, g_ib, (uInt)got);
        done += got;

        if (z->method == 0) {
            if (z->enc) zk_encrypt(&zk, g_ib, got);
            if (got && fwrite(g_ib, 1, got, w->f) != got) bad = 3;
            written += got;
        } else {
            zs.next_in = g_ib;
            zs.avail_in = (uInt)got;
            int flush = eof ? Z_FINISH : Z_NO_FLUSH;
            int r;
            do {
                zs.next_out = g_ob;
                zs.avail_out = BUFSZ;
                r = deflate(&zs, flush);
                size_t have = BUFSZ - zs.avail_out;
                if (have) {
                    if (z->enc) zk_encrypt(&zk, g_ob, have);
                    if (fwrite(g_ob, 1, have, w->f) != have) { bad = 3; break; }
                    written += have;
                }
                if (r == Z_STREAM_ERROR) { bad = 4; break; }
            } while (zs.avail_out == 0);
        }
        if (!bad && fs_progress && fs_progress(base, done, sz)) { w->cancel = 1; break; }
    }
    if (z->method == 8) deflateEnd(&zs);
    fclose(in);
    if (bad || w->cancel) {
        if (bad) seterr(w->res->lasterr, "Erro ao gravar o zip (disco cheio?)");
        return bad ? FS_ERR : FS_CANCEL;
    }

    z->crc = (unsigned)crc;
    z->csize = (unsigned)written;
    z->usize = (unsigned)done;

    long endpos = ftell(w->f);
    unsigned char p[12];
    wr32(p, z->crc);
    wr32(p + 4, z->csize);
    wr32(p + 8, z->usize);
    if (fseek(w->f, (long)z->off + 14, SEEK_SET) != 0 || fwrite(p, 1, 12, w->f) != 12) return FS_ERR;
    if (fseek(w->f, endpos, SEEK_SET) != 0) return FS_ERR;
    w->res->ok++;
    return FS_OK;
}

static int zw_add_path(ZW *w, const char *full, const char *arcname)
{
    if (!strcmp(full, w->outpath)) return FS_OK;          /* nao inclui o proprio zip */

    int isdir;
    unsigned long long sz;
    unsigned dd, dt;
    if (fs_stat_info(full, &isdir, &sz, &dd, &dt) != FS_OK) { w->res->failed++; return FS_OK; }
    if (!isdir) return zw_add_file(w, full, arcname);

    ZEnt *z = zw_add(w, arcname, 1);
    if (!z) return FS_ERR;
    z->dtime = dt;
    z->ddate = dd;
    long hdr = ftell(w->f);
    z->off = (unsigned)hdr;
    if (!put_local(w, z)) return FS_ERR;

    void *dh = fs_dir_open(full);
    if (!dh) { w->res->failed++; return FS_OK; }
    char nm[256];
    int result = FS_OK;
    while (fs_dir_next(dh, nm, sizeof(nm))) {
        char cf[512], ca[512];
        path_join(cf, sizeof(cf), full, nm);
        snprintf(ca, sizeof(ca), "%s/%s", arcname, nm);
        int r = zw_add_path(w, cf, ca);
        if (r != FS_OK) { result = r; break; }
    }
    fs_dir_close(dh);
    return result;
}

int zip_create(const char *outpath, char **srcs, int nsrc, ArcResult *res)
{
    ArcResult dummy;
    if (!res) res = &dummy;
    memset(res, 0, sizeof(*res));
    if (!bufs_ok()) { seterr(res->lasterr, "Sem memoria"); return FS_ERR; }

    ZW w;
    memset(&w, 0, sizeof(w));
    w.res = res;
    snprintf(w.outpath, sizeof(w.outpath), "%s", outpath);
    w.f = fopen(outpath, "w+b");
    if (!w.f) { seterr(res->lasterr, "Nao foi possivel criar o zip"); return FS_ERR; }

    int result = FS_OK;
    for (int i = 0; i < nsrc && result == FS_OK; i++) {
        char tmp[512];
        snprintf(tmp, sizeof(tmp), "%s", srcs[i]);
        int l = (int)strlen(tmp);
        while (l > 1 && tmp[l - 1] == '/') tmp[--l] = 0;
        const char *base = path_base(tmp);
        if (!*base) { res->failed++; continue; }
        result = zw_add_path(&w, tmp, base);
    }

    if (result == FS_OK) {
        long cdoff = ftell(w.f);
        long cdsize = 0;
        for (int i = 0; i < w.n && result == FS_OK; i++) {
            ZEnt *z = &w.v[i];
            unsigned char h[46];
            unsigned nl = (unsigned)strlen(z->name);
            memset(h, 0, sizeof(h));
            wr32(h, 0x02014b50u);
            wr16(h + 4, 20);
            wr16(h + 6, 20);
            wr16(h + 8, 0x0800 | (z->enc ? 1 : 0));
            wr16(h + 10, z->method);
            wr16(h + 12, z->dtime);
            wr16(h + 14, z->ddate);
            wr32(h + 16, z->crc);
            wr32(h + 20, z->csize);
            wr32(h + 24, z->usize);
            wr16(h + 28, nl);
            wr32(h + 38, z->isdir ? 0x10u : 0u);
            wr32(h + 42, z->off);
            if (fwrite(h, 1, 46, w.f) != 46 || fwrite(z->name, 1, nl, w.f) != nl) result = FS_ERR;
            cdsize += 46 + (long)nl;
        }
        if (result == FS_OK) {
            unsigned char e[22];
            memset(e, 0, sizeof(e));
            wr32(e, 0x06054b50u);
            wr16(e + 8, (unsigned)w.n);
            wr16(e + 10, (unsigned)w.n);
            wr32(e + 12, (unsigned)cdsize);
            wr32(e + 16, (unsigned)cdoff);
            if (fwrite(e, 1, 22, w.f) != 22) result = FS_ERR;
        }
        if (result == FS_ERR && !res->lasterr[0]) seterr(res->lasterr, "Erro ao gravar o zip (disco cheio?)");
    }
    fclose(w.f);
    for (int i = 0; i < w.n; i++) free(w.v[i].name);
    free(w.v);
    if (result != FS_OK) remove(outpath);
    return result;
}
