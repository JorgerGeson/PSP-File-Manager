#ifndef VIEWER_H
#define VIEWER_H

void view_text(const char *path);   /* visualizador de texto com rolagem */
void view_hex(const char *path);    /* visualizador hexadecimal */

#endif
