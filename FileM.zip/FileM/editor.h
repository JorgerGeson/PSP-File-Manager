#ifndef EDITOR_H
#define EDITOR_H

void edit_text(const char *path);   /* editor de texto por linhas (salvar, desfazer, procurar/substituir) */
void edit_hex(const char *path);    /* editor hexadecimal: altera bytes direto no arquivo */

#endif
