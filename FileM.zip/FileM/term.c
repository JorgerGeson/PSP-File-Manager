/*
 * term.c - terminal de comandos
 *
 * X/Start: digitar comando (teclado em tela)   Tri: inserir nome de arquivo da pasta
 * L/R: historico   Cima/Baixo: rolar   O: sair     Digite "help" para a lista.
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include "ui.h"
#include "fsops.h"
#include "arch.h"
#include "viewer.h"
#include "editor.h"
#include "imgview.h"
#include "audio.h"
#include "term.h"

#define TL_MAX   400
#define OUT_ROWS 31
#define MAXARGS  24
#define HIST_MAX 40

static char     tl[TL_MAX][UI_W + 1];
static unsigned tc[TL_MAX];
static int      tn = 0;               /* linhas guardadas (ring) */
static int      thead = 0;
static int      tscroll = 0;          /* linhas puladas a partir do fim */
static char     cwd[512];
static char     hist[HIST_MAX][160];
static int      nh = 0, hsel = -1;
static char     pending[160] = "";
static FILE    *redir = NULL;
static int      quit = 0;

static void put_line(unsigned color, const char *s, int len)
{
    int idx;
    if (tn == TL_MAX) { idx = thead; thead = (thead + 1) % TL_MAX; }
    else { idx = (thead + tn) % TL_MAX; tn++; }
    char out[UI_W + 1];
    int o = 0;
    for (int i = 0; i < len && o < UI_W; ) {
        char ch;
        i += ui_fold_char((const unsigned char *)s + i, len - i, &ch);
        out[o++] = (s[i - 1] == '\t') ? ' ' : ch;
    }
    out[o] = 0;
    memcpy(tl[idx], out, (size_t)o + 1);
    tc[idx] = color;
}

static void tprint(unsigned color, const char *fmt, ...)
{
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (redir) { fputs(buf, redir); fputc('\n', redir); return; }
    const char *s = buf;
    for (;;) {
        const char *nl = strchr(s, '\n');
        int len = nl ? (int)(nl - s) : (int)strlen(s);
        while (len > 66) { put_line(color, s, 66); s += 66; len -= 66; }
        put_line(color, s, len);
        if (!nl) break;
        s = nl + 1;
    }
    tscroll = 0;
}

#define OUT(...)  tprint(C_WHITE, __VA_ARGS__)
#define ERR(...)  tprint(C_RED, __VA_ARGS__)

static void draw(void)
{
    ui_line(0, C_BLACK, C_CYAN, " Terminal  %.55s", cwd);
    int maxs = tn > OUT_ROWS ? tn - OUT_ROWS : 0;
    if (tscroll > maxs) tscroll = maxs;
    int first = tn - OUT_ROWS - tscroll;
    for (int r = 0; r < OUT_ROWS; r++) {
        int k = first + r;
        if (k < 0 || k >= tn) { ui_line(1 + r, C_WHITE, C_BLACK, ""); continue; }
        int i = (thead + k) % TL_MAX;
        ui_line(1 + r, tc[i], C_BLACK, "%s", tl[i]);
    }
    ui_line(32, C_GREEN, C_BLACK, "> %s_", pending);
    ui_line(33, C_GRAY, C_BLACK, " X:digitar Tri:arquivo L/R:historico Cima/Baixo:rolar O:sair");
}

static void rp(char *out, const char *arg) { path_resolve(out, 512, cwd, arg); }

static int is_dir(const char *p)
{
    int d = 0;
    return fs_stat_info(p, &d, NULL, NULL, NULL) == FS_OK && d;
}

/* ---------------- comandos ---------------- */
static void cmd_ls(int argc, char **argv)
{
    int lng = 0;
    char path[512];
    snprintf(path, sizeof(path), "%s", cwd);
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-l")) lng = 1; else rp(path, argv[i]);
    }
    DirList dl;
    if (dir_load(path, &dl, 0) != FS_OK) { ERR("ls: nao foi possivel abrir %s", path); return; }
    dir_sort(&dl, SORT_NAME);
    for (int i = 0; i < dl.n; i++) {
        Entry *e = &dl.v[i];
        char sz[24];
        fmt_size(sz, e->size);
        if (lng) tprint(e->isdir ? C_YELLOW : C_WHITE, "%c %9s %04d-%02d-%02d %s%s", e->isdir ? 'd' : '-',
                        e->isdir ? "-" : sz, (int)e->mtime.year, (int)e->mtime.month, (int)e->mtime.day,
                        e->name, e->isdir ? "/" : "");
        else tprint(e->isdir ? C_YELLOW : C_WHITE, "%s%s", e->name, e->isdir ? "/" : "");
    }
    OUT("%d item(ns)", dl.n);
    dir_free(&dl);
}

static char *slurp(const char *path, int *n, int maxn)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) return NULL;
    int sz = (int)st.st_size;
    if (sz > maxn) sz = maxn;
    char *b = (char *)malloc((size_t)sz + 1);
    if (!b) return NULL;
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) { free(b); return NULL; }
    int r = sz > 0 ? sceIoRead(fd, b, sz) : 0;
    sceIoClose(fd);
    if (r < 0) r = 0;
    b[r] = 0;
    *n = r;
    return b;
}

static void print_text(const char *b, int n, int first, int last)  /* linhas [first,last) ; last<0 = tudo */
{
    int line = 0, s = 0;
    for (int i = 0; i <= n; i++) {
        if (i == n || b[i] == '\n') {
            if (i == n && s == i) break;
            if (line >= first && (last < 0 || line < last)) {
                int e = i;
                if (e > s && b[e - 1] == '\r') e--;
                char tmp[1024];
                int l = e - s > 1000 ? 1000 : e - s;
                memcpy(tmp, b + s, (size_t)l);
                tmp[l] = 0;
                tprint(C_WHITE, "%s", tmp);
            }
            line++;
            s = i + 1;
        }
    }
}

static int count_lines(const char *b, int n)
{
    int c = 0;
    for (int i = 0; i < n; i++) if (b[i] == '\n') c++;
    if (n > 0 && b[n - 1] != '\n') c++;
    return c;
}

static void cmd_cat_head_tail(const char *c, int argc, char **argv)
{
    int cnt = 10;
    const char *file = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-n") && i + 1 < argc) cnt = atoi(argv[++i]);
        else file = argv[i];
    }
    if (!file) { ERR("uso: %s [-n N] arquivo", c); return; }
    char p[512];
    rp(p, file);
    int n;
    char *b = slurp(p, &n, 4 * 1024 * 1024);
    if (!b) { ERR("%s: nao foi possivel ler", file); return; }
    if (!strcmp(c, "cat")) print_text(b, n, 0, -1);
    else if (!strcmp(c, "head")) print_text(b, n, 0, cnt);
    else { int t = count_lines(b, n); print_text(b, n, t > cnt ? t - cnt : 0, -1); }
    free(b);
}

static void cmd_wc(const char *f)
{
    char p[512];
    rp(p, f);
    int n;
    char *b = slurp(p, &n, 8 * 1024 * 1024);
    if (!b) { ERR("wc: nao foi possivel ler"); return; }
    int words = 0, in = 0;
    for (int i = 0; i < n; i++) {
        if (isspace((unsigned char)b[i])) in = 0; else if (!in) { in = 1; words++; }
    }
    OUT("%d linhas  %d palavras  %d bytes", count_lines(b, n), words, n);
    free(b);
}

static void cmd_grep(const char *pat, const char *f)
{
    char p[512];
    rp(p, f);
    int n;
    char *b = slurp(p, &n, 4 * 1024 * 1024);
    if (!b) { ERR("grep: nao foi possivel ler"); return; }
    int line = 1, s = 0, hits = 0;
    for (int i = 0; i <= n; i++) {
        if (i == n || b[i] == '\n') {
            char tmp[1024];
            int l = i - s > 1000 ? 1000 : i - s;
            memcpy(tmp, b + s, (size_t)l);
            tmp[l] = 0;
            for (char *q = tmp; *q; q++) if (*q == '\r') *q = 0;
            int found = 0, pl = (int)strlen(pat);
            for (char *q = tmp; *q && !found; q++)
                if (!strncasecmp(q, pat, (size_t)pl)) found = 1;
            if (found) { tprint(C_WHITE, "%d: %s", line, tmp); hits++; }
            line++;
            s = i + 1;
        }
    }
    OUT("%d ocorrencia(s)", hits);
    free(b);
}

static void find_rec(const char *dir, const char *pat, int *hits, int depth)
{
    DirList dl;
    if (depth > 12 || dir_load(dir, &dl, 0) != FS_OK) return;
    for (int i = 0; i < dl.n && *hits < 300; i++) {
        char c[512];
        path_join(c, sizeof(c), dir, dl.v[i].name);
        int pl = (int)strlen(pat), found = 0;
        for (const char *q = dl.v[i].name; *q && !found; q++) if (!strncasecmp(q, pat, (size_t)pl)) found = 1;
        if (found) { tprint(dl.v[i].isdir ? C_YELLOW : C_WHITE, "%s", c); (*hits)++; }
        if (dl.v[i].isdir) find_rec(c, pat, hits, depth + 1);
    }
    dir_free(&dl);
}

static void cmd_stat(const char *f)
{
    char p[512];
    rp(p, f);
    SceIoStat st;
    if (sceIoGetstat(p, &st) < 0) { ERR("stat: nao encontrado"); return; }
    OUT("%s", p);
    OUT("tipo: %s   tamanho: %llu bytes", FIO_S_ISDIR(st.st_mode) ? "pasta" : "arquivo", (unsigned long long)st.st_size);
    OUT("modificado: %04d-%02d-%02d %02d:%02d:%02d", (int)st.sce_st_mtime.year, (int)st.sce_st_mtime.month,
        (int)st.sce_st_mtime.day, (int)st.sce_st_mtime.hour, (int)st.sce_st_mtime.minute, (int)st.sce_st_mtime.second);
}

static void result_text(const char *what, int r, const ArcResult *res)
{
    if (r == FS_CANCEL) { ERR("%s: cancelado", what); return; }
    if (r != FS_OK) { ERR("%s: erro - %s", what, res->lasterr); return; }
    tprint(res->failed ? C_YELLOW : C_GREEN, "%s: %d ok, %d pulado(s), %d falha(s)", what, res->ok, res->skipped, res->failed);
    if (res->failed && res->lasterr[0]) ERR("ultimo erro: %s", res->lasterr);
}

static void cmd_zip(int argc, char **argv)
{
    arc_password[0] = 0;
    int a0 = 1;
    if (argc > 2 && !strcmp(argv[1], "-p")) { snprintf(arc_password, sizeof(arc_password), "%s", argv[2]); a0 = 3; }
    if (argc < a0 + 2) { ERR("uso: zip [-p senha] saida.zip itens..."); return; }
    char out[512];
    rp(out, argv[a0]);
    if (path_is_ro(out)) { ERR("destino somente leitura"); return; }
    int ns = argc - a0 - 1;
    char **src = (char **)calloc((size_t)ns, sizeof(char *));
    if (!src) return;
    for (int i = 0; i < ns; i++) { src[i] = (char *)malloc(512); rp(src[i], argv[a0 + 1 + i]); }
    ui_set_op("Compactando");
    ArcResult res;
    int r = zip_create(out, src, ns, &res);
    arc_password[0] = 0;
    for (int i = 0; i < ns; i++) free(src[i]);
    free(src);
    result_text("zip", r, &res);
}

static void cmd_unarc(int argc, char **argv)
{
    int list = 0, ow = 0;
    arc_password[0] = 0;
    const char *file = NULL, *dest = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-l") || !strcmp(argv[i], "l")) list = 1;
        else if (!strcmp(argv[i], "-o")) ow = 1;
        else if (!strcmp(argv[i], "-d") && i + 1 < argc) dest = argv[++i];
        else if (!strcmp(argv[i], "-p") && i + 1 < argc) snprintf(arc_password, sizeof(arc_password), "%s", argv[++i]);
        else if (!strcmp(argv[i], "x") && i == 1) continue;
        else if (!file) file = argv[i];
        else if (!dest) dest = argv[i];
    }
    if (!file) { ERR("uso: %s [-l] [-o] arquivo [-d pasta]", argv[0]); return; }
    char p[512], d[512];
    rp(p, file);
    if (list) {
        ArcList al;
        if (arc_list(p, &al) != FS_OK) { ERR("%s", al.err); return; }
        for (int i = 0; i < al.n; i++) {
            char sz[24];
            fmt_size(sz, al.v[i].usize);
            tprint(al.v[i].status ? C_ORANGE : (al.v[i].isdir ? C_YELLOW : C_WHITE), "%9s %s%s%s%s", al.v[i].isdir ? "-" : sz,
                   al.v[i].name, al.v[i].status ? "  [" : "", arc_status_text(&al.v[i]), al.v[i].status ? "]" : "");
        }
        OUT("%d entrada(s)", al.n);
        arc_free(&al);
        return;
    }
    if (dest) rp(d, dest); else snprintf(d, sizeof(d), "%s", cwd);
    if (path_is_ro(d)) { ERR("destino somente leitura"); return; }
    ui_set_op("Extraindo");
    ArcResult res;
    int r = arc_extract(p, d, -1, ow, &res);
    arc_password[0] = 0;
    result_text("extrair", r, &res);
}

static void cmd_help(void)
{
    tprint(C_CYAN, "Comandos (caminhos: relativos, /x ou ms0:/x):");
    OUT("ls [-l] [dir]  cd [dir]  pwd  clear  df  stat f  tree-like: find texto");
    OUT("cat/head/tail [-n N] f   wc f   grep texto f");
    OUT("cp origem destino   mv origem destino   rm [-r] f");
    OUT("mkdir d   touch f   echo texto [> f | >> f]   (> e >> valem p/ qualquer comando)");
    OUT("zip [-p senha] saida.zip itens...   unzip [-l] [-o] [-p senha] f.zip [-d pasta]");
    OUT("unrar [-l] [-o] f.rar [-d pasta]  (so entradas sem compressao)");
    OUT("edit f   hex f (editor hex)   view f   img f   play f");
    OUT("history   exit");
    OUT("-o sobrescreve arquivos existentes ao extrair.");
}

static int tokenize(char *line, char **argv)
{
    int n = 0;
    char *p = line;
    while (*p && n < MAXARGS) {
        while (*p == ' ') p++;
        if (!*p) break;
        char q = 0;
        if (*p == '"' || *p == '\'') q = *p++;
        argv[n++] = p;
        char *w = p;
        while (*p && (q ? *p != q : *p != ' ')) *w++ = *p++;
        int end = (*p == 0);
        *w = 0;
        if (!end) p++;
    }
    return n;
}

static void run(char *line)
{
    char *argv[MAXARGS + 1];
    int argc = tokenize(line, argv);
    if (argc == 0) return;

    /* redirecionamento */
    redir = NULL;
    for (int i = 0; i < argc - 1; i++) {
        if (!strcmp(argv[i], ">") || !strcmp(argv[i], ">>")) {
            char p[512];
            rp(p, argv[i + 1]);
            if (path_is_ro(p)) { ERR("destino somente leitura"); return; }
            redir = fopen(p, argv[i][1] ? "ab" : "wb");
            if (!redir) { ERR("nao foi possivel abrir %s", argv[i + 1]); return; }
            argc = i;
            break;
        }
    }
    const char *c = argv[0];
    char a[512], b[512];

    if (!strcmp(c, "help") || !strcmp(c, "?")) cmd_help();
    else if (!strcmp(c, "exit") || !strcmp(c, "quit")) quit = 1;
    else if (!strcmp(c, "clear")) { tn = 0; thead = 0; }
    else if (!strcmp(c, "pwd")) OUT("%s", cwd);
    else if (!strcmp(c, "ls") || !strcmp(c, "dir")) cmd_ls(argc, argv);
    else if (!strcmp(c, "cd")) {
        if (argc < 2) { OUT("%s", cwd); }
        else {
            rp(a, argv[1]);
            if (!is_dir(a)) ERR("cd: %s nao e uma pasta", argv[1]);
            else snprintf(cwd, sizeof(cwd), "%s", a);
        }
    }
    else if (!strcmp(c, "cat") || !strcmp(c, "head") || !strcmp(c, "tail")) cmd_cat_head_tail(c, argc, argv);
    else if (!strcmp(c, "wc") && argc > 1) cmd_wc(argv[1]);
    else if (!strcmp(c, "grep") && argc > 2) cmd_grep(argv[1], argv[2]);
    else if (!strcmp(c, "find") && argc > 1) { int h = 0; find_rec(cwd, argv[1], &h, 0); OUT("%d resultado(s)", h); }
    else if (!strcmp(c, "stat") && argc > 1) cmd_stat(argv[1]);
    else if (!strcmp(c, "df")) {
        unsigned long long f, t;
        char fs[24], ts[24];
        if (fs_devinfo(cwd, &f, &t) == FS_OK) { fmt_size(fs, f); fmt_size(ts, t); OUT("livre %s de %s", fs, ts); }
        else ERR("df: indisponivel aqui");
    }
    else if (!strcmp(c, "mkdir") && argc > 1) {
        rp(a, argv[1]);
        if (path_is_ro(a)) ERR("somente leitura");
        else if (fs_mkpath(a) == FS_OK) OUT("criada: %s", a); else ERR("mkdir: erro");
    }
    else if (!strcmp(c, "touch") && argc > 1) {
        rp(a, argv[1]);
        if (path_is_ro(a)) ERR("somente leitura");
        else if (fs_exists(a)) OUT("ja existe");
        else { SceUID fd = sceIoOpen(a, PSP_O_WRONLY | PSP_O_CREAT, 0777); if (fd >= 0) sceIoClose(fd); else ERR("touch: erro"); }
    }
    else if (!strcmp(c, "echo")) {
        char t[512] = "";
        for (int i = 1; i < argc; i++) { if (i > 1) strncat(t, " ", sizeof(t) - strlen(t) - 1); strncat(t, argv[i], sizeof(t) - strlen(t) - 1); }
        OUT("%s", t);
    }
    else if ((!strcmp(c, "cp") || !strcmp(c, "mv")) && argc > 2) {
        rp(a, argv[1]);
        rp(b, argv[2]);
        if (is_dir(b)) { char t[512]; path_join(t, sizeof(t), b, path_base(a)); snprintf(b, sizeof(b), "%s", t); }
        int mv = !strcmp(c, "mv");
        if (!fs_exists(a)) ERR("%s: origem nao existe", c);
        else if (path_is_ro(b) || (mv && path_is_ro(a))) ERR("somente leitura");
        else if (fs_exists(b)) ERR("%s: destino ja existe", c);
        else if (path_inside(b, a)) ERR("%s: destino dentro da origem", c);
        else {
            ui_set_op(mv ? "Movendo" : "Copiando");
            int r = mv ? fs_move(a, b) : fs_copy(a, b);
            if (r == FS_OK) tprint(C_GREEN, "ok"); else if (r == FS_CANCEL) ERR("cancelado"); else ERR("%s: erro", c);
        }
    }
    else if (!strcmp(c, "rm") && argc > 1) {
        int rec = 0;
        const char *t = NULL;
        for (int i = 1; i < argc; i++) { if (!strcmp(argv[i], "-r") || !strcmp(argv[i], "-rf")) rec = 1; else t = argv[i]; }
        if (!t) { ERR("uso: rm [-r] alvo"); }
        else {
            rp(a, t);
            if (path_is_ro(a)) ERR("somente leitura");
            else if (!fs_exists(a)) ERR("rm: nao existe");
            else if (is_dir(a) && !rec) ERR("rm: e uma pasta (use -r)");
            else {
                char l2[96];
                snprintf(l2, sizeof(l2), "%.90s", a);
                if (ui_confirm("Excluir permanentemente?", l2)) {
                    ui_set_op("Excluindo");
                    int r = fs_delete(a);
                    if (r == FS_OK) tprint(C_GREEN, "ok"); else if (r == FS_CANCEL) ERR("cancelado"); else ERR("rm: erro");
                } else OUT("cancelado");
            }
        }
    }
    else if (!strcmp(c, "zip")) cmd_zip(argc, argv);
    else if (!strcmp(c, "unzip") || !strcmp(c, "unrar") || !strcmp(c, "rar") || !strcmp(c, "extract")) cmd_unarc(argc, argv);
    else if (argc > 1 && (!strcmp(c, "edit") || !strcmp(c, "hex") || !strcmp(c, "view") || !strcmp(c, "img") || !strcmp(c, "play"))) {
        rp(a, argv[1]);
        if (!fs_exists(a) && strcmp(c, "edit")) ERR("%s: nao existe", argv[1]);
        else {
            if (!fs_exists(a)) { SceUID fd = sceIoOpen(a, PSP_O_WRONLY | PSP_O_CREAT, 0777); if (fd >= 0) sceIoClose(fd); }
            if (!strcmp(c, "edit")) edit_text(a);
            else if (!strcmp(c, "hex")) edit_hex(a);
            else if (!strcmp(c, "view")) view_text(a);
            else if (!strcmp(c, "img")) view_image(a);
            else play_audio(a);
        }
    }
    else if (!strcmp(c, "history")) { for (int i = 0; i < nh; i++) OUT("%2d  %s", i + 1, hist[i]); }
    else ERR("%s: comando desconhecido (digite help)", c);
}

static void pick_file(void)
{
    DirList dl;
    if (dir_load(cwd, &dl, 1) != FS_OK) return;
    dir_sort(&dl, SORT_NAME);
    const char **items = (const char **)malloc((size_t)dl.n * sizeof(char *));
    if (!items) { dir_free(&dl); return; }
    for (int i = 0; i < dl.n; i++) items[i] = dl.v[i].name;
    int s = ui_menu("Inserir nome no comando", items, dl.n, 0);
    if (s >= 0 && strcmp(dl.v[s].name, "..") != 0) {
        char t[300];
        if (strchr(dl.v[s].name, ' ')) snprintf(t, sizeof(t), "\"%s\"", dl.v[s].name);
        else snprintf(t, sizeof(t), "%s", dl.v[s].name);
        if (pending[0] && pending[strlen(pending) - 1] != ' ') strncat(pending, " ", sizeof(pending) - strlen(pending) - 1);
        strncat(pending, t, sizeof(pending) - strlen(pending) - 1);
    }
    free(items);
    dir_free(&dl);
}

void terminal_run(const char *startdir)
{
    snprintf(cwd, sizeof(cwd), "%s", startdir);
    tn = 0; thead = 0; tscroll = 0; pending[0] = 0; hsel = -1; quit = 0;
    tprint(C_CYAN, "Terminal do File Manager. Digite help.");
    ui_clear();

    while (!quit) {
        draw();
        unsigned p = ui_wait();
        if (p & PSP_CTRL_CIRCLE) break;
        if (p & PSP_CTRL_UP)    tscroll++;
        if (p & PSP_CTRL_DOWN)  { if (tscroll > 0) tscroll--; }
        if (p & PSP_CTRL_LEFT)  tscroll += OUT_ROWS;
        if (p & PSP_CTRL_RIGHT) tscroll = (tscroll > OUT_ROWS) ? tscroll - OUT_ROWS : 0;
        if ((p & PSP_CTRL_LTRIGGER) && nh > 0) {
            hsel = (hsel < 0) ? nh - 1 : (hsel > 0 ? hsel - 1 : 0);
            snprintf(pending, sizeof(pending), "%s", hist[hsel]);
        }
        if ((p & PSP_CTRL_RTRIGGER) && nh > 0 && hsel >= 0) {
            if (hsel < nh - 1) { hsel++; snprintf(pending, sizeof(pending), "%s", hist[hsel]); }
            else { hsel = -1; pending[0] = 0; }
        }
        if (p & PSP_CTRL_TRIANGLE) { pick_file(); ui_clear(); }
        if (p & (PSP_CTRL_CROSS | PSP_CTRL_START)) {
            char buf[160];
            snprintf(buf, sizeof(buf), "%s", pending);
            int ok = ui_input_text("Comando (Start = executar)", buf, sizeof(buf));
            ui_clear();
            if (!ok) continue;
            pending[0] = 0;
            hsel = -1;
            tprint(C_GREEN, "> %s", buf);
            if (nh == 0 || strcmp(hist[nh - 1], buf)) {
                if (nh == HIST_MAX) { memmove(hist, hist + 1, sizeof(hist[0]) * (HIST_MAX - 1)); nh--; }
                snprintf(hist[nh++], sizeof(hist[0]), "%s", buf);
            }
            char work[160];
            snprintf(work, sizeof(work), "%s", buf);
            run(work);
            if (redir) { fclose(redir); redir = NULL; }
            ui_clear();
        }
    }
    ui_clear();
}
