#ifndef FSOPS_H
#define FSOPS_H

#include <pspkernel.h>

#define FS_OK      0
#define FS_ERR    -1
#define FS_CANCEL -2

typedef struct {
    char name[256];
    int  isdir;
    unsigned long long size;
    unsigned long long mkey;   /* chave numerica da data de modificacao */
    ScePspDateTime mtime;
    int  marked;
} Entry;

typedef struct {
    Entry *v;
    int n, cap;
} DirList;

enum { SORT_NAME, SORT_SIZE, SORT_DATE, SORT_COUNT };

/* listagem */
int  dir_load(const char *path, DirList *dl, int with_updir);
void dir_free(DirList *dl);
void dir_sort(DirList *dl, int mode);
int  dir_find(const DirList *dl, const char *name);

/* caminhos */
void        path_join(char *out, int sz, const char *dir, const char *name);
void        path_parent(char *path);
const char *path_base(const char *path);
int         path_is_root(const char *path);
int         path_is_ro(const char *path);          /* flash0/flash1/umd: somente leitura */
int         path_inside(const char *child, const char *parent);

/* operacoes */
int  fs_exists(const char *path);
void fs_unique(char *path, int sz);                /* evita sobrescrever: nome_copia.ext */
int  fs_copy(const char *src, const char *dst);    /* arquivo ou pasta (recursivo) */
int  fs_move(const char *src, const char *dst);
int  fs_delete(const char *path);                  /* recursivo */
void fs_tree_size(const char *path, unsigned long long *bytes, int *files, int *dirs);
int  fs_devinfo(const char *path, unsigned long long *freeb, unsigned long long *totalb);

/* apoio para arquivos compactados e terminal */
int  fs_mkpath(const char *dir);                   /* cria a pasta e todas as pais */
int  fs_stat_info(const char *path, int *isdir, unsigned long long *size,
                  unsigned *dosdate, unsigned *dostime);
void *fs_dir_open(const char *path);
int  fs_dir_next(void *h, char *name, int sz);     /* 1 = ok, 0 = fim */
void fs_dir_close(void *h);
void path_resolve(char *out, int sz, const char *cwd, const char *arg);  /* relativo/absoluto, . e .. */

/* callback de progresso; retorna != 0 para cancelar */
extern int (*fs_progress)(const char *name, unsigned long long done, unsigned long long total);

#endif
