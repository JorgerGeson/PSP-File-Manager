/*
 * imgview.c - visualizador de imagens (PNG, JPG, BMP)
 *
 * Desenha direto na VRAM (480x272, 32 bits, 512 de stride), com escala por
 * vizinho mais proximo em ponto fixo.
 *   D-pad: rolar   L/R: zoom -/+   X: ajustar/100%   Tri: info
 *   Select/Start: imagem anterior/proxima da pasta   O: sair
 */
#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <pspdebug.h>
#include <pspge.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"
#include "fsops.h"
#include "imgdec.h"
#include "imgview.h"

#define SW 480
#define SH 272
#define VSTRIDE 512

int is_image_name(const char *name) { return img_type(name) != IMG_NONE; }

static unsigned *vram(void)
{
    return (unsigned *)(0x40000000u | (unsigned)sceGeEdramGetAddr());
}

static void vram_fill(unsigned c)
{
    unsigned *v = vram();
    for (int y = 0; y < SH; y++)
        for (int x = 0; x < VSTRIDE; x++) v[y * VSTRIDE + x] = c;
}

static void render(const Image *im, float zoom, float cx, float cy)
{
    unsigned *v = vram();
    int step = (int)(65536.0f / zoom);
    if (step < 1) step = 1;
    long long u0 = (long long)((cx - (SW / 2) / zoom) * 65536.0f);
    long long v0 = (long long)((cy - (SH / 2) / zoom) * 65536.0f);

    for (int sy = 0; sy < SH; sy++) {
        unsigned *dst = v + sy * VSTRIDE;
        long long vy = v0 + (long long)sy * step;
        if (vy < 0 || (vy >> 16) >= im->h) {
            for (int sx = 0; sx < SW; sx++) dst[sx] = 0xFF000000u;
            continue;
        }
        const unsigned *row = im->px + (size_t)(vy >> 16) * (size_t)im->w;
        long long u = u0;
        for (int sx = 0; sx < SW; sx++, u += step) {
            if (u < 0 || (u >> 16) >= im->w) dst[sx] = 0xFF000000u;
            else dst[sx] = row[u >> 16];
        }
    }
}

static float fit_zoom(const Image *im)
{
    float zx = (float)SW / (float)im->w, zy = (float)SH / (float)im->h;
    return zx < zy ? zx : zy;
}

static void clamp_center(const Image *im, float zoom, float *cx, float *cy)
{
    float hw = (SW / 2) / zoom, hh = (SH / 2) / zoom;
    if (im->w * zoom <= SW) *cx = im->w / 2.0f;
    else { if (*cx < hw) *cx = hw; if (*cx > im->w - hw) *cx = im->w - hw; }
    if (im->h * zoom <= SH) *cy = im->h / 2.0f;
    else { if (*cy < hh) *cy = hh; if (*cy > im->h - hh) *cy = im->h - hh; }
}

/* lista as imagens da pasta de "path" */
static int list_images(const char *path, char **dirout, char (**names)[256], int *n, int *index)
{
    char *dir = (char *)malloc(512);
    if (!dir) return 0;
    snprintf(dir, 512, "%s", path);
    path_parent(dir);

    DirList dl;
    if (dir_load(dir, &dl, 0) != FS_OK) { free(dir); return 0; }
    dir_sort(&dl, SORT_NAME);

    char (*nm)[256] = (char (*)[256])malloc((size_t)(dl.n ? dl.n : 1) * 256);
    int cnt = 0, idx = 0;
    const char *base = path_base(path);
    for (int i = 0; nm && i < dl.n; i++) {
        if (dl.v[i].isdir || !is_image_name(dl.v[i].name)) continue;
        snprintf(nm[cnt], 256, "%s", dl.v[i].name);
        if (!strcmp(dl.v[i].name, base)) idx = cnt;
        cnt++;
    }
    dir_free(&dl);
    if (!nm || cnt == 0) { free(nm); free(dir); return 0; }
    *dirout = dir;
    *names = nm;
    *n = cnt;
    *index = idx;
    return 1;
}

void view_image(const char *path)
{
    char *dir = NULL;
    char (*names)[256] = NULL;
    int n = 0, idx = 0;
    if (!list_images(path, &dir, &names, &n, &idx)) {
        ui_message("Nao foi possivel listar as imagens.", "", C_RED);
        return;
    }

    Image im;
    memset(&im, 0, sizeof(im));
    float zoom = 1.0f, fit = 1.0f, cx = 0, cy = 0;
    int show = 1, loaded = 0, dirty = 1, goto_next = 0;
    char err[128] = "";

    for (;;) {
        if (!loaded) {
            char full[512];
            img_free(&im);
            path_join(full, sizeof(full), dir, names[idx]);
            ui_clear();
            ui_line(15, C_BLACK, C_ORANGE, " Carregando imagem...");
            ui_line(16, C_WHITE, C_BLUE, " %s", names[idx]);
            err[0] = 0;
            if (img_decode(full, &im, err, sizeof(err))) {
                fit = fit_zoom(&im);
                zoom = fit < 1.0f ? fit : 1.0f;
                cx = im.w / 2.0f;
                cy = im.h / 2.0f;
                clamp_center(&im, zoom, &cx, &cy);
            }
            loaded = 1;
            dirty = 1;
        }

        if (dirty) {
            if (im.px) {
                render(&im, zoom, cx, cy);
                if (show) {
                    ui_line(0, C_BLACK, C_CYAN, " %.30s %dx%d%s %d%% [%d/%d]", names[idx], im.ow, im.oh,
                            im.step > 1 ? " (reduzida)" : "", (int)(zoom * 100.0f * (float)im.step + 0.5f), idx + 1, n);
                    ui_line(33, C_GRAY, C_BLACK, " Setas:rolar L/R:zoom X:ajustar Tri:info Sel/Start:ant/prox O:sair");
                }
            } else {
                vram_fill(0xFF000000u);
                ui_line(0, C_BLACK, C_CYAN, " %.40s [%d/%d]", names[idx], idx + 1, n);
                ui_line(14, C_BLACK, C_RED, " ERRO");
                ui_line(15, C_WHITE, C_BLUE, " %.64s", err);
                ui_line(33, C_GRAY, C_BLACK, " Sel/Start: ant/prox   O: sair");
            }
            dirty = 0;
        }

        unsigned p = ui_wait();
        float pan = 32.0f / zoom;
        goto_next = 0;

        if (p & PSP_CTRL_CIRCLE) break;
        if (p & PSP_CTRL_START)  goto_next = 1;
        if (p & PSP_CTRL_SELECT) goto_next = -1;
        if (goto_next) {
            idx = (idx + n + goto_next) % n;
            loaded = 0;
            continue;
        }
        if (!im.px) continue;

        if (p & PSP_CTRL_UP)    { cy -= pan; dirty = 1; }
        if (p & PSP_CTRL_DOWN)  { cy += pan; dirty = 1; }
        if (p & PSP_CTRL_LEFT)  { cx -= pan; dirty = 1; }
        if (p & PSP_CTRL_RIGHT) { cx += pan; dirty = 1; }
        if (p & PSP_CTRL_RTRIGGER) { zoom *= 1.25f; if (zoom > 16.0f) zoom = 16.0f; dirty = 1; }
        if (p & PSP_CTRL_LTRIGGER) {
            float mn = fit < 1.0f ? fit : 1.0f;
            zoom /= 1.25f;
            if (zoom < mn * 0.5f) zoom = mn * 0.5f;
            dirty = 1;
        }
        if (p & PSP_CTRL_CROSS) {
            float d = zoom - fit;
            if (d < 0.01f && d > -0.01f) zoom = 1.0f; else zoom = fit;
            cx = im.w / 2.0f;
            cy = im.h / 2.0f;
            dirty = 1;
        }
        if (p & PSP_CTRL_TRIANGLE) { show = !show; dirty = 1; }
        if (dirty) clamp_center(&im, zoom, &cx, &cy);
    }

    img_free(&im);
    free(names);
    free(dir);
    vram_fill(0xFF000000u);
    ui_clear();
}
