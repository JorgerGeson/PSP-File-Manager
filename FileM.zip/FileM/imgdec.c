#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <setjmp.h>
#include <png.h>
#ifndef NO_JPEG
#include <jpeglib.h>
#endif
#include "imgdec.h"

#define MAXPIX      (2 * 1024 * 1024)     /* pixels guardados (8 MB) */
#define MAXFULL     (3 * 1024 * 1024)     /* PNG entrelacado: imagem inteira em memoria */
#define MAXDIM      30000

static char s_err[128];

static void set_err(const char *m) { snprintf(s_err, sizeof(s_err), "%s", m); }

int img_type(const char *name)
{
    const char *d = strrchr(name, '.');
    if (!d) return IMG_NONE;
    d++;
    if (!strcasecmp(d, "png")) return IMG_PNG;
    if (!strcasecmp(d, "jpg") || !strcasecmp(d, "jpeg") || !strcasecmp(d, "jpe")) return IMG_JPG;
    if (!strcasecmp(d, "bmp")) return IMG_BMP;
    return IMG_NONE;
}

void img_free(Image *im)
{
    if (im->px) free(im->px);
    memset(im, 0, sizeof(*im));
}

static int pick_step(int w, int h)
{
    int step = 1;
    while ((long long)((w + step - 1) / step) * ((h + step - 1) / step) > MAXPIX && step < 64) step++;
    return step;
}

static unsigned pack(unsigned r, unsigned g, unsigned b) { return 0xFF000000u | (b << 16) | (g << 8) | r; }

/* =============================== PNG =============================== */
static FILE *p_fp;
static unsigned *p_px;
static unsigned char *p_row, *p_full;
static unsigned char **p_rows;
static png_structp p_png;
static png_infop p_info;

static void png_err_cb(png_structp png, png_const_charp msg)
{
    set_err(msg);
    png_longjmp(png, 1);
}
static void png_warn_cb(png_structp png, png_const_charp msg) { (void)png; (void)msg; }

static void png_cleanup(void)
{
    if (p_png) png_destroy_read_struct(&p_png, &p_info, NULL);
    p_png = NULL;
    p_info = NULL;
    if (p_fp) fclose(p_fp);
    p_fp = NULL;
    free(p_row); p_row = NULL;
    free(p_full); p_full = NULL;
    free(p_rows); p_rows = NULL;
}

static unsigned rgba_to_px(const unsigned char *s)
{
    unsigned a = s[3];
    if (a == 255) return pack(s[0], s[1], s[2]);
    return pack(s[0] * a / 255, s[1] * a / 255, s[2] * a / 255);   /* sobre fundo preto */
}

static int decode_png(const char *path, Image *im)
{
    p_fp = fopen(path, "rb");
    if (!p_fp) { set_err("Nao foi possivel abrir o arquivo"); return 0; }
    unsigned char sig[8];
    if (fread(sig, 1, 8, p_fp) != 8 || png_sig_cmp(sig, 0, 8)) { set_err("PNG invalido"); png_cleanup(); return 0; }

    p_png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, png_err_cb, png_warn_cb);
    if (!p_png) { set_err("Sem memoria"); png_cleanup(); return 0; }
    p_info = png_create_info_struct(p_png);
    if (!p_info) { set_err("Sem memoria"); png_cleanup(); return 0; }
    p_px = NULL;

    if (setjmp(png_jmpbuf(p_png))) {
        free(p_px); p_px = NULL;
        png_cleanup();
        return 0;
    }
    png_init_io(p_png, p_fp);
    png_set_sig_bytes(p_png, 8);
    png_read_info(p_png, p_info);

    png_uint_32 w = png_get_image_width(p_png, p_info), h = png_get_image_height(p_png, p_info);
    int ct = png_get_color_type(p_png, p_info), bd = png_get_bit_depth(p_png, p_info);
    if (w == 0 || h == 0 || w > MAXDIM || h > MAXDIM) { set_err("Dimensoes nao suportadas"); png_longjmp(p_png, 1); }

    if (bd == 16) png_set_strip_16(p_png);
    if (ct == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(p_png);
    if (ct == PNG_COLOR_TYPE_GRAY && bd < 8) png_set_expand_gray_1_2_4_to_8(p_png);
    if (png_get_valid(p_png, p_info, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(p_png);
    if (ct == PNG_COLOR_TYPE_GRAY || ct == PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(p_png);
    png_set_filler(p_png, 0xFF, PNG_FILLER_AFTER);
    int passes = png_set_interlace_handling(p_png);
    png_read_update_info(p_png, p_info);

    size_t rb = png_get_rowbytes(p_png, p_info);
    if (rb < (size_t)w * 4) { set_err("Formato PNG nao suportado"); png_longjmp(p_png, 1); }

    int step = pick_step((int)w, (int)h);
    if (passes > 1 && (long long)w * h > MAXFULL) { set_err("PNG entrelacado grande demais"); png_longjmp(p_png, 1); }
    int ow = ((int)w + step - 1) / step, oh = ((int)h + step - 1) / step;

    p_px = (unsigned *)malloc((size_t)ow * (size_t)oh * 4);
    if (!p_px) { set_err("Memoria insuficiente"); png_longjmp(p_png, 1); }

    if (passes <= 1) {
        p_row = (unsigned char *)malloc(rb);
        if (!p_row) { set_err("Memoria insuficiente"); png_longjmp(p_png, 1); }
        for (png_uint_32 y = 0; y < h; y++) {
            png_read_row(p_png, p_row, NULL);
            if (y % (unsigned)step) continue;
            unsigned *dst = p_px + (size_t)(y / (unsigned)step) * (size_t)ow;
            for (int x = 0, ox = 0; x < (int)w && ox < ow; x += step, ox++) dst[ox] = rgba_to_px(p_row + (size_t)x * 4);
        }
    } else {
        p_full = (unsigned char *)malloc(rb * h);
        p_rows = (unsigned char **)malloc(sizeof(unsigned char *) * h);
        if (!p_full || !p_rows) { set_err("Memoria insuficiente"); png_longjmp(p_png, 1); }
        for (png_uint_32 y = 0; y < h; y++) p_rows[y] = p_full + (size_t)y * rb;
        png_read_image(p_png, p_rows);
        for (png_uint_32 y = 0; y < h; y += (unsigned)step) {
            unsigned *dst = p_px + (size_t)(y / (unsigned)step) * (size_t)ow;
            for (int x = 0, ox = 0; x < (int)w && ox < ow; x += step, ox++) dst[ox] = rgba_to_px(p_rows[y] + (size_t)x * 4);
        }
    }
    png_cleanup();
    im->px = p_px;
    p_px = NULL;
    im->w = ow; im->h = oh; im->ow = (int)w; im->oh = (int)h; im->step = step;
    return 1;
}

/* =============================== JPEG =============================== */
#ifndef NO_JPEG
struct jerr { struct jpeg_error_mgr pub; jmp_buf jb; };

static void jerr_exit(j_common_ptr c)
{
    char buf[JMSG_LENGTH_MAX];
    (*c->err->format_message)(c, buf);
    set_err(buf);
    longjmp(((struct jerr *)c->err)->jb, 1);
}

static FILE *j_fp;
static unsigned *j_px;
static unsigned char *j_row;
static struct jpeg_decompress_struct j_ci;
static struct jerr j_err;

static void jpg_cleanup(void)
{
    jpeg_destroy_decompress(&j_ci);
    if (j_fp) fclose(j_fp);
    j_fp = NULL;
    free(j_row); j_row = NULL;
}

static int decode_jpg(const char *path, Image *im)
{
    j_fp = fopen(path, "rb");
    if (!j_fp) { set_err("Nao foi possivel abrir o arquivo"); return 0; }
    j_px = NULL;
    j_row = NULL;

    j_ci.err = jpeg_std_error(&j_err.pub);
    j_err.pub.error_exit = jerr_exit;
    if (setjmp(j_err.jb)) {
        free(j_px); j_px = NULL;
        jpg_cleanup();
        return 0;
    }
    jpeg_create_decompress(&j_ci);
    jpeg_stdio_src(&j_ci, j_fp);
    jpeg_read_header(&j_ci, TRUE);

    int w = (int)j_ci.image_width, h = (int)j_ci.image_height;
    if (w <= 0 || h <= 0 || w > MAXDIM || h > MAXDIM) { set_err("Dimensoes nao suportadas"); longjmp(j_err.jb, 1); }

    int denom = 1;                                   /* reducao nativa 1/1, 1/2, 1/4, 1/8 (rapida) */
    while (denom < 8 && (long long)((w + denom - 1) / denom) * ((h + denom - 1) / denom) > MAXPIX) denom *= 2;

    j_ci.out_color_space = JCS_RGB;
    j_ci.scale_num = 1;
    j_ci.scale_denom = (unsigned)denom;
    j_ci.dct_method = JDCT_IFAST;
    j_ci.do_fancy_upsampling = FALSE;
    jpeg_start_decompress(&j_ci);

    int ow = (int)j_ci.output_width, oh = (int)j_ci.output_height;
    if ((long long)ow * oh > MAXPIX * 4LL) { set_err("Imagem grande demais"); longjmp(j_err.jb, 1); }
    j_px = (unsigned *)malloc((size_t)ow * (size_t)oh * 4);
    j_row = (unsigned char *)malloc((size_t)ow * (size_t)j_ci.output_components);
    if (!j_px || !j_row) { set_err("Memoria insuficiente"); longjmp(j_err.jb, 1); }

    int comps = j_ci.output_components;
    while ((int)j_ci.output_scanline < oh) {
        int y = (int)j_ci.output_scanline;
        JSAMPROW rp = j_row;
        jpeg_read_scanlines(&j_ci, &rp, 1);
        unsigned *dst = j_px + (size_t)y * (size_t)ow;
        if (comps >= 3) for (int x = 0; x < ow; x++) dst[x] = pack(j_row[x * comps], j_row[x * comps + 1], j_row[x * comps + 2]);
        else            for (int x = 0; x < ow; x++) dst[x] = pack(j_row[x], j_row[x], j_row[x]);
    }
    jpeg_finish_decompress(&j_ci);
    jpg_cleanup();
    im->px = j_px;
    j_px = NULL;
    im->w = ow; im->h = oh; im->ow = w; im->oh = h; im->step = denom;
    return 1;
}
#else
static int decode_jpg(const char *path, Image *im) { (void)path; (void)im; set_err("JPEG desativado"); return 0; }
#endif

/* =============================== BMP =============================== */
static unsigned le16(const unsigned char *p) { return p[0] | (p[1] << 8); }
static unsigned le32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((unsigned)p[3] << 24); }

static int mask_shift(unsigned m, int *bits)
{
    int s = 0;
    if (!m) { *bits = 0; return 0; }
    while (!(m & 1)) { m >>= 1; s++; }
    int b = 0;
    while (m & 1) { m >>= 1; b++; }
    *bits = b;
    return s;
}

static unsigned scale8(unsigned v, int bits)
{
    if (bits == 0) return 0;
    if (bits >= 8) return v >> (bits - 8);
    return (v * 255) / ((1u << bits) - 1);
}

static int decode_bmp(const char *path, Image *im)
{
    FILE *f = fopen(path, "rb");
    if (!f) { set_err("Nao foi possivel abrir o arquivo"); return 0; }
    unsigned char hd[124 + 14];
    size_t got = fread(hd, 1, 14 + 40, f);
    if (got < 14 + 12 || hd[0] != 'B' || hd[1] != 'M') { fclose(f); set_err("BMP invalido"); return 0; }

    unsigned dataoff = le32(hd + 10), dib = le32(hd + 14);
    int w, h, bpp, comp = 0;
    unsigned ncol = 0;
    if (dib == 12) { w = (int)le16(hd + 18); h = (int)le16(hd + 20); bpp = (int)le16(hd + 24); }
    else if (dib >= 40 && got >= 54) {
        w = (int)le32(hd + 18); h = (int)le32(hd + 22); bpp = (int)le16(hd + 28);
        comp = (int)le32(hd + 30); ncol = le32(hd + 46);
    } else { fclose(f); set_err("BMP invalido"); return 0; }

    int topdown = 0;
    if (h < 0) { h = -h; topdown = 1; }
    if (w <= 0 || h <= 0 || w > MAXDIM || h > MAXDIM) { fclose(f); set_err("Dimensoes nao suportadas"); return 0; }
    if (comp != 0 && comp != 3) { fclose(f); set_err("BMP comprimido (RLE) nao suportado"); return 0; }
    if (bpp != 1 && bpp != 4 && bpp != 8 && bpp != 16 && bpp != 24 && bpp != 32) { fclose(f); set_err("Profundidade BMP nao suportada"); return 0; }

    unsigned pal[256];
    memset(pal, 0, sizeof(pal));
    unsigned masks[3] = { 0, 0, 0 };
    if (bpp <= 8) {
        unsigned n = ncol ? ncol : (1u << bpp);
        if (n > 256) n = 256;
        int esz = (dib == 12) ? 3 : 4;
        fseek(f, (long)(14 + dib), SEEK_SET);
        for (unsigned i = 0; i < n; i++) {
            unsigned char e[4] = { 0, 0, 0, 0 };
            if (fread(e, 1, (size_t)esz, f) != (size_t)esz) break;
            pal[i] = pack(e[2], e[1], e[0]);
        }
    } else if (bpp == 16 || bpp == 32) {
        if (comp == 3) {
            unsigned char m[12];
            fseek(f, 14 + 40, SEEK_SET);
            if (fread(m, 1, 12, f) == 12) { masks[0] = le32(m); masks[1] = le32(m + 4); masks[2] = le32(m + 8); }
        } else if (bpp == 16) { masks[0] = 0x7C00; masks[1] = 0x03E0; masks[2] = 0x001F; }
        else                  { masks[0] = 0xFF0000; masks[1] = 0x00FF00; masks[2] = 0x0000FF; }
    }
    int sh[3], nb[3];
    for (int i = 0; i < 3; i++) sh[i] = mask_shift(masks[i], &nb[i]);

    int step = pick_step(w, h);
    int ow = (w + step - 1) / step, oh = (h + step - 1) / step;
    size_t stride = (((size_t)w * (size_t)bpp + 31) / 32) * 4;
    unsigned *px = (unsigned *)malloc((size_t)ow * (size_t)oh * 4);
    unsigned char *row = (unsigned char *)malloc(stride);
    if (!px || !row) { free(px); free(row); fclose(f); set_err("Memoria insuficiente"); return 0; }

    fseek(f, (long)dataoff, SEEK_SET);
    for (int fr = 0; fr < h; fr++) {
        if (fread(row, 1, stride, f) != stride) { free(px); free(row); fclose(f); set_err("BMP truncado"); return 0; }
        int dy = topdown ? fr : h - 1 - fr;
        if (dy % step) continue;
        unsigned *dst = px + (size_t)(dy / step) * (size_t)ow;
        for (int x = 0, ox = 0; x < w && ox < ow; x += step, ox++) {
            unsigned c;
            switch (bpp) {
            case 1:  c = pal[(row[x >> 3] >> (7 - (x & 7))) & 1]; break;
            case 4:  c = pal[(row[x >> 1] >> ((x & 1) ? 0 : 4)) & 15]; break;
            case 8:  c = pal[row[x]]; break;
            case 24: c = pack(row[x * 3 + 2], row[x * 3 + 1], row[x * 3]); break;
            case 16: {
                unsigned v = le16(row + x * 2);
                c = pack(scale8((v & masks[0]) >> sh[0], nb[0]), scale8((v & masks[1]) >> sh[1], nb[1]),
                         scale8((v & masks[2]) >> sh[2], nb[2]));
                break;
            }
            default: {
                unsigned v = le32(row + x * 4);
                c = pack(scale8((v & masks[0]) >> sh[0], nb[0]), scale8((v & masks[1]) >> sh[1], nb[1]),
                         scale8((v & masks[2]) >> sh[2], nb[2]));
                break;
            }
            }
            dst[ox] = c;
        }
    }
    free(row);
    fclose(f);
    im->px = px;
    im->w = ow; im->h = oh; im->ow = w; im->oh = h; im->step = step;
    return 1;
}

/* =============================== API =============================== */
int img_decode(const char *path, Image *im, char *err, int esz)
{
    memset(im, 0, sizeof(*im));
    s_err[0] = 0;
    int t = img_type(path);
    int ok = 0;
    if (t == IMG_PNG) ok = decode_png(path, im);
    else if (t == IMG_JPG) ok = decode_jpg(path, im);
    else if (t == IMG_BMP) ok = decode_bmp(path, im);
    else set_err("Formato nao suportado (use PNG, JPG ou BMP)");
    if (!ok && err) snprintf(err, (size_t)esz, "%s", s_err[0] ? s_err : "Erro ao decodificar");
    return ok;
}
