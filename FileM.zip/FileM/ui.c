#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "ui.h"

static unsigned g_prev = 0, g_held = 0;
static int g_rep = 0;
static char g_op[48] = "";

void ui_init(void)
{
    pspDebugScreenInit();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);
}

/* A fonte do PSP so tem ASCII: UTF-8 vira 1 coluna por caractere (acentos perdem o acento). */
int ui_fold_char(const unsigned char *s, int avail, char *out)
{
    static const char tab[] = "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTsaaaaaaaceeeeiiiidnooooo/ouuuuyty";
    unsigned char c = s[0];
    if (c >= 32 && c < 127) { *out = (char)c; return 1; }
    if (c < 32 || c == 127) { *out = '?'; return 1; }
    if ((c == 0xC2 || c == 0xC3) && avail >= 2 && (s[1] & 0xC0) == 0x80) {
        unsigned cp = ((unsigned)(c & 0x1F) << 6) | (s[1] & 0x3F);
        char r = '?';
        if (cp >= 0xC0 && cp <= 0xFF) r = tab[cp - 0xC0];
        else if (cp == 0xAA) r = 'a';
        else if (cp == 0xBA || cp == 0xB0) r = 'o';
        else if (cp == 0xA1) r = '!';
        else if (cp == 0xAB) r = '<';
        else if (cp == 0xBB) r = '>';
        *out = r;
        return 2;
    }
    int n = 1;                                   /* sequencia desconhecida: 1 coluna */
    if (c >= 0xF0) n = 4; else if (c >= 0xE0) n = 3; else if (c >= 0xC0) n = 2;
    int k = 1;
    while (k < n && k < avail && (s[k] & 0xC0) == 0x80) k++;
    *out = '?';
    return k;
}

void ui_line(int row, unsigned fg, unsigned bg, const char *fmt, ...)
{
    char raw[400], tmp[UI_W + 1];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(raw, sizeof(raw), fmt, ap);
    va_end(ap);

    int len = 0, rl = (int)strlen(raw);
    for (int i = 0; i < rl && len < UI_W; ) {
        char ch;
        i += ui_fold_char((const unsigned char *)raw + i, rl - i, &ch);
        tmp[len++] = ch;
    }
    for (int i = len; i < UI_W; i++) tmp[i] = ' ';
    tmp[UI_W] = 0;

    pspDebugScreenSetTextColor(fg);
    pspDebugScreenSetBackColor(bg);
    pspDebugScreenSetXY(0, row);
    pspDebugScreenPrintf("%s", tmp);
}

void ui_clear(void)
{
    for (int r = 0; r < UI_ROWS; r++)
        ui_line(r, C_WHITE, C_BLACK, "");
}

/* ---------------- entrada ---------------- */
unsigned ui_poll(void)
{
    SceCtrlData pad;
    sceCtrlPeekBufferPositive(&pad, 1);
    unsigned b = pad.Buttons;
    unsigned pressed = b & ~g_prev;
    unsigned rep = PSP_CTRL_UP | PSP_CTRL_DOWN | PSP_CTRL_LEFT | PSP_CTRL_RIGHT |
                   PSP_CTRL_LTRIGGER | PSP_CTRL_RTRIGGER;

    if (b & rep) {
        if ((b & rep) == (g_prev & rep)) {
            g_rep++;
            if (g_rep > 18 && (g_rep % 3) == 0) pressed |= (b & rep);
        } else {
            g_rep = 0;
        }
    } else {
        g_rep = 0;
    }
    g_prev = b;
    g_held = b;
    return pressed;
}

unsigned ui_held(void) { return g_held; }

unsigned ui_wait(void)
{
    for (;;) {
        sceDisplayWaitVblankStart();
        unsigned p = ui_poll();
        if (p) return p;
    }
}

/* ---------------- utilidades ---------------- */
void fmt_size(char *out, unsigned long long b)
{
    if (b < 1024ULL)
        sprintf(out, "%uB", (unsigned)b);
    else if (b < 1024ULL * 1024)
        sprintf(out, "%u.%uK", (unsigned)(b / 1024), (unsigned)((b % 1024) * 10 / 1024));
    else if (b < 1024ULL * 1024 * 1024)
        sprintf(out, "%u.%uM", (unsigned)(b >> 20), (unsigned)(((b & 0xFFFFF) * 10) >> 20));
    else
        sprintf(out, "%u.%uG", (unsigned)(b >> 30), (unsigned)(((b & 0x3FFFFFFF) * 10) >> 30));
}

/* ---------------- menu ---------------- */
int ui_menu(const char *title, const char **items, int n, int start)
{
    const int vis = 28;
    int sel = start, top = 0;
    if (n <= 0) return -1;
    ui_clear();

    for (;;) {
        if (sel < top) top = sel;
        if (sel >= top + vis) top = sel - vis + 1;

        ui_line(0, C_BLACK, C_CYAN, " %s", title);
        for (int i = 0; i < vis; i++) {
            int k = top + i;
            if (k < n) {
                if (k == sel) ui_line(2 + i, C_BLACK, C_WHITE, "  > %s", items[k]);
                else          ui_line(2 + i, C_WHITE, C_BLACK, "    %s", items[k]);
            } else {
                ui_line(2 + i, C_WHITE, C_BLACK, "");
            }
        }
        ui_line(33, C_GRAY, C_BLACK, " Cima/Baixo: mover    X: escolher    O: voltar");

        unsigned p = ui_wait();
        if (p & PSP_CTRL_UP)        sel = (sel + n - 1) % n;
        else if (p & PSP_CTRL_DOWN) sel = (sel + 1) % n;
        else if (p & PSP_CTRL_CROSS)  return sel;
        else if (p & PSP_CTRL_CIRCLE) return -1;
    }
}

/* ---------------- caixas de dialogo ---------------- */
int ui_confirm(const char *l1, const char *l2)
{
    ui_line(11, C_BLACK, C_ORANGE, " CONFIRMAR");
    ui_line(12, C_WHITE, C_BLUE, " %s", l1);
    ui_line(13, C_WHITE, C_BLUE, " %s", l2 ? l2 : "");
    ui_line(14, C_YELLOW, C_BLUE, " X = Sim        O = Nao");
    for (;;) {
        unsigned p = ui_wait();
        if (p & PSP_CTRL_CROSS) return 1;
        if (p & PSP_CTRL_CIRCLE) return 0;
    }
}

void ui_message(const char *l1, const char *l2, unsigned color)
{
    ui_line(11, C_BLACK, color, " AVISO");
    ui_line(12, C_WHITE, C_BLUE, " %s", l1);
    ui_line(13, C_WHITE, C_BLUE, " %s", l2 ? l2 : "");
    ui_line(14, C_YELLOW, C_BLUE, " Pressione X");
    for (;;) {
        unsigned p = ui_wait();
        if (p & (PSP_CTRL_CROSS | PSP_CTRL_CIRCLE)) return;
    }
}

/* ---------------- teclado em tela ---------------- */
#define KB_PAGES 4
static const char *g_pages[3][4] = {
    { "abcdefghij", "klmnopqrst", "uvwxyz0123", "456789._-~" },
    { "ABCDEFGHIJ", "KLMNOPQRST", "UVWXYZ0123", "456789._-~" },
    { "!@#$%&()[]", "+=,;'^{}`_", "/\\:*?\"<>|-", "0123456789" },
};
static const char *g_acc[4][10] = {
    { "\xC3\xA1", "\xC3\xA0", "\xC3\xA2", "\xC3\xA3", "\xC3\xA9", "\xC3\xAA", "\xC3\xAD", "\xC3\xB3", "\xC3\xB4", "\xC3\xB5" },
    { "\xC3\xBA", "\xC3\xBC", "\xC3\xA7", "\xC3\x81", "\xC3\x80", "\xC3\x82", "\xC3\x83", "\xC3\x89", "\xC3\x8A", "\xC3\x8D" },
    { "\xC3\x93", "\xC3\x94", "\xC3\x95", "\xC3\x9A", "\xC3\x9C", "\xC3\x87", "\xC3\xB1", "\xC3\x91", "\xC2\xBA", "\xC2\xAA" },
    { "\xC2\xBF", "\xC2\xA1", "\xC2\xAB", "\xC2\xBB", "\xE2\x82\xAC", "\xC2\xA3", "\xC2\xB0", "\xC2\xA7", "\xC3\x97", "\xC3\xB7" },
};
static const char *g_acc_lab[4][10] = {
    { "a'", "a`", "a^", "a~", "e'", "e^", "i'", "o'", "o^", "o~" },
    { "u'", "u:", "c,", "A'", "A`", "A^", "A~", "E'", "E^", "I'" },
    { "O'", "O^", "O~", "U'", "U:", "C,", "n~", "N~", "o.", "a." },
    { "?_", "!_", "<<", ">>", "EU", "Lb", "o0", "SS", "x ", "/ " },
};
static const char *g_acc_desc[4][10] = {
    { "a agudo", "a crase", "a circunflexo", "a til", "e agudo", "e circunflexo", "i agudo", "o agudo", "o circunflexo", "o til" },
    { "u agudo", "u trema", "c cedilha", "A agudo", "A crase", "A circunflexo", "A til", "E agudo", "E circunflexo", "I agudo" },
    { "O agudo", "O circunflexo", "O til", "U agudo", "U trema", "C cedilha", "n til", "N til", "ordinal masc.", "ordinal fem." },
    { "interrogacao invertida", "exclamacao invertida", "aspas <<", "aspas >>", "euro", "libra", "grau", "paragrafo", "vezes", "dividido" },
};
static const char *g_page_names[KB_PAGES] = { "minusculas", "MAIUSCULAS", "simbolos", "acentos" };

static int u8_prev(const char *b, int i)
{
    if (i <= 0) return 0;
    int j = i - 1;
    while (j > 0 && ((unsigned char)b[j] & 0xC0) == 0x80) j--;
    return j;
}

static int u8_next(const char *b, int i)
{
    if (!b[i]) return i;
    int j = i + 1;
    while (b[j] && ((unsigned char)b[j] & 0xC0) == 0x80) j++;
    return j;
}

static void kb_cell(int x, int y, const char *txt, int sel)
{
    pspDebugScreenSetTextColor(sel ? C_BLACK : C_WHITE);
    pspDebugScreenSetBackColor(sel ? C_YELLOW : C_BLACK);
    pspDebugScreenSetXY(x, y);
    pspDebugScreenPrintf(" %-2s", txt);
}

/* retorna 1 = confirmado, 0 = cancelado. maxlen = tamanho do buffer (com o NUL). */
int ui_input_text(const char *title, char *buf, int maxlen)
{
    return ui_input_text_ex(title, buf, maxlen, 0);
}

int ui_input_text_ex(const char *title, char *buf, int maxlen, int allow_empty)
{
    int len = (int)strlen(buf);
    int cur = len;
    int page = 0, cx = 0, cy = 0;
    ui_clear();

    for (;;) {
        /* texto em ASCII (1 coluna por caractere) e posicao do cursor em colunas */
        char disp[512];
        int nd = 0, cc = 0;
        for (int i = 0; i < len && nd < (int)sizeof(disp) - 1; ) {
            if (i == cur) cc = nd;
            char ch;
            i += ui_fold_char((const unsigned char *)buf + i, len - i, &ch);
            disp[nd++] = ch;
        }
        if (cur >= len) cc = nd;
        disp[nd] = 0;
        int ws = (cc > 56) ? cc - 56 : 0;

        ui_line(0, C_BLACK, C_CYAN, " %s", title);
        ui_line(2, C_WHITE, C_BLACK, " Texto: (%d/%d)", len, maxlen - 1);
        ui_line(3, C_GREEN, C_BLACK, " %s%.64s", ws ? "<" : " ", disp + ws);
        {
            char caret[80];
            int cpos = cc - ws + 1;
            if (cpos < 0) cpos = 0;
            if (cpos > 70) cpos = 70;
            memset(caret, ' ', (size_t)cpos);
            caret[cpos] = '^';
            caret[cpos + 1] = 0;
            ui_line(4, C_YELLOW, C_BLACK, "%s", caret);
        }
        ui_line(6, C_GRAY, C_BLACK, " Teclado: %s", g_page_names[page]);

        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 10; c++) {
                char one[2] = { 0, 0 };
                const char *t;
                if (page < 3) { one[0] = g_pages[page][r][c]; t = one; }
                else          t = g_acc_lab[r][c];
                kb_cell(15 + c * 3, 8 + r * 2, t, (r == cy && c == cx));
            }
        if (page == 3) ui_line(16, C_CYAN, C_BLACK, " Tecla: %-40s", g_acc_desc[cy][cx]);
        else           ui_line(16, C_CYAN, C_BLACK, "");

        ui_line(18, C_GRAY, C_BLACK, " X: inserir      Quad: apagar      Tri: espaco");
        ui_line(19, C_GRAY, C_BLACK, " L/R: trocar teclado (min/MAIUS/simbolos/acentos)");
        ui_line(20, C_GRAY, C_BLACK, " Select+Esq/Dir: mover cursor   Select+Cima/Baixo: inicio/fim");
        ui_line(21, C_GRAY, C_BLACK, " Select+Tri: limpar tudo");
        ui_line(22, C_GRAY, C_BLACK, " Start: confirmar      O: cancelar");

        unsigned p = ui_wait();
        int sel = (ui_held() & PSP_CTRL_SELECT) != 0;

        if (sel) {
            if (p & PSP_CTRL_LEFT)  cur = u8_prev(buf, cur);
            if (p & PSP_CTRL_RIGHT) cur = u8_next(buf, cur);
            if (p & PSP_CTRL_UP)    cur = 0;
            if (p & PSP_CTRL_DOWN)  cur = len;
            if (p & PSP_CTRL_TRIANGLE) { buf[0] = 0; len = 0; cur = 0; }
            continue;
        }
        if (p & PSP_CTRL_LEFT)   cx = (cx + 9) % 10;
        if (p & PSP_CTRL_RIGHT)  cx = (cx + 1) % 10;
        if (p & PSP_CTRL_UP)     cy = (cy + 3) % 4;
        if (p & PSP_CTRL_DOWN)   cy = (cy + 1) % 4;
        if (p & PSP_CTRL_LTRIGGER) page = (page + KB_PAGES - 1) % KB_PAGES;
        if (p & PSP_CTRL_RTRIGGER) page = (page + 1) % KB_PAGES;

        const char *ins = NULL;
        char one[2] = { 0, 0 };
        if (p & PSP_CTRL_CROSS) {
            if (page < 3) { one[0] = g_pages[page][cy][cx]; ins = one; }
            else          ins = g_acc[cy][cx];
        }
        if (p & PSP_CTRL_TRIANGLE) { one[0] = ' '; ins = one; }
        if (ins) {
            int il = (int)strlen(ins);
            if (len + il < maxlen) {
                memmove(buf + cur + il, buf + cur, (size_t)(len - cur + 1));
                memcpy(buf + cur, ins, (size_t)il);
                len += il;
                cur += il;
            }
        }
        if (p & PSP_CTRL_SQUARE) {
            if (cur > 0) {
                int pv = u8_prev(buf, cur);
                memmove(buf + pv, buf + cur, (size_t)(len - cur + 1));
                len -= cur - pv;
                cur = pv;
            }
        }
        if (p & PSP_CTRL_START) {
            if (len > 0 || allow_empty) return 1;
        }
        if (p & PSP_CTRL_CIRCLE) return 0;
    }
}

/* ---------------- progresso ---------------- */
void ui_set_op(const char *op)
{
    snprintf(g_op, sizeof(g_op), "%s", op);
}

int ui_progress(const char *name, unsigned long long done, unsigned long long total)
{
    static unsigned last = 0;
    SceCtrlData pad;

    sceCtrlPeekBufferPositive(&pad, 1);
    if (pad.Buttons & PSP_CTRL_CIRCLE) return 1;

    unsigned now = sceKernelGetSystemTimeLow();
    int finished = (total && done >= total);
    if ((now - last) < 100000u && !finished) return 0;
    last = now;

    int pct = total ? (int)(done * 100ULL / total) : 0;
    char bar[52];
    int fill = pct / 2;
    for (int i = 0; i < 50; i++) bar[i] = (i < fill) ? '#' : '.';
    bar[50] = 0;

    ui_line(11, C_BLACK, C_ORANGE, " %s", g_op);
    ui_line(12, C_WHITE, C_BLUE, " %s", name);
    ui_line(13, C_GREEN, C_BLUE, " [%s] %3d%%", bar, pct);
    ui_line(14, C_YELLOW, C_BLUE, " Segure O para cancelar");
    return 0;
}
