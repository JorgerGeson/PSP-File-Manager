#include <pspkernel.h>
#include <pspctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"
#include "fsops.h"
#include "viewer.h"

#define VROWS    32          /* linhas 1..32 da tela */
#define WRAP_COL 66
#define MAX_TEXT (512 * 1024)

typedef struct { int off; int len; } Line;

/* ================= texto ================= */
void view_text(const char *path)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) {
        ui_message("Nao foi possivel ler o arquivo.", "", C_RED);
        return;
    }
    unsigned long long fsize = (unsigned long long)st.st_size;
    int truncated = fsize > MAX_TEXT;
    int n = truncated ? MAX_TEXT : (int)fsize;

    unsigned char *data = (unsigned char *)malloc((size_t)n + 1);
    if (!data) {
        ui_message("Memoria insuficiente.", "", C_RED);
        return;
    }
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) {
        free(data);
        ui_message("Nao foi possivel abrir o arquivo.", "", C_RED);
        return;
    }
    int rd = sceIoRead(fd, data, n);
    sceIoClose(fd);
    if (rd < 0) rd = 0;
    n = rd;

    /* quebra em linhas (com wrap) */
    int cap = 1024, nl = 0;
    Line *ln = (Line *)malloc(cap * sizeof(Line));
    if (!ln) { free(data); return; }

    int i = 0;
    while (i < n) {
        int start = i, col = 0;
        while (i < n && data[i] != '\n' && col < WRAP_COL) { i++; col++; }
        if (nl >= cap) {
            cap *= 2;
            Line *nln = (Line *)realloc(ln, cap * sizeof(Line));
            if (!nln) break;
            ln = nln;
        }
        ln[nl].off = start;
        ln[nl].len = i - start;
        nl++;
        if (i < n && data[i] == '\n') i++;
    }

    const char *name = path_base(path);
    int top = 0;
    int maxtop = (nl > VROWS) ? nl - VROWS : 0;
    ui_clear();

    for (;;) {
        int pct = (nl > 0) ? (int)(((long long)(top + VROWS > nl ? nl : top + VROWS) * 100) / nl) : 100;
        ui_line(0, C_BLACK, C_CYAN, " %s  [%d/%d %d%%]%s", name, nl ? top + 1 : 0, nl, pct,
                truncated ? " (truncado)" : "");

        for (int r = 0; r < VROWS; r++) {
            int idx = top + r;
            if (idx < nl) {
                char tmp[UI_W + 1];
                int k = 0;
                for (int j = 0; j < ln[idx].len && k < UI_W; ) {
                    unsigned char c = data[ln[idx].off + j];
                    if (c == '\r') { j++; continue; }
                    if (c == '\t') { tmp[k++] = ' '; j++; continue; }
                    char ch;
                    j += ui_fold_char(data + ln[idx].off + j, ln[idx].len - j, &ch);
                    tmp[k++] = ch;
                }
                tmp[k] = 0;
                ui_line(1 + r, C_WHITE, C_BLACK, "%s", tmp);
            } else {
                ui_line(1 + r, C_WHITE, C_BLACK, "");
            }
        }
        ui_line(33, C_GRAY, C_BLACK, " Cima/Baixo: linha  L/R: pagina  Esq/Dir: inicio/fim  O: sair");

        unsigned p = ui_wait();
        if (p & PSP_CTRL_UP)        top--;
        if (p & PSP_CTRL_DOWN)      top++;
        if (p & PSP_CTRL_LTRIGGER)  top -= VROWS;
        if (p & PSP_CTRL_RTRIGGER)  top += VROWS;
        if (p & PSP_CTRL_LEFT)      top = 0;
        if (p & PSP_CTRL_RIGHT)     top = maxtop;
        if (top < 0) top = 0;
        if (top > maxtop) top = maxtop;
        if (p & PSP_CTRL_CIRCLE) break;
    }

    free(ln);
    free(data);
}

/* ================= hex ================= */
void view_hex(const char *path)
{
    SceIoStat st;
    if (sceIoGetstat(path, &st) < 0) {
        ui_message("Nao foi possivel ler o arquivo.", "", C_RED);
        return;
    }
    unsigned long long size = (unsigned long long)st.st_size;
    if (size == 0) {
        ui_message("Arquivo vazio.", "", C_YELLOW);
        return;
    }
    SceUID fd = sceIoOpen(path, PSP_O_RDONLY, 0);
    if (fd < 0) {
        ui_message("Nao foi possivel abrir o arquivo.", "", C_RED);
        return;
    }

    const int per_row = 8;
    const int page = VROWS * per_row;           /* 256 bytes por tela */
    unsigned long long maxoff = ((size - 1) / per_row) * per_row;
    unsigned long long off = 0;
    unsigned char buf[VROWS * 8];
    const char *name = path_base(path);
    ui_clear();

    for (;;) {
        sceIoLseek(fd, (SceOff)off, PSP_SEEK_SET);
        int got = sceIoRead(fd, buf, page);
        if (got < 0) got = 0;

        ui_line(0, C_BLACK, C_CYAN, " %s  %08X / %08X", name, (unsigned)off, (unsigned)size);

        for (int r = 0; r < VROWS; r++) {
            char row[96];
            int o = snprintf(row, sizeof(row), "%08X  ", (unsigned)(off + (unsigned long long)r * per_row));
            for (int k = 0; k < per_row; k++) {
                int idx = r * per_row + k;
                if (idx < got) o += snprintf(row + o, sizeof(row) - o, "%02X ", buf[idx]);
                else           o += snprintf(row + o, sizeof(row) - o, "   ");
            }
            row[o++] = ' ';
            for (int k = 0; k < per_row; k++) {
                int idx = r * per_row + k;
                char c = ' ';
                if (idx < got) {
                    c = (char)buf[idx];
                    if (c < 32 || c > 126) c = '.';
                }
                row[o++] = c;
            }
            row[o] = 0;
            ui_line(1 + r, (r * per_row < got) ? C_WHITE : C_GRAY, C_BLACK, "%s", row);
        }
        ui_line(33, C_GRAY, C_BLACK, " Cima/Baixo:linha L/R:pag Esq/Dir:4K Tri:inicio Quad:fim O:sair");

        unsigned p = ui_wait();
        if (p & PSP_CTRL_UP)       off = (off >= (unsigned long long)per_row) ? off - per_row : 0;
        if (p & PSP_CTRL_DOWN)     off += per_row;
        if (p & PSP_CTRL_LTRIGGER) off = (off >= (unsigned long long)page) ? off - page : 0;
        if (p & PSP_CTRL_RTRIGGER) off += page;
        if (p & PSP_CTRL_LEFT)     off = (off >= 4096ULL) ? off - 4096ULL : 0;
        if (p & PSP_CTRL_RIGHT)    off += 4096ULL;
        if (p & PSP_CTRL_TRIANGLE) off = 0;
        if (p & PSP_CTRL_SQUARE)   off = maxoff;
        if (off > maxoff) off = maxoff;
        if (p & PSP_CTRL_CIRCLE) break;
    }
    sceIoClose(fd);
}
